151Paraguay 69th /82
Index Component Value Score       Rank/ 82 Best Performer
- 38.6 69 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 71.3 0.0 67 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 24.1 36.4 62 Australia
3.03 Pupils per teacher in primary education 24.2 52.8 66 Multiple (3)
3.04 Pupils per teacher in secondary education 17.6 58.0 54 Armenia
3.05 Harmonized learning outcomes (score) 382.8 45.7 69 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 39.0 77 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.9 68 Switzerland
4.02 Active labour market policies (1–7) 2.1 18.3 80 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.3 39.1 81 Switzerland
4.04 Percentage of ﬁrms of fering formal training 46.4 61.9 12 Ecuador
4.05 Digital skills among active population (1–7) 2.9 31.8 82 Finland
- 58.5 67 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 65.0 65.0 55 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 4.6 9.2 69 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 57.7 48.1 68 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 97.0 97.0 54 Multiple (13)
5.05 Rural population with electricity access (%) 98.5 98.5 66 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.0 33.4 82 Singapore
- 71.2 41 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 5.0 80.0 25 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.9 76.3 38 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.8 89.0 15 Czech Republic
6.04 Unemployment in rural areas (%) 3.6 85.6 24 Peru
6.05 Ratio of female to male labour force participation rate 68.1 60.1 61 Lao PDR
6.06 Workers in vulnerable employment (%) 38.3 36.2 61 Saudi Arabia
- 37.8 60 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 14.5 58.7 19 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 29.7 21.9 67 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 19.8 24.6 66 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 33.0 22.9 61 Multiple (4)
7.05 Adjusted labour income share (%) 52.3 60.7 37 Switzerland
- 41.2 78 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 73.0 73.0 41 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.4 57.0 53 Singapore
8.03 Pay and productivity (1–7) 3.4 40.3 74 Switzerland
8.04 Employees working more than 48 hours per week (%) 32.5 35.1 68 Bulgaria
8.05 Collective bargaining coverage ratio (%) 1 0.7 69 France
- 31.9 70 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 6.4 25.4 61 Multiple (9)
9.04 Social safety net protection, 1-7 3.3 38.5 69 Norway
- 52.7 55 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 29.0 29.0 75 Denmark
10.02 Government and public services efﬁciency (score) -0.5 41.3 74 Singapore
10.03 Inclusiveness of institutions (score) 0.4 77.0 19 Portugal
10.04 Political stability and protection from violence (score) -0.1 63.5 52 New Zealand

152Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

66th
56th
47th
72nd
57th
70th
45th
59th
76th
72nd
61st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5068
61
38475570
3844
2950
Peru 66th /82
Index Component Value Score      Rank/ 82 Best Performer
- 68.0 56 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 56.9 43.1 64 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.9 82.2 21 Ghana
1.03 Health Access and Quality Index (0–100 best) 64.3 64.3 62 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 82.1 34 Singapore
- 60.8 47 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 99.7 99.7 2 Malta
2.02 Quality of vocational training (1–7) 3.8 47.0 60 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 17.7 41.1 50 Japan
2.04 Out-of-school children (%) 4.2 58.0 52 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 58.3 60 GermanyPeru 66th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %32.2
215.2
7,002.10.34
43.3
4.2

153Peru 66th /82
Index Component Value Score       Rank/ 82 Best Performer
- 37.8 72 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 53.7 23.3 55 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 19.5 51.5 54 Australia
3.03 Pupils per teacher in primary education 17.4 75.4 48 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 404.6 51.2 65 Singapore
3.06 Social diversity in schools (score) 48.8 0.0 62 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material74.6 25.4 58 Multiple (2)
- 46.9 57 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.3 37.6 82 Switzerland
4.02 Active labour market policies (1–7) 2.2 20.5 79 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.0 49.4 69 Switzerland
4.04 Percentage of ﬁrms of fering formal training 65.9 87.9 3 Ecuador
4.05 Digital skills among active population (1–7) 3.4 39.3 77 Finland
- 54.6 70 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 52.5 52.5 69 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 7.3 14.7 64 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 65.7 54.7 62 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 73.9 73.9 81 Multiple (13)
5.05 Rural population with electricity access (%) 83.7 83.7 74 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.9 48.1 62 Singapore
- 69.5 45 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 5.9 76.3 28 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 8.0 68.0 54 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.8 80.8 47 Czech Republic
6.04 Unemployment in rural areas (%) 0.4 98.3 1 Peru
6.05 Ratio of female to male labour force participation rate 82.8 78.4 27 Lao PDR
6.06 Workers in vulnerable employment (%) 50.7 15.5 72 Saudi Arabia
- 37.9 59 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 0.7 98.1 3 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 16.3 7.1 73 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 12.2 5.5 76 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 36.1 31.7 56 Multiple (4)
7.05 Adjusted labour income share (%) 46.1 46.9 59 Switzerland
- 43.6 76 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 73.0 73.0 41 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.0 50.7 70 Singapore
8.03 Pay and productivity (1–7) 3.5 42.1 67 Switzerland
8.04 Employees working more than 48 hours per week (%) 26.4 47.2 58 Bulgaria
8.05 Collective bargaining coverage ratio (%) 5 4.8 62 France
- 29.2 72 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 5.5 21.9 64 Multiple (9)
9.04 Social safety net protection, 1-7 3.2 36.6 73 Norway
- 50.4 61 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 35.0 35.0 63 Denmark
10.02 Government and public services efﬁciency (score) -0.2 47.1 66 Singapore
10.03 Inclusiveness of institutions (score) -0.3 59.1 62 Portugal
10.04 Political stability and protection from violence (score) -0.3 60.4 54 New Zealand

154Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
61st 69th 56th 71st 25th 62nd 52nd 63rd 58th 66th 64th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5256 55
3864 6368
3653
3550
Philippines 61st /82
Index Component Value Score      Rank/ 82 Best Performer
- 56.3 69 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 54.2 45.8 63 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 14.0 71.9 60 Ghana
1.03 Health Access and Quality Index (0–100 best) 51.2 51.2 71 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 56.1 74 Singapore
- 54.8 56 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 64.5 64.5 49 Malta
2.02 Quality of vocational training (1–7) 4.7 62.4 25 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 19.9 33.7 57 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 58.4 59 GermanyPhilippines 61st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %106.6
313.4
3,103.60.71
44.4
5.5

155Philippines 61st /82
Index Component Value Score       Rank/ 82 Best Performer
- 38.3 71 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 27.1 26.4 66 Australia
3.03 Pupils per teacher in primary education 29.1 36.4 74 Multiple (3)
3.04 Pupils per teacher in secondary education 22.4 41.9 62 Armenia
3.05 Harmonized learning outcomes (score) 418.2 54.6 60 Singapore
3.06 Social diversity in schools (score) 66.8 40.6 46 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material70.0 30.0 55 Multiple (2)
- 63.9 25 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.9 65.7 15 Switzerland
4.02 Active labour market policies (1–7) 3.8 46.9 38 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.6 59.4 42 Switzerland
4.04 Percentage of ﬁrms of fering formal training 59.8 79.7 5 Ecuador
4.05 Digital skills among active population (1–7) 5.1 67.7 17 Finland
- 62.6 62 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 60.1 60.1 62 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 3.2 6.5 73 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 68.4 57.0 60 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 93.0 93.0 67 Multiple (13)
5.05 Rural population with electricity access (%) 90.0 90.0 71 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.1 68.8 26 Singapore
- 67.5 52 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 4.5 82.2 23 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 9.0 63.9 60 Thailand
6.02 Unemployment among labor force with advanced education (%) 7.5 70.0 61 Czech Republic
6.04 Unemployment in rural areas (%) 1.8 92.6 7 Peru
6.05 Ratio of female to male labour force participation rate 62.0 52.5 67 Lao PDR
6.06 Workers in vulnerable employment (%) 33.6 44.0 57 Saudi Arabia
- 35.9 63 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 0.0 99.9 1 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 27.6 19.5 68 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 18.5 21.3 68 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 37.4 35.4 55 Multiple (4)
7.05 Adjusted labour income share (%) 26.6 3.6 82 Switzerland
- 52.8 58 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 62.0 62.0 65 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.4 72.6 12 Singapore
8.03 Pay and productivity (1–7) 4.9 64.9 9 Switzerland
8.04 Employees working more than 48 hours per week (%) 18.5 63.0 51 Bulgaria
8.05 Collective bargaining coverage ratio (%) 2 1.6 66 France
- 35.2 66 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 47.1 47.1 45 Multiple (6)
9.03 Social protection spending (% of GDP) 2.2 8.8 76 Multiple (9)
9.04 Social safety net protection, 1-7 4.0 49.8 48 Norway
- 49.6 64 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 36.0 36.0 59 Denmark
10.02 Government and public services efﬁciency (score) 0.0 53.4 52 Singapore
10.03 Inclusiveness of institutions (score) 0.0 67.4 46 Portugal
10.04 Political stability and protection from violence (score) -1.1 41.4 76 New Zealand

156Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

30th
31st
42nd
14th
48th
31st
26th
28th
46th
26th
30th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6982
6682
497975
605869 70
Poland 30th /82
Index Component Value Score      Rank/ 82 Best Performer
- 82.5 31 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 10.5 89.5 30 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.9 78.1 42 Ghana
1.03 Health Access and Quality Index (0–100 best) 82.4 82.4 34 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 79.9 40 Singapore
- 66.2 42 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 79.2 79.2 31 Malta
2.02 Quality of vocational training (1–7) 3.5 42.2 72 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 8.7 71.1 19 Japan
2.04 Out-of-school children (%) 4.4 56.0 53 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 82.5 23 GermanyPoland 30th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %38.0
524.9
15,430.90.90
31.8
3.1

157Poland 30th /82
Index Component Value Score       Rank/ 82 Best Performer
- 81.8 14 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.0 97.1 11 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 14.5 68.3 37 Australia
3.03 Pupils per teacher in primary education 10.7 97.5 6 Multiple (3)
3.04 Pupils per teacher in secondary education 10.0 83.3 13 Armenia
3.05 Harmonized learning outcomes (score) 539.9 85.0 8 Singapore
3.06 Social diversity in schools (score) 78.3 68.3 18 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material27.2 72.8 20 Multiple (2)
- 49.4 48 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.0 49.7 50 Switzerland
4.02 Active labour market policies (1–7) 3.6 43.1 48 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.2 53.4 61 Switzerland
4.04 Percentage of ﬁrms of fering formal training 34.6 46.1 26 Ecuador
4.05 Digital skills among active population (1–7) 4.3 54.5 48 Finland
- 78.6 31 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 77.5 77.5 37 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 18.9 37.7 44 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 171.7 100.0 2 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.4 56.5 49 Singapore
- 75.2 26 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 11.9 52.3 61 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.4 82.4 19 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.0 92.0 7 Czech Republic
6.04 Unemployment in rural areas (%) 4.3 82.8 31 Peru
6.05 Ratio of female to male labour force participation rate 74.7 68.4 46 Lao PDR
6.06 Workers in vulnerable employment (%) 16.1 73.1 39 Saudi Arabia
- 60.0 28 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 21.7 38.1 38 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 72.8 69.7 16 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 37.3 68.2 15 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 50.4 72.7 26 Multiple (4)
7.05 Adjusted labour income share (%) 48.1 51.3 53 Switzerland
- 57.7 46 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 74.0 74.0 40 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.3 55.1 58 Singapore
8.03 Pay and productivity (1–7) 4.2 53.0 43 Switzerland
8.04 Employees working more than 48 hours per week (%) 5.5 89.1 19 Bulgaria
8.05 Collective bargaining coverage ratio (%) 17 17.2 48 France
- 69.2 26 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 61.0 81.3 3 Multiple (2)
9.02 Social protection coverage (% of population) 84.9 84.9 27 Multiple (6)
9.03 Social protection spending (% of GDP) 19.4 77.7 26 Multiple (9)
9.04 Social safety net protection, 1-7 3.0 32.8 78 Norway
- 70.2 30 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 60.0 60.0 26 Denmark
10.02 Government and public services efﬁciency (score) 0.7 66.5 35 Singapore
10.03 Inclusiveness of institutions (score) 0.4 76.1 24 Portugal
10.04 Political stability and protection from violence (score) 0.5 78.1 27 New Zealand

158Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
24th 24th 36th 24th 32nd 30th 36th 41st 15th 17th 15th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7287
6977
6079
74
50707481
Portugal 24th /82
Index Component Value Score      Rank/ 82 Best Performer
- 86.6 24 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 8.4 91.6 26 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 11.2 77.6 46 Ghana
1.03 Health Access and Quality Index (0–100 best) 85.7 85.7 31 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 91.4 16 Singapore
- 69.0 36 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 90.2 90.2 17 Malta
2.02 Quality of vocational training (1–7) 4.3 55.3 41 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 8.4 72.1 17 Japan
2.04 Out-of-school children (%) 3.6 64.0 50 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 63.5 52 GermanyPortugal 24th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %10.3
218.1
23,186.30.24
35.5
0.4

159Portugal 24th /82
Index Component Value Score       Rank/ 82 Best Performer
- 76.9 24 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 3.0 95.7 19 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 16.8 60.8 45 Australia
3.03 Pupils per teacher in primary education 12.7 91.1 17 Multiple (3)
3.04 Pupils per teacher in secondary education 9.2 86.0 10 Armenia
3.05 Harmonized learning outcomes (score) 518.6 79.6 26 Singapore
3.06 Social diversity in schools (score) 76.7 64.4 25 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material39.7 60.3 29 Multiple (2)
- 59.7 32 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.1 50.9 45 Switzerland
4.02 Active labour market policies (1–7) 4.0 50.8 34 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.7 78.2 19 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.5 58.7 39 Finland
- 79.2 30 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 74.7 74.7 40 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 36.9 73.8 16 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 73.8 61.5 55 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.2 99.2 34 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.0 66.1 30 Singapore
- 73.8 36 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.5 62.0 47 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 8.2 67.1 55 Thailand
6.02 Unemployment among labor force with advanced education (%) 5.4 78.5 51 Czech Republic
6.04 Unemployment in rural areas (%) 6.1 75.4 45 Peru
6.05 Ratio of female to male labour force participation rate 84.0 80.0 24 Lao PDR
6.06 Workers in vulnerable employment (%) 12.2 79.6 33 Saudi Arabia
- 50.2 41 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 30.1 14.0 52 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 58.4 53.8 29 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 32.1 55.3 30 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 46.8 62.2 35 Multiple (4)
7.05 Adjusted labour income share (%) 54.5 65.6 27 Switzerland
- 70.3 15 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 90.0 90.0 14 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 58.8 43 Singapore
8.03 Pay and productivity (1–7) 3.7 44.8 61 Switzerland
8.04 Employees working more than 48 hours per week (%) 7.2 85.6 31 Bulgaria
8.05 Collective bargaining coverage ratio (%) 72 72.3 15 France
- 73.7 17 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 34.0 45.3 26 Multiple (2)
9.02 Social protection coverage (% of population) 90.2 90.2 20 Multiple (6)
9.03 Social protection spending (% of GDP) 24.1 96.4 11 Multiple (9)
9.04 Social safety net protection, 1-7 4.8 63.0 28 Norway
- 80.5 15 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 64.0 64.0 24 Denmark
10.02 Government and public services efﬁciency (score) 1.2 78.2 20 Singapore
10.03 Inclusiveness of institutions (score) 0.8 88.8 1 Portugal
10.04 Political stability and protection from violence (score) 1.1 91.2 8 New Zealand

160Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

42nd
48th
58th
50th
44th
45th
27th
15th
40th
39th
56th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6373
5464
5274 75
68
6158
52
Romania 42nd /82
Index Component Value Score      Rank/ 82 Best Performer
- 73.2 48 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 36.2 63.8 54 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.7 78.7 39 Ghana
1.03 Health Access and Quality Index (0–100 best) 78.3 78.3 38 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 72.0 56 Singapore
- 54.2 58 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 74.9 74.9 40 Malta
2.02 Quality of vocational training (1–7) 3.5 42.2 73 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 14.5 51.6 39 Japan
2.04 Out-of-school children (%) 6.9 31.0 59 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 71.4 41 GermanyRomania 42nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %19.5
211.3
12,285.20.38
35.9
2.6

161Romania 42nd /82
Index Component Value Score       Rank/ 82 Best Performer
- 64.0 50 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 14.1 79.9 39 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 15.5 65.1 42 Australia
3.03 Pupils per teacher in primary education 19.3 68.9 54 Multiple (3)
3.04 Pupils per teacher in secondary education 13.3 72.3 39 Armenia
3.05 Harmonized learning outcomes (score) 456.1 64.0 47 Singapore
3.06 Social diversity in schools (score) 70.5 49.4 42 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material51.6 48.4 37 Multiple (2)
- 51.5 44 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.7 44.8 65 Switzerland
4.02 Active labour market policies (1–7) 3.7 45.4 44 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 55.0 54 Switzerland
4.04 Percentage of ﬁrms of fering formal training 40.7 54.3 18 Ecuador
4.05 Digital skills among active population (1–7) 4.5 58.2 41 Finland
- 73.6 45 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 70.7 70.7 49 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 26.1 52.1 39 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 88.0 73.3 37 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 17 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.7 45.4 65 Singapore
- 75.1 27 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 6.6 73.7 32 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.3 82.6 18 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.1 91.4 8 Czech Republic
6.04 Unemployment in rural areas (%) 4.7 81.1 37 Peru
6.05 Ratio of female to male labour force participation rate 70.7 63.4 57 Lao PDR
6.06 Workers in vulnerable employment (%) 25.1 58.1 49 Saudi Arabia
- 68.5 15 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 97.0 96.6 2 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 44.5 86.2 3 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 41.5 47.1 48 Multiple (4)
7.05 Adjusted labour income share (%) 44.8 44.0 62 Switzerland
- 60.5 40 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 73.0 73.0 41 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.3 54.7 61 Singapore
8.03 Pay and productivity (1–7) 3.7 44.6 63 Switzerland
8.04 Employees working more than 48 hours per week (%) 2.3 95.3 5 Bulgaria
8.05 Collective bargaining coverage ratio (%) 35 35.0 32 France
- 58.4 39 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 18.0 24.0 35 Multiple (2)
9.02 Social protection coverage (% of population) 95.0 95.0 14 Multiple (6)
9.03 Social protection spending (% of GDP) 14.8 59.2 42 Multiple (9)
9.04 Social safety net protection, 1-7 4.3 55.4 35 Norway
- 52.2 56 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 47.0 47.0 41 Denmark
10.02 Government and public services efﬁciency (score) -0.3 46.9 67 Singapore
10.03 Inclusiveness of institutions (score) -0.1 62.7 53 Portugal
10.04 Political stability and protection from violence (score) n/a n/a n/a New Zealand

162Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
39th 43rd 31st 32nd 61st 44th 34th 21st 32nd 29th 76th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6575
7075
4674 74
63 6264
43
Russian Federation 39th /82
Index Component Value Score      Rank/ 82 Best Performer
- 75.0 43 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 20.7 79.3 43 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.0 82.0 23 Ghana
1.03 Health Access and Quality Index (0–100 best) 75.1 75.1 44 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 63.7 67 Singapore
- 70.4 31 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 85.0 85.0 26 Malta
2.02 Quality of vocational training (1–7) 4.1 50.9 54 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 12.4 58.6 32 Japan
2.04 Out-of-school children (%) 2.4 76.0 39 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 81.4 26 GermanyRussian Federation 39th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %144.0
1,527.5
11,326.83.12
37.7
1.7

163Russian Federation 39th /82
Index Component Value Score       Rank/ 82 Best Performer
- 75.0 32 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 0.9 98.7 3 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 9.6 84.7 11 Australia
3.03 Pupils per teacher in primary education 21.1 63.0 60 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 540.3 85.1 7 Singapore
3.06 Social diversity in schools (score) 80.6 73.8 14 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material55.0 45.0 43 Multiple (2)
- 46.1 61 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.9 48.7 52 Switzerland
4.02 Active labour market policies (1–7) 3.6 44.0 46 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.4 56.3 49 Switzerland
4.04 Percentage of ﬁrms of fering formal training 11.8 15.7 46 Ecuador
4.05 Digital skills among active population (1–7) 4.9 65.8 21 Finland
- 73.6 44 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 80.9 80.9 31 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 22.2 44.4 41 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 87.3 72.7 39 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 78.0 78.0 77 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.9 65.8 31 Singapore
- 74.0 34 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 13.5 46.0 65 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.2 83.1 16 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.8 80.8 46 Czech Republic
6.04 Unemployment in rural areas (%) 7.4 70.6 49 Peru
6.05 Ratio of female to male labour force participation rate 77.8 72.3 41 Lao PDR
6.06 Workers in vulnerable employment (%) 5.2 91.3 5 Saudi Arabia
- 63.0 21 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 72.5 69.4 17 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 36.2 65.4 18 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 45.0 57.2 37 Multiple (4)
7.05 Adjusted labour income share (%) 52.0 60.0 39 Switzerland
- 62.3 32 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 77.0 77.0 38 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.4 56.5 54 Singapore
8.03 Pay and productivity (1–7) 4.5 58.9 28 Switzerland
8.04 Employees working more than 48 hours per week (%) 1.9 96.2 4 Bulgaria
8.05 Collective bargaining coverage ratio (%) 23 22.8 43 France
- 64.3 29 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 90.1 90.1 21 Multiple (6)
9.03 Social protection spending (% of GDP) 15.6 62.2 40 Multiple (9)
9.04 Social safety net protection, 1-7 3.4 40.7 63 Norway
- 43.0 76 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 28.0 28.0 78 Denmark
10.02 Government and public services efﬁciency (score) -0.1 51.0 59 Singapore
10.03 Inclusiveness of institutions (score) -1.1 37.8 79 Portugal
10.04 Political stability and protection from violence (score) -0.5 55.0 63 New Zealand

164Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

52nd
45th
60th
49th
17th
39th
55th
70th
71st
54th
60th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5773
53646876
66
30464451
Saudi Arabia 52nd /82
Index Component Value Score      Rank/ 82 Best Performer
- 73.4 45 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.3 92.7 18 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 24.4 51.3 81 Ghana
1.03 Health Access and Quality Index (0–100 best) 74.9 74.9 45 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 74.9 50 Singapore
- 53.4 60 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 19.7 19.7 66 Malta
2.02 Quality of vocational training (1–7) 4.6 60.2 29 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 16.1 46.3 44 Japan
2.04 Out-of-school children (%) 2.5 75.0 42 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 66.0 49 GermanySaudi Arabia 52nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
10-year average annual GDP growth %33.2
683.8
23,566.41.37
3.3

165Saudi Arabia 52nd /82
Index Component Value Score       Rank/ 82 Best Performer
- 64.2 49 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 36.7 47.6 49 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 15.0 66.5 39 Australia
3.03 Pupils per teacher in primary education 13.8 87.3 26 Multiple (3)
3.04 Pupils per teacher in secondary education 11.4 78.6 24 Armenia
3.05 Harmonized learning outcomes (score) 436.4 59.1 54 Singapore
3.06 Social diversity in schools (score) 75.1 60.6 33 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material50.5 49.5 36 Multiple (2)
- 67.5 17 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.6 60.5 26 Switzerland
4.02 Active labour market policies (1–7) 4.8 64.1 17 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.4 73.2 28 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.3 72.1 12 Finland
- 75.7 39 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 93.3 93.3 8 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 5.6 11.3 68 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 111.1 92.6 16 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.1 98.1 47 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.5 59.0 45 Singapore
- 66.2 55 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 1.2 95.3 3 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 7.1 71.5 48 Thailand
6.02 Unemployment among labor force with advanced education (%) 10.6 57.4 66 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 29.5 11.9 82 Lao PDR
6.06 Workers in vulnerable employment (%) 3.0 95.1 1 Saudi Arabia
- 29.6 70 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 41.5 35.0 52 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 25.8 39.4 48 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 31.5 14.4 79 Switzerland
- 45.9 71 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 10.0 10.0 74 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.1 68.0 18 Singapore
8.03 Pay and productivity (1–7) 5.0 65.9 6 Switzerland
8.04 Employees working more than 48 hours per week (%) 30.2 39.6 66 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 43.9 54 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 3.6 14.6 73 Multiple (9)
9.04 Social safety net protection, 1-7 5.4 73.3 15 Norway
- 50.7 60 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 49.0 49.0 39 Denmark
10.02 Government and public services efﬁciency (score) 0.3 59.2 46 Singapore
10.03 Inclusiveness of institutions (score) -1.0 40.0 78 Portugal
10.04 Political stability and protection from violence (score) -0.5 54.7 64 New Zealand

166Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

81st
80th
81st
79th
79th
78th
74th
80th
81st
74th
43rd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions3646
1928384348
939
2861
Senegal 81st /82
Index Component Value Score      Rank/ 82 Best Performer
- 45.7 80 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 72.7 27.3 76 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 11.1 77.8 45 Ghana
1.03 Health Access and Quality Index (0–100 best) 31.1 31.1 81 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 46.5 77 Singapore
- 18.9 81 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 14.6 14.6 68 Malta
2.02 Quality of vocational training (1–7) 4.6 60.4 28 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 36.2 0.0 76 Japan
2.04 Out-of-school children (%) 25.7 0.0 69 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.2 19.7 81 GermanySenegal 81st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %16.3
16.5
1,473.80.04
40.3
4.4

167Senegal 81st /82
Index Component Value Score       Rank/ 82 Best Performer
- 28.2 79 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 65.2 6.9 64 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 29.8 17.3 70 Australia
3.03 Pupils per teacher in primary education 36.3 12.3 78 Multiple (3)
3.04 Pupils per teacher in secondary education 19.3 52.5 58 Armenia
3.05 Harmonized learning outcomes (score) 408.2 52.1 62 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 38.4 79 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.2 74 Switzerland
4.02 Active labour market policies (1–7) 2.5 25.0 72 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.8 47.3 75 Switzerland
4.04 Percentage of ﬁrms of fering formal training 17.4 23.2 42 Ecuador
4.05 Digital skills among active population (1–7) 4.2 53.4 55 Finland
- 43.5 78 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 46.0 46.0 72 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 0.8 1.6 78 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 41.5 34.6 76 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 92.2 92.2 68 Multiple (13)
5.05 Rural population with electricity access (%) 35.4 35.4 81 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.1 51.0 56 Singapore
- 47.9 74 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 8.4 66.4 38 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 11.2 55.2 69 Thailand
6.02 Unemployment among labor force with advanced education (%) 17.8 28.7 78 Czech Republic
6.04 Unemployment in rural areas (%) 3.3 86.7 22 Peru
6.05 Ratio of female to male labour force participation rate 60.3 50.3 69 Lao PDR
6.06 Workers in vulnerable employment (%) 64.8 0.0 77 Saudi Arabia
- 9.3 80 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 14.0 4.5 77 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 12.7 6.7 75 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 32.5 16.7 78 Switzerland
- 39.2 81 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 69.0 69.0 52 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.4 57.3 51 Singapore
8.03 Pay and productivity (1–7) 3.4 40.0 75 Switzerland
8.04 Employees working more than 48 hours per week (%) 50.3 0.0 74 Bulgaria
8.05 Collective bargaining coverage ratio (%) 30 29.8 36 France
- 28.2 74 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 5.3 21.3 67 Multiple (9)
9.04 Social safety net protection, 1-7 3.1 35.0 75 Norway
- 60.6 43 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 45.0 45.0 44 Denmark
10.02 Government and public services efﬁciency (score) -0.3 46.6 69 Singapore
10.03 Inclusiveness of institutions (score) 0.8 86.5 2 Portugal
10.04 Political stability and protection from violence (score) -0.1 64.1 51 New Zealand

168Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

41st
38th
44th
37th
52nd
52nd
68th
23rd
33rd
28th
47th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6478
6374
4868
5661 6267
59
Serbia 41st /82
Index Component Value Score      Rank/ 82 Best Performer
- 78.0 38 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 14.7 85.3 38 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 11.9 76.1 49 Ghana
1.03 Health Access and Quality Index (0–100 best) 77.2 77.2 41 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 73.4 52 Singapore
- 63.5 44 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 61.9 61.9 52 Malta
2.02 Quality of vocational training (1–7) 3.9 48.7 57 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 17.0 43.4 47 Japan
2.04 Out-of-school children (%) 0.8 92.0 19 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 71.4 41 GermanySerbia 41st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %7.0
41.5
7,243.40.09
39.6
1.5

169Serbia 41st /82
Index Component Value Score       Rank/ 82 Best Performer
- 74.2 37 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 7.4 89.4 33 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 11.6 77.9 18 Australia
3.03 Pupils per teacher in primary education 14.3 85.7 27 Multiple (3)
3.04 Pupils per teacher in secondary education 8.1 89.6 7 Armenia
3.05 Harmonized learning outcomes (score) 522.8 80.7 23 Singapore
3.06 Social diversity in schools (score) 76.6 64.1 27 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material68.3 31.7 52 Multiple (2)
- 48.3 52 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.6 69 Switzerland
4.02 Active labour market policies (1–7) 3.5 41.1 51 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 54.8 57 Switzerland
4.04 Percentage of ﬁrms of fering formal training 37.8 50.4 21 Ecuador
4.05 Digital skills among active population (1–7) 4.1 51.5 60 Finland
- 68.1 52 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 73.4 73.4 44 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 16.8 33.5 46 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 60.7 50.6 65 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.7 98.7 45 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.2 52.7 53 Singapore
- 56.4 68 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 10.9 56.4 56 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 13.7 45.1 73 Thailand
6.02 Unemployment among labor force with advanced education (%) 10.8 56.7 68 Czech Republic
6.04 Unemployment in rural areas (%) 10.9 56.3 60 Peru
6.05 Ratio of female to male labour force participation rate 75.3 69.2 44 Lao PDR
6.06 Workers in vulnerable employment (%) 27.0 55.0 53 Saudi Arabia
- 61.4 23 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 78.0 75.5 11 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 38.7 71.8 12 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 38.0 37.1 53 Multiple (4)
7.05 Adjusted labour income share (%) 52.5 61.1 36 Switzerland
- 62.2 33 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 69.0 69.0 52 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.1 51.4 69 Singapore
8.03 Pay and productivity (1–7) 4.0 49.6 51 Switzerland
8.04 Employees working more than 48 hours per week (%) 7.1 85.8 30 Bulgaria
8.05 Collective bargaining coverage ratio (%) 55 55.0 24 France
- 66.5 28 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 23.4 93.6 13 Multiple (9)
9.04 Social safety net protection, 1-7 3.4 39.4 66 Norway
- 59.2 47 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 39.0 39.0 54 Denmark
10.02 Government and public services efﬁciency (score) 0.1 54.7 51 Singapore
10.03 Inclusiveness of institutions (score) 0.3 75.2 28 Portugal
10.04 Political stability and protection from violence (score) 0.1 67.9 45 New Zealand

170Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
20th 7th 8th 4th 3rd 15th 8th 51st 21st 61st 5th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7591
8486
7887
82
4567
3987
Singapore 20th /82
Index Component Value Score      Rank/ 82 Best Performer
- 91.5 7 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 3.5 96.5 3 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.3 81.4 29 Ghana
1.03 Health Access and Quality Index (0–100 best) 90.6 90.6 21 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 97.4 1 Singapore
- 83.7 8 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 5.4 73.3 6 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 4.1 86.2 2 Japan
2.04 Out-of-school children (%) 0.1 99.0 6 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 76.4 33 GermanySingapore 20th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
10-year average annual GDP growth %5.6
323.9
64,041.40.42
4.6

171Singapore 20th /82
Index Component Value Score       Rank/ 82 Best Performer
- 85.8 4 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.7 96.1 16 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 14.7 84.4 29 Multiple (3)
3.04 Pupils per teacher in secondary education 11.6 78.0 26 Armenia
3.05 Harmonized learning outcomes (score) 584.6 96.2 1 Singapore
3.06 Social diversity in schools (score) 74.9 60.1 34 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material0.0 100.0 1 Multiple (2)
- 78.2 3 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.4 73.3 4 Switzerland
4.02 Active labour market policies (1–7) 5.5 75.5 3 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.3 87.5 4 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.6 76.4 5 Finland
- 87.4 15 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 88.2 88.2 17 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 25.9 51.8 40 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 145.7 100.0 5 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 6.1 84.5 1 Singapore
- 81.8 8 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.5 85.9 17 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.6 81.5 24 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.1 83.5 39 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 79.3 74.2 36 Lao PDR
6.06 Workers in vulnerable employment (%) 9.7 83.8 23 Saudi Arabia
- 45.1 51 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 48.0 42.2 39 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 25.7 39.2 49 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 49.2 53.8 48 Switzerland
- 66.7 21 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 89.0 89.0 18 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 6.1 85.3 1 Singapore
8.03 Pay and productivity (1–7) 5.5 74.6 2 Switzerland
8.04 Employees working more than 48 hours per week (%) n/a n/a n/a Bulgaria
8.05 Collective bargaining coverage ratio (%) 18 18.1 47 France
- 38.6 61 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 4.2 16.6 70 Multiple (9)
9.04 Social safety net protection, 1-7 4.6 60.6 30 Norway
- 87.5 5 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 85.0 85.0 3 Denmark
10.02 Government and public services efﬁciency (score) 2.2 100.0 1 Singapore
10.03 Inclusiveness of institutions (score) 0.0 65.5 51 Portugal
10.04 Political stability and protection from violence (score) 1.5 99.3 2 New Zealand

172Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
32nd 36th 33rd 48th 35th 33rd 58th 5th 26th 32nd 35th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6879
6965
5678
6478
656367
Slovak Republic 32nd /82
Index Component Value Score      Rank/ 82 Best Performer
- 79.3 36 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 25.7 74.3 49 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.3 81.5 28 Ghana
1.03 Health Access and Quality Index (0–100 best) 83.3 83.3 33 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 78.0 43 Singapore
- 69.2 33 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 75.4 75.4 37 Malta
2.02 Quality of vocational training (1–7) 3.6 43.9 69 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 10.2 66.0 26 Japan
2.04 Out-of-school children (%) 2.1 79.0 35 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 81.9 24 GermanySlovak Republic 32nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %5.4
95.9
19,581.60.14
26.5
2.8

173Slovak Republic 32nd /82
Index Component Value Score       Rank/ 82 Best Performer
- 65.4 48 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 6.6 90.6 32 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.0 76.7 21 Australia
3.03 Pupils per teacher in primary education 17.4 75.3 49 Multiple (3)
3.04 Pupils per teacher in secondary education 13.6 71.5 44 Armenia
3.05 Harmonized learning outcomes (score) 502.9 75.7 38 Singapore
3.06 Social diversity in schools (score) 63.0 31.4 53 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material63.2 36.8 49 Multiple (2)
- 56.5 35 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.1 51.7 43 Switzerland
4.02 Active labour market policies (1–7) 4.1 51.2 33 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.7 61.8 37 Switzerland
4.04 Percentage of ﬁrms of fering formal training 43.5 58.0 14 Ecuador
4.05 Digital skills among active population (1–7) 4.6 59.8 37 Finland
- 77.7 33 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 80.7 80.7 33 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 27.7 55.3 34 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 86.0 71.7 41 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.0 95.0 58 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.8 63.4 36 Singapore
- 64.0 58 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 29.8 0.0 80 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.8 76.9 35 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.1 87.7 20 Czech Republic
6.04 Unemployment in rural areas (%) 8.4 66.6 50 Peru
6.05 Ratio of female to male labour force participation rate 78.3 72.9 38 Lao PDR
6.06 Workers in vulnerable employment (%) 11.9 80.2 32 Saudi Arabia
- 77.8 5 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 18.6 46.8 30 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 102.3 100.0 1 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 46.7 91.7 1 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 57.4 92.6 8 Multiple (4)
7.05 Adjusted labour income share (%) 51.0 57.8 43 Switzerland
- 64.6 26 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 100.0 100.0 1 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.2 53.0 65 Singapore
8.03 Pay and productivity (1–7) 4.2 53.6 40 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.3 91.4 12 Bulgaria
8.05 Collective bargaining coverage ratio (%) 25 25.0 41 France
- 63.0 32 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 22.0 29.3 33 Multiple (2)
9.02 Social protection coverage (% of population) 92.1 92.1 19 Multiple (6)
9.03 Social protection spending (% of GDP) 19.4 77.6 27 Multiple (9)
9.04 Social safety net protection, 1-7 4.2 52.7 41 Norway
- 67.1 35 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 50.0 50.0 38 Denmark
10.02 Government and public services efﬁciency (score) 0.7 67.4 34 Singapore
10.03 Inclusiveness of institutions (score) 0.1 68.5 43 Portugal
10.04 Political stability and protection from violence (score) 0.8 82.6 24 New Zealand

174Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

13th
20th
22nd
21st
27th
32nd
19th
4th
19th
11th
18th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7688
77 77
6278 78 79
687977
Slovenia 13th /82
Index Component Value Score      Rank/ 82 Best Performer
- 88.4 20 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 3.8 96.2 4 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.4 79.3 37 Ghana
1.03 Health Access and Quality Index (0–100 best) 90.8 90.8 20 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 87.1 27 Singapore
- 77.0 22 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 88.9 88.9 18 Malta
2.02 Quality of vocational training (1–7) 4.2 53.5 47 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 6.6 77.9 11 Japan
2.04 Out-of-school children (%) 2.2 78.0 36 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 86.6 13 GermanySlovenia 13th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %2.1
48.9
26,234.30.06
25.4
1.5

175Slovenia 13th /82
Index Component Value Score       Rank/ 82 Best Performer
- 77.3 21 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 3.7 94.7 23 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 9.1 86.2 7 Australia
3.03 Pupils per teacher in primary education 14.5 85.2 28 Multiple (3)
3.04 Pupils per teacher in secondary education 14.1 69.8 46 Armenia
3.05 Harmonized learning outcomes (score) 537.9 84.5 11 Singapore
3.06 Social diversity in schools (score) 75.5 61.5 31 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material41.0 59.0 33 Multiple (2)
- 62.3 27 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.5 58.4 30 Switzerland
4.02 Active labour market policies (1–7) 4.6 59.3 24 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.5 74.9 26 Switzerland
4.04 Percentage of ﬁrms of fering formal training 41.5 55.3 17 Ecuador
4.05 Digital skills among active population (1–7) 4.8 63.8 28 Finland
- 78.3 32 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 79.7 79.7 34 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 29.5 59.0 27 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 77.7 64.7 47 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.5 99.5 29 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.0 66.7 29 Singapore
- 77.7 19 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 10.9 56.4 55 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.5 78.1 30 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.6 85.5 29 Czech Republic
6.04 Unemployment in rural areas (%) 4.6 81.7 35 Peru
6.05 Ratio of female to male labour force participation rate 85.3 81.6 15 Lao PDR
6.06 Workers in vulnerable employment (%) 10.4 82.6 26 Saudi Arabia
- 78.9 4 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 19.2 45.1 31 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 94.1 93.4 5 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 42.8 82.0 6 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 60.2 100.0 3 Multiple (4)
7.05 Adjusted labour income share (%) 58.4 74.2 16 Switzerland
- 67.8 19 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) n/a n/a n/a Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.6 59.4 40 Singapore
8.03 Pay and productivity (1–7) 4.1 51.8 47 Switzerland
8.04 Employees working more than 48 hours per week (%) 5.5 88.9 20 Bulgaria
8.05 Collective bargaining coverage ratio (%) 71 70.9 16 France
- 79.4 11 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 46.0 61.3 11 Multiple (2)
9.02 Social protection coverage (% of population) 100.0 100.0 1 Multiple (6)
9.03 Social protection spending (% of GDP) 22.4 89.4 16 Multiple (9)
9.04 Social safety net protection, 1-7 5.0 66.9 23 Norway
- 76.6 18 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 60.0 60.0 26 Denmark
10.02 Government and public services efﬁciency (score) 1.1 76.4 25 Singapore
10.03 Inclusiveness of institutions (score) 0.7 83.9 5 Portugal
10.04 Political stability and protection from violence (score) 0.9 86.2 19 New Zealand

176Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
77th 78th 80th 80th 67th 69th 80th 73rd 59th 55th 40th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4148
27234356
35
2653
4461
South Africa 77th /82
Index Component Value Score      Rank/ 82 Best Performer
- 48.1 78 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 67.9 32.1 72 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 16.0 68.0 66 Ghana
1.03 Health Access and Quality Index (0–100 best) 49.7 49.7 72 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 42.5 78 Singapore
- 26.5 80 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 14.9 14.9 67 Malta
2.02 Quality of vocational training (1–7) 3.5 41.0 76 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 31.6 0.0 73 Japan
2.04 Out-of-school children (%) 8.4 16.0 63 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 60.7 54 GermanySouth Africa 77th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %57.7
349.3
6,377.30.58
63.0
1.6

177South Africa 77th /82
Index Component Value Score       Rank/ 82 Best Performer
- 22.9 80 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 77.9 0.0 70 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 29.6 17.9 69 Australia
3.03 Pupils per teacher in primary education 30.3 32.2 76 Multiple (3)
3.04 Pupils per teacher in secondary education 27.6 24.8 68 Armenia
3.05 Harmonized learning outcomes (score) 358.8 39.7 77 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 43.1 67 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.5 58.0 33 Switzerland
4.02 Active labour market policies (1–7) 2.5 24.9 73 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.1 51.6 62 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 3.3 37.9 79 Finland
- 56.0 69 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 56.2 56.2 67 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 2.4 4.8 75 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 76.0 63.3 51 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.5 99.5 28 Multiple (13)
5.05 Rural population with electricity access (%) 66.9 66.9 77 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.7 45.2 66 Singapore
- 34.7 80 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 33.3 0.0 81 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 28.5 0.0 82 Thailand
6.02 Unemployment among labor force with advanced education (%) 12.0 51.9 70 Czech Republic
6.04 Unemployment in rural areas (%) 30.1 0.0 66 Peru
6.05 Ratio of female to male labour force participation rate 77.9 72.4 40 Lao PDR
6.06 Workers in vulnerable employment (%) 9.7 83.8 22 Saudi Arabia
- 26.0 73 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 32.4 7.4 54 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 34.0 26.7 57 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 22.4 31.0 59 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 17.8 0.0 67 Multiple (4)
7.05 Adjusted labour income share (%) 54.1 64.7 29 Switzerland
- 52.5 59 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 86.0 86.0 23 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.2 36.4 82 Singapore
8.03 Pay and productivity (1–7) 3.8 46.0 59 Switzerland
8.04 Employees working more than 48 hours per week (%) 17.9 64.2 50 Bulgaria
8.05 Collective bargaining coverage ratio (%) 30 29.9 35 France
- 43.7 55 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 48.0 48.0 43 Multiple (6)
9.03 Social protection spending (% of GDP) 10.1 40.6 54 Multiple (9)
9.04 Social safety net protection, 1-7 3.6 42.6 59 Norway
- 60.8 40 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 43.0 43.0 46 Denmark
10.02 Government and public services efﬁciency (score) 0.3 59.6 44 Singapore
10.03 Inclusiveness of institutions (score) 0.5 80.6 14 Portugal
10.04 Political stability and protection from violence (score) -0.3 60.0 56 New Zealand

178Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

28th
18th
27th
35th
34th
24th
72nd
29th
12th
18th
31st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7090
7274
5783
5060717470
Spain 28th /82
Index Component Value Score      Rank/ 82 Best Performer
- 89.7 18 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.7 92.3 23 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 11.1 77.8 44 Ghana
1.03 Health Access and Quality Index (0–100 best) 91.9 91.9 18 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 97.0 3 Singapore
- 72.3 27 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 92.2 92.2 15 Malta
2.02 Quality of vocational training (1–7) 4.5 58.5 34 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 12.4 58.5 33 Japan
2.04 Out-of-school children (%) 1.5 85.0 31 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 67.1 48 GermanySpain 28th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %46.4
1,314.0
30,697.31.38
36.2
0.8

179Spain 28th /82
Index Component Value Score       Rank/ 82 Best Performer
- 74.4 35 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 3.4 95.1 22 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 14.4 68.8 35 Australia
3.03 Pupils per teacher in primary education 13.6 87.8 24 Multiple (3)
3.04 Pupils per teacher in secondary education 10.7 81.1 20 Armenia
3.05 Harmonized learning outcomes (score) 513.4 78.4 31 Singapore
3.06 Social diversity in schools (score) 75.8 62.2 29 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material53.0 47.0 40 Multiple (2)
- 56.6 34 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.9 48.1 56 Switzerland
4.02 Active labour market policies (1–7) 3.9 48.4 37 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.4 74.1 27 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.3 55.7 47 Finland
- 82.6 24 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 86.1 86.1 21 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 32.0 64.1 22 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 98.5 82.1 24 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.7 99.7 24 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.8 63.9 35 Singapore
- 50.4 72 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 24.5 1.9 79 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 15.5 38.1 75 Thailand
6.02 Unemployment among labor force with advanced education (%) 8.9 64.4 65 Czech Republic
6.04 Unemployment in rural areas (%) 15.1 39.4 64 Peru
6.05 Ratio of female to male labour force participation rate 81.8 77.2 29 Lao PDR
6.06 Workers in vulnerable employment (%) 11.3 81.1 31 Saudi Arabia
- 59.9 29 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 16.7 52.3 27 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 62.4 58.2 24 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 32.3 55.8 28 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 43.5 52.8 44 Multiple (4)
7.05 Adjusted labour income share (%) 61.2 80.4 7 Switzerland
- 71.1 12 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 79.0 79.0 34 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.4 57.2 52 Singapore
8.03 Pay and productivity (1–7) 3.7 44.3 64 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.3 91.4 13 Bulgaria
8.05 Collective bargaining coverage ratio (%) 84 83.6 8 France
- 73.6 18 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 27.0 36.0 32 Multiple (2)
9.02 Social protection coverage (% of population) 80.9 80.9 29 Multiple (6)
9.03 Social protection spending (% of GDP) 25.4 100.0 9 Multiple (9)
9.04 Social safety net protection, 1-7 5.6 77.4 12 Norway
- 69.9 31 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 58.0 58.0 31 Denmark
10.02 Government and public services efﬁciency (score) 1.0 73.7 30 Singapore
10.03 Inclusiveness of institutions (score) 0.4 76.2 23 Portugal
10.04 Political stability and protection from violence (score) 0.3 71.7 40 New Zealand

180Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

59th
49th
55th
46th
49th
71st
56th
66th
73rd
65th
66th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5273
5566
495365
3344
3549
Sri Lanka 59th /82
Index Component Value Score      Rank/ 82 Best Performer
- 72.8 49 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 20.9 79.1 44 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 19.7 60.5 75 Ghana
1.03 Health Access and Quality Index (0–100 best) 70.6 70.6 51 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 80.9 36 Singapore
- 55.2 55 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 4.3 54.8 42 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 27.1 9.7 65 Japan
2.04 Out-of-school children (%) 0.9 91.0 20 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 65.3 51 GermanySri Lanka 59th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %21.7
87.6
4,067.90.22
39.8
4.8