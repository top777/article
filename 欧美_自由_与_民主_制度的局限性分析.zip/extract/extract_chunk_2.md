31talent development that is lifelong and blended with careers. 
Beyond compulsory education, education systems 
must also provide continuous learning and skill development 
opportunities for adults and remove barriers to adult education 
by targeting financial assistance to those most in need.68
Enhancing Social 
Protection
Traditionally, policy has been focused overwhelmingly on 
legislating to protect and promote full-time permanent jobs. 
In high-income economies this focus persists even as non-
standard work increases without recourse to similar benefits 
and protections. Low- and middle-income economies have 
focused on promoting formal work, formalizing employment 
in line with development objectives. Today, however, there 
needs to be a change of policy mindset that focuses on 
protecting people rather than jobs.
A policy programme that looks holistically at the 
protections and support that individuals need throughout 
their working lives, regardless of their status, is likely to be 
more effective in the current context. As globalization and 
digitalization continue to reshape work, policy-makers are 
challenged to facilitate more flexible work relationships and job 
transitions without sacrificing rights. Such a move away from 
policies promoting job security in isolation towards dynamic 
work security is necessary to support the resilience of workers 
and labour markets.69 Previous attempts to liberalize labour 
markets to increase opportunities for freelance work have often 
kept the legal status of standard jobs largely unchanged. This 
can create an incentive for employers to offer more ‘atypical’ 
work, and has widened the gap in rights and social support 
offered between those in full-time standard employment and 
those in non-standard employment. Similarly, policy targeted 
at specific categories of jobs—for example, legislation to 
restrict the operation of digital labour platforms or to create a 
new status of worker—may also prove to be time-limited as 
work continues to transform. 
Facilitating effective transitions into and within changing 
labour markets will be a major determinant of an economy’s 
and society’s success. One recent estimate suggests that 
75 million people worldwide will need to switch occupations 
by 2030 in selected developed and emerging markets.70 
In addition, there is an ongoing need to integrate workers 
following periods of inactivity such as long-term care 
responsibilities, protracted unemployment or migration. 
Enabling positive transitions should become a significant 
short-term mission of labour policy, essential for inclusion 
and for meeting changing demands for talent. Meeting this 
challenge will require labour policy that takes account of the 
broader mission and adopts a cross-domain, collaborative 
approach, bringing in initiatives from other areas of policy, 
including education, social protection and public services.Reforming Taxation and the 
Mix of Public Spending
Many policies designed to address social mobility require 
both additional public resources through taxation and a 
different mix of public spending on the key elements that help 
address inequalities of opportunities. 
The top marginal personal income tax rate has tended 
to decline in both developed and developing countries over 
the past few decades. Corporate income taxes, too, have 
also fallen since 1990 in both developed and developing 
countries. From the perspective of fiscal effort, many 
countries have the scope to increase redistribution by 
increasing tax revenues. A recent study on whether personal 
income tax rates are optimal for maximizing revenues found 
that tax rates were significantly below optimal levels in all the 
countries examined, implying that they could raise tax rates 
and still increase revenue.71
In addition to income taxes, policies that affect wealth 
accumulation are also an important tool for enhancing social 
mobility. Wealth influences intergenerational mobility, as 
parents often use their wealth to support their children by 
investing in their education or by transmitting part of their 
wealth to their children. However, wealth is much more 
unequally distributed than income, and wealth deprivation 
often goes hand in hand with income poverty. Wealth 
inequality is therefore likely to entrench social immobility. 
Wealth taxes are another potential lever to both increase 
revenue and lower inequality. The advantage of taxing 
wealth is that the most privileged can own a lot of wealth 
while reporting little taxable income. Wealth taxation has 
an important role to play in addressing the rise of wealth 
concentration and could help to restore tax progressivity 
among the top of the distribution. 
In addition to progressivity of taxes, progressivity of 
expenditure is an important lever to promote social mobility. 
Fiscal policy can maximize the impact of redistribution 
through careful design of how resources are allocated to 
different groups, geographical areas and types of spending. 
Fiscal policy should therefore tilt towards greater spending on 
disadvantaged groups and communities and areas, through 
more direct and in-kind transfers and targeted programmes. 
Finally, when it comes to corporate taxes, solutions need 
to consider the complexity of international tax architecture, 
the increasing importance of intangible assets and the digital 
economy that allows for greater profit-shifting opportunities 
by multinationals. In this context, it has proven harder to 
enforce high tax rates on corporate income as demonstrated 
by decreasingly effective tax rates and a higher share of 
corporate profits generated in tax havens. Against this 
backdrop, greater international coordination is essential.

32The Role of Businesses 
Businesses of all sizes, as societal stakeholders, face risks 
from systemic challenges, including inequality, social unrest 
and climate change. As employers, purchasers, investors 
and providers of goods and services, businesses have a 
critical role in promoting social mobility. 
There is not only a moral imperative but also an 
economic rationale for companies to contribute to creating 
opportunities for all and ultimately more equitable societies. 
More inclusive businesses can rely on a more educated, 
engaged and diverse workforce that drives innovation; are 
more representative of and better able to understand their 
customers; and can foster a corporate culture of acceptance 
and respect from customers and stakeholders. Overall, it has 
been shown that companies putting purpose over profits 
perform better in the long run.  
As employers, businesses can contribute to facilitating 
youth access to working life—for example, by enrolling more 
young people into vocational and education training (VET) 
schemes. This would typically imply hiring apprentices and 
providing them with on-the-job training and, often, a minimal 
wage. It is widely acknowledged that VET programmes 
represent effective routes into professional life and a real 
alternative to the graduate track. 
Businesses should promote a culture of meritocracy 
based on performance, aptitude, potential and interest, and 
prevent any form of discrimination when hiring, developing 
and promoting talent. Blind interviews, training for hiring 
and recruitment managers, and CV anonymisation—
typically by omitting name, age and location of the 
candidates—can support this effort. For graduates, 
businesses should expand their pool of candidates to 
beyond a country’s top universities and outside traditional 
networks. While labour institutions typically set the minimal standards 
for wages, businesses have extensive leeway in setting wages and benefits beyond those. In addition, the minimum wage, does not always correspond to the living wage and can be significantly lower. Paying fair wages that allow 
employees to meet their basic needs is an effective way to 
combat vulnerable employment and contributes to upward social mobility. In addition, eliminating the gender pay gap enhances women’s economic empowerment and increases social mobility. Even where equal pay is a legal obligation, 
enforcement is too often lax or the notion of ‘equality’ applied 
loosely. Whether or not there is a legal obligation to do so, 
businesses should spontaneously, systematically and strictly 
apply gender pay equality. 
Across industries, employees from disadvantaged 
backgrounds are disproportionately represented in 
occupations vulnerable to technological innovation (automation and AI) and globalization. By providing adequate on-the-job training, employers can ensure that employees in roles set to become redundant are retained. In addition, reskilling and upskilling are likely to make employees more productive and their income should therefore increase commensurately, which is positive for social mobility. To 
encourage and reward companies’ efforts, governments 
should consider providing incentives such as tax credits for investment in significant and meaningful training programmes. These credits could compensate (at least partly) for training costs and time off. Finally, companies ‘practicing’ social mobility should incentivize and support the same from their suppliers along the value chain—and encourage their peers to follow their lead.

33Notes 
1. Schwab, 2016.
2. World Bank, 2018. 
3. Solt, 2019.
4. Schulz, 2015, https://www.tandfonline.com/doi/
full/10.1080/14616696.2015.1072228.
5. Blanchard and Giavazzi, 2003.
6. Sherman, 2009.
7. Piketty, 2014, and Zucman, 2014.
8. Schwab, 2016.
9. https://wol.iza.org/uploads/articles/176/pdfs/intergenerational-income-persistence.pdf.
10. Based on Intergenerational income Elasticity Data from the Global Database on Intergenerational Mobility, World Bank. 
11. OECD, 2018c.
12. Ibid.
13. OECD, 2018c.
14. https://en.wikipedia.org/wiki/Gini_coefficient.
15. Rawls, 1971, and Sen, 1985.
16. World Economic Forum, 2019c.
17. Ibid. 
18. Sutton Trust, Boston Consulting Group estimates, 2010 .
19. Aiyar and Ebeke, 2019. 
20. ILO, 2019.
21. Economic Policy Institute analysis of Kopczuk, Saez, and Song (2010, Table A3) and Social Security Administration wage statistics.
22. Reijnders and de Vries, 2017.
23. Autor, et al., 2010.
24. Van Reenen, Case, et al., 2003, and Bajgar, et al, 2019.
25. Fehr and Fischbacher, 2003.
26. Corak, 2012. 
27. Ferreira, 2001.
28. World Bank, 2018a.
29. Sen, 1985.
30. Chetty, 2016.
31. Blanpain, 2018.
32. OECD 2018a.
33. Case, et al., 2005.
34. Bilingsley, 2019.
35. Case, et al., 2005.
36. D’Addio 2008, Blanden, et al., 2004, Breen and Jonsson, 2005, and Esping-Andersen, 2015.
37. For more information http://1000days.unicef.ph/
38. Heckman, et al., 2004.
39. Council of Europe, 2011.
40. For a description of such policies and their outcomes see OECD, 2018a, World Bank, 2018a, and Ludwinek, et al, 2017.
41. Chetty, et al., 2014.42. World Economic Forum, 2018.
43. OECD, 2018a.
44. World Bank, 2018a.
45. World Economic Forum, 2018.
46. Ibid.
47. Kalleberg, 2018.
48. Nunn, et al, 2007.
49. OECD, 2018.
50. Bellet, et al, 2019. 
51. Heider, 1946, Kramer, 1999, Parigi, et al., 2017, and Abrahao, et al, 2017.
52. Salganik, et al., 2006, Van de Rijt, et al., 2014, and Sauder, et al,. 2012.
53. The Network Trends Survey had an n=2,007 U.S. adults, age 18-65, conducted in April-May 2019. 
54. Granovetter, 1977, Burt, 2004, Aral, 2016, and Bakshy, et al., 2012.
55. Comparison between the lowest and highest quartile by network strength. Results take into account the highest achieved degree, individuals industry, and their function.
56. Schubert, et al., 2019.
57. The Theil’s index is a measure of economic inequality that ranges from 0 to ln(N), where N is the number of regions used (in our case, counties). The theoretical maximum for this index in the current analysis is just over 8. The minimum is 0 which should be 
interpreted as no concentration of opportunity across regions.
58. The net pay is calculated by subtracting from gross pay 
federal tax, state tax, social security tax, Medicare tax and unemployment/disability insurance, etc. This provisional adjustment is subject to further refinement in annual tax returns.
59. On the economic growth-social mobility nexus and the possibility of a virtuous cycle, see Chapter 3 of World Economic Forum , 2019a. 
60. OECD, 2018b.
61. Chapter 7 of UNDP HDI 2019.
62. McKinsey, 2018.
63. OECD, 2018a.
64. Ibid.
65. Ibid.
66. Note that the notion of quality is evolving rapidly. Education systems need to adjust their curricula to the reality of the Fourth Industrial Revolution to equip students with the skills needed to succeed. Among these skills of the future are 
digital skills, creativity, communication, critical thinking, 
complex problem-solving and emotional intelligence.
67. Pathways towards cultivating talent” in World Economic Forum, 2019b.
68. OECD, 2018c.
69. DeVos, 2018.
70. McKinsey, 2018.
71. Zucman, 2014.

34References
Abrahao, B., P. Paolo, G. Alok and K. Cook, “Reputation Offsets Trust 
Judgments Based on Social Biases among Airbnb Users” , 
Proceedings of the National Academy of Sciences, vol. 114, 
no. 37, 2017.  
Aiyar, S. and C. Ebeke, Inequality of Opportunity, Inequality of Income 
and Economic Growth , IMF Working Paper, European 
Department, 2019.  
Autor, D., The Polarization of Job Opportunities in the U.S: Labor 
Market Implications for Employment and Earnings , Center for 
American Progress and The Hamilton Project, 2010, https://economics.mit.edu/files/5554.  
Autor, D., D. Dorn, L. Katz, C. Patterson and J. Van Reenen, The Fall 
of the Labor Share and the Rise of Superstar Firms , NBER 
Working Paper No. 23396, National Bureau of Economic Research, 2017, https://www.nber.org/papers/w23396.  
Aral, S., “The Future of Weak Ties”, American Journal of Sociology , vol. 
121, no. 6, 2016, pp. 1931–1939.  
Bajgar, M., S. Calligaris, C. Criscuolo, L. Marcolin and J. Timmis, 
“Superstar Firms Are Running Away with the Global Economy”, Harvard Business Review , November 2019, https://
hbr.org/2019/11/superstar-firms-are-running-away-with-the-global-economy.  
Bakshy, E., R. Itamar, M. Cameron and L. Adamic, “The Role of Social 
Networks in Information Diffusion”, i n Proceedings of the 
21st International  Conference on World Wide Web, pp. 
519–528, ACM, 2012. 
Banchet, T, L. Chancel and A. Gethin, How did Europe do on SDG 
10.1 - sustaining income growth of the bottom 40%? , United 
Nations Development Programme (UNDP), 2019.  
Bellet, C., J. De Neve and G. Ward, Does Employee Happiness have an 
Impact on Productivity? , Saïd Business School WP 2019-13, 
Said Business School, 2019.  
Billingsley S., “Intragenerational social mobility and cause-specific premature 
mortality”, Public Library of Science , vol. 14, no. 2, 2019.
Blanchard, O. and F. Giavazzi, “Macroeconomic Effects of Regulation 
and Deregulation in Goods and Labor Markets “, The Quarterly 
Journal of Economics , vol. 118, no. 3, 2003, pp. 879–907.
Blanden, J. “Cross-Country Rankings In Intergenerational Mobility: A 
Comparison Of Approaches From Economics And Sociology,” Journal of Economic Surveys , vol. 27, no. 1, 2013, pp. 38-73.  
Blanden J. and P. Gregg, “Family income and educational attainment: a 
review of approaches and evidence for Britain”, Oxford Review 
of Economic Policy , vol. 20, iss. 2, 2004, pp. 245–263.  
Blanden J., et al, Intergenerational Mobility in Europe and North 
America , London: London School of Economics Publishing, 
2005.
, “Accounting for inter-generational income persistence: non-
cognitive skills, ability and education”, The Economic Journal , 
vol. 117, iss. 519, 2007, pp. C43-C60.
Blanpain, N.,  “L’espérance de vie par niveau de vie : chez les hommes, 
13 ans d’écart entre les plus aisés et les plus modestes” , 
INSEE Premiere , N 1687, 2018.
Bourdieu P. and J.C. Passeron, Reproduction in Education, Society 
and Culture , London: Sage, 1997.Burt, R., “Structural Holes and Good Ideas”, American Journal of 
Sociology , vol. 110, no. 2, 2004, pp. 349–399.
Breen R. and J. Jonsson, “Inequality of opportunity in comparative 
perspective: recent research on educational attainment and social mobility”, Annual Review of Sociology , vol. 31, no. 1, 
2005, pp. 223-243. 
Breen R. (ed), Social Mobility in Europe , Oxford: Oxford University 
Press, 2004.
Brunori, P., V. Peragine and L. Serlenga, “Upward and Downward Bias 
When Measuring Inequality of Opportunity”, Social Choice and 
Welfare , vol. 52, iss. 4, 2018, pp. 635-661.
Brynner J. and W. Paxton, The Asset Effect , Institute for Public Policy 
Research, 2001.
Case, A., A. Fertig and C. Paxson, “The lasting impact of childhood 
health and circumstance”, Journal of Health Economics , vol. 
24, nol. 2, 2005, pp. 365-389.
Causa O. and C.  Chapuis, Equ ity in student ac hievement acro ss OECD 
c
ountries ; an investigation in the role of policies , OECD 
economic department working paper 708, OECD, 2009.
Chetty, R., et al., The Fading American Dream: Trends in Absolute 
Income Mobility Since 1940 , NBER Working Paper No. 22910, 
National Bureau of Economic Research, 2016.
Chetty, R., J. Friedman and J. Rockoff, “Measuring the Impacts of 
Teachers II: Teacher Value-Added and Student Outcomes in Adulthood,” American Economic Review , vol. 104, no. 9, 2014, 
pp. 2633-2679.
Chetty, R., M. Stepner, S. Abraham, et al., “The Association Between 
Income and Life Expectancy in the United States, 2001–2014”, Journal of the American Medical Association , vol. 315, no. 16, 
2016, pp. 1750-1766. 
Clasen J. and D. Clegg, Regulating the Risk of Unemployment: National 
Adaptations to post-industrial Labour Markets , Oxford: Oxford 
University Press, 2011.
Corak, M., Generational Income Mobility in North America and Europe , 
Cambridge: Cambridge University Press, 2004.
, Do Poor Children Become Poor Adults? Lessons from a Cross-
Country Comparison of Generational Earnings Mobility , IZA 
discussion paper, nr 1993, IZA, 2006.
, Inequality from Generation to Generation: The United States in 
Comparison , IZA DP No. 9929, IZA, 2012.
, Income Inequality, Equality of Opportunity, and 
Intergenerational Mobility , IZA DP No. 7520, IZA, 2013.
Council of Europe, Draft report on fostering social mobility as a 
contribution to social cohesion , CDCS (4), 2011.
Currie, J., Healthy, Wealthy and Wise: Socio-Economic Status, Poor 
Health in Childhood and Human Capital Development , NBER 
Working Paper No. 13987, National Bureau of Economic Research, 2008.
Currie, J. and M. Stabile, Socio-Economic Status and Child Health; 
Why is the Relationship Stronger with Older Children? , NBER 
Working Paper No. 9098, National Bureau of Economic Research, 2003.

35D’Addio A., Intergenerational mobility : does is offset or reinforce 
income inequality ? in OECD (ed) Growing unequal ? Income 
Distribution and Inequality in OECD countries , OECD, 2008.
De Vos, M., Work 4.0 and the Future of Labour Law , 2018.
Elliot-Major, L. and S. Machin, Social Mobility and Its Enemies , Pelican 
Books, 2019.
Erikson R. and J. Goldthorpe, The Constant Flux: a Study of Class 
Mobility in Industrial Societies , Oxford: Oxford University 
Press,1992.
Escobari, M., I. Seyal and M. Meaney, Realism about reskilling: 
Upgrading the career prospects of America’s low-wage workers , Brooking Institute, 2019.
Esping-Andersen, G., “Welfare regimes and social stratification”, 
Journal of European Social Policy , vol. 25, iss. 1, 2015.
Fehr, E. and U. Fischbacher, “The Nature of Human Altruism”, Nature , 
vol. 425, 2003, pp. 785–791.
Ferreira, F., “Education for the Masses? The Interaction Between 
Wealth, Educational and Political Inequalities, Economics of 
Transition , vol. 9, no. 2, 2001, pp. 533-552. 
, “The Active Ingredient of Inequality”, Let’s Talk Development , 
15 June 2017, https://blogs.worldbank.org/developmenttalk/active-ingredient-inequality.
Ferreira, F. and J. Gignoux, “The Measurement of Inequality of 
Opportunity, Theory and Application”, The Review of Income 
and Wealth , 2011.
Goldin C. and F. Katz, The Race between Education and Technology , 
Cambridge, MA: Belknap Press, 2010.
Granovetter, M., “The Strength of Weak Ties”, in Social Networks , pp. 
347– 367. Elsevier, 1977.
Heider, F., “Attitudes and Cognitive Organization”, The Journal of 
Psychology , vol. 21, no. 1, 1946, p. 107.
Havnes, T.  and M. Mogstad,  No Child Left Behind, Universal Child 
Care and Children Long-run Outcomes , IZA DP No. 4561, IZA, 
2009.
Heckman, J.J. and D. V. Masterov, The Productivity Argument for 
Investing in Young Children , Working Paper No. 5, Committee 
on Economic Development, 2004.
International Labour Organization (ILO), Meeting the Challenges of a 
Changing World Of Work , 2019.
Jäntti M., et al., American Exceptionalism in New Light: A Comparison 
of International Earnings Mobility in the Nordic Countries, the UK and the US , IZA discussion paper DP no. 1938, IZA, 2006.
Kalleberg A., Precarious Lives: Job Insecurity and Well-Being in Rich 
Democracies , Wiley, 2018.
Kerr C., et al, Industrialism and Industrial Man , Cambridge, MA: 
Harvard University Press, 1960.
Kopczuk, W., E. Saez and J. Song, Earnings inequality and mobility in 
the United States: Evidence from social security data since 1937, Quarterly Journal of Economics , 2010.
Kramer, R., “Trust and Distrust in Organizations: Emerging  Perspectives, Enduring Questions” , Annual Review of 
Psychology, vol. 50, no. 1, 1999, pp. 569–598.
Li, Y and Z. Yizhan, “Double Disadvantages: A Study of Ethnic and 
Hukou Effects on Class Mobility in China (1996–2014)”, International Migration and Ethnic Integration , vol. 5, no. 1, 
2017. 
Ludwinek, A., et al, Social Mobility in the EU , European Foundation for 
the Improvement of Living and Working Conditions, 2017.
Lynn R. and T. Vanhanen, IQ and the Wealth of Nations , Westport, CT: 
Praeger, 2002.
McKinsey & Company, Tech For Good: Using Technology to Smooth 
Disruption and Improve Well-Being , 2018.
National Institute of Adult Continuing Education (NIACE), Family 
Learning Works: The Inquiry into Family Learning in England and Wales , 2013.
Nunn A., et al., Factors Influencing Social Mobility , Government of the 
UK Department of Work and Pensions, 2007.
OECD, Health at a Glance, 2018 edition , 2018a.
, Employment Outlook 2018 , 2018b.
, A Broken Social Elevator: How to Promote Social Mobility , 
2018c.
, Under Pressure: The Squeezed Middle Class , 2019a.
Parigi, P., J. Santana and K. Cook, “Online Field Experiments: Studying 
Social Interactions in Context”, Social Psychology Quarterly , 
vol. 80, no. 1, 2017, pp. 1–19.
Pew Trusts, Women’s Work: The Economic Mobility of Women Across 
a Generation , 2014.
Piketty, T., Capital in the 21st Century , Cambridge, MA: Belknap Press. 
2014.
Piketty, T., E. Saez and G. Zucman, Distributional National Accounts: 
Methods and estimates for the United States , NBER Working 
Paper No. 22945, National Bureau of Economic Research, 2016.
Portes A., “Social Capital: Its Origins and Application in Modern 
Sociology”, Annual Review of Sociology , vol. 24, 1998, pp. 
1–24. 
Putman R., Bowling Alone: The Collapse and Revival of American 
Community , New York: Simon and Schuster, 2000.
Rawls, J., A Theory of Justice , Cambridge, MA: Belknap Press, 1971.
Reijnders, L. and G. de Vries, Job Polarization in Advanced and 
Emerging Countries: The Role of Task Relocation and Technological Change within Global Supply Chains , GGDC 
Research Memorandum 167, University of Groningen-
Groningen Growth and Development Centre, 2017.
Saunders P., “Reflections on the Meritocracy Debate in Britain: A 
Response to Richard Breen and John Goldthorpe”, British 
Journal of Sociology , vol. 53, 2002, pp. 559−574. 
Salganik, M., P.S. Dodds and D. Watts, “Experimental Study of 
Inequality and Unpredictability in an Artificial Cultural Market”, 
Science , vol. 311, no. 5762, 2006, pp. 854–856.

36Sauder, M., F. Lynn and J. Podolny, “Status: Insights from 
Organizational Sociology”, Annual Review of Sociology , vol. 
38, 2012, pp. 267–283.
Schmid G., Flexible and Secure Labour Market Transitions: Towards 
Institutional Capacity Building in the Digital Economy , IZA 
Policy Paper 116, IZA, 2016.
Schubert, G., A. Stansbury and B. Taska, “Getting Labor Markets 
Right: Outside Options and Occupational Mobility”, working 
paper, 22nd IZA Summer School in Labor Economics , Buch/
Ammersee, Germany, 2019.
Schulz, W., “Occupational Career Attainment of Single Women During 
Modernization: The Logic of Industrialism Thesis Revisited”, 
European Societies , vol. 17, iss. 4, 2015, pp. 467-491, https://
www.tandfonline.com/doi/full/10.1080/14616696.2015.1072228.
Schwab, K., The Fourth Industrial Revolution , Geneva: World Economic 
Forum, 2016.
Sen, A,. Commodities and Capabilities , Oxford: Oxford University 
Press, 1985.
Sherman, M., A Short History of Financial Deregulation in the United 
States , Center for Economic and Policy Research (CEPR), 2009.
Solt, Frederick, The Standardized World Income Inequality Database, 
Version 8 , https://doi.org/10.7910/DVN/LM4OWF, Harvard 
Dataverse, 2019.
Stiglitz, J., The Price of Inequality: How Today’s Divided Society 
Endangers Our Future  , New York: W.W. Norton, 2012.
Sutton Trust, The Mobility Manifesto: A report on cost-effective ways 
to achieve greater social mobility through education, based on 
work by the Boston Consulting Group,  2010.
, The State of Social Mobility in the UK , 2017.
Government of the United Kingdom Family and Childcare Trust, The 
Parliamentary Inquiry into Parenting and Social Mobility , 2015.
Government of the United Kingdom Social Mobility Commission, Social 
Mobility Index Methodology , 2016.
, Social Mobility in Great Britain: State of the Nation 2018 to 
2019 , 2019.
United Nations Development Programme, Human Development Report 
2019 , 2019.
Van Reenen, J., The Rise of Superstar Firms , VoxEU, CEPR Policy 
Portal, https://voxeu.org/content/rise-superstar-firms.
Van de Rijt, A., K. Soong Moon, M. Restivo and A. Patil,  “Field 
Experiments of Success-Breeds-Success Dynamics”, 
Proceedings of the National Academy of Sciences , vol. 111, 
no. 19, 2014, pp. 6934–6939.
Waldfogel, J., Social Mobility, Life Chances, and the Early Years , LSE 
STICERD Research Paper No. CASE088, Centre for Analysis 
of Social Exclusion, London School of Economics and Political 
Science, 2004.
World Bank, Fair Progress? Economic Mobility across Generations 
Around the World , 2018a.
, Poverty and Shared Prosperity 2018: Piecing Together the 
Poverty Puzzle , 2018b., Global Database on Intergenerational Mobility (GDIM) , 2018c.
, Health Equity and Financial Protection Indicators (HEFPI)  
database, 2019 Update.
World Economic Forum, Future of Jobs Report 2018 , 2018.
, Towards a Reskilling Revolution , 2019a.
, Dialogue Series on New Economic and Social Frontiers: 
Shaping the New Economy in the Fourth Industrial Revolution , 
2019b.
, Global Competitiveness Report 2019 , 2019c.
Zucman, G., “Taxing across Borders: Tracking Personal Wealth and 
Corporate Profits, Journal of Economic Perspectives”, vol. 28, 
no. 4, 2014, pp. 121–148.

37Economy Profiles 
How to Read the Economy Profiles
The Economy Profiles section presents a two-page profile for each of the 82 economies 
covered in The Global Social Mobility Report 2020 . 
Performance overview  
 
This section details the economy’s performance on the main components of the Global 
Social Mobility Index (GSMI). The bar chart in this section presents an economy’s score 
on the overall GSMI and on each of its ten pillars. The economy’s rank (out of 82 
economies) on each pillar is displayed at the bottom of the chart. At the top of the chart, 
the three-letter code (ISO-3) of the best performer is displayed. To the right of each bar 
the performance of relevant benchmarks is displayed: the economy’s score in the index 
edition (circle) and the average score of the economy’s income group, based on the 
World Bank’s classification (triangle).
Contextual indicators   
This section presents a selection of contextual indicators as well as selected indicators 
of social and environmental performance, to complement the GCI. These include: 
population (millions, 2018 or most recent year available, source: International Monetary 
Fund, World Economic Outlook Database , April 2019); GDP per capita (US$, 2018 or 
most recent year available, source: International Monetary Fund, World Economic Outlook 
Database , April 2019); 10-year average annual GDP growth (% real terms, 2009–2018 
or most recent years available, source: International Monetary Fund, World Economic 
Outlook Database , April 2019); share of GDP in world total (%, 2018 or most recent 
year available, source: International Monetary Fund, World Economic Outlook Database , 
April 2019); Income Gini coefficient (0–1, 2015 or most recent year available, source: 
World Bank, Development Research Group, via the World Bank’s World Development 
Indicators database ). 
The Global Social Mobility Index in detail   
These pages detail the economy’s performance on each of the 51 indicators that 
compose the GSMI. Indicators are organized by pillar. Refer to Appendix B for the detailed 
structure of the GSMI, the definition of each indicator and computation methodology. 
For each indicator, the following information is displayed: 
 ≥Number, title and unit of measurement 
 ≥The value for the economy under review, if available. 
 ≥The economy’s progress score on a 0 to 100 scale following normalization 
 ≥Economy’s rank out of 82 (or rank among the subset of economies  
for which data are available) 
 ≥The name of the economy attaining the highest progress score or the number  
of economies if there are multiple best performers 
Online resources
Interactive profiles and sortable rankings with detailed meta information (such as the 
period and source for each data point), as well as downloadable datasets, are available at 
http://reports.weforum.org/social-mobility-report-2020/

38Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

54th
37th
62nd
55th
47th
50th
81st
49th
18th
56th
39th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5679
5057
5070
324668
4261
Albania 54th /82
Index Component Value Score      Rank/ 82 Best Performer
- 78.9 37 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 19.6 80.4 41 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.2 81.7 25 Ghana
1.03 Health Access and Quality Index (0–100 best) 75.4 75.4 43 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 78.0 44 Singapore
- 49.8 62 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 76.5 76.5 33 Malta
2.02 Quality of vocational training (1–7) 4.3 54.7 43 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 32.8 0.0 74 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 68.1 46 GermanyAlbania 54th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %2.9
13.2
5,288.90.03
29.0
2.4

39Albania 54th /82
Index Component Value Score       Rank/ 82 Best Performer
- 57.1 55 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 17.6 74.8 50 Multiple (3)
3.04 Pupils per teacher in secondary education 13.4 71.9 41 Armenia
3.05 Harmonized learning outcomes (score) 445.0 61.3 51 Singapore
3.06 Social diversity in schools (score) 70.0 48.3 43 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material70.7 29.3 56 Multiple (2)
- 50.3 47 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.6 59.2 28 Switzerland
4.02 Active labour market policies (1–7) 2.9 31.0 62 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.0 49.9 67 Switzerland
4.04 Percentage of ﬁrms of fering formal training 46.2 61.6 13 Ecuador
4.05 Digital skills among active population (1–7) 4.0 49.9 62 Finland
- 70.3 50 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 71.8 71.8 47 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 12.5 25.0 56 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 62.8 52.3 63 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.2 99.2 34 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.4 73.5 18 Singapore
- 32.5 81 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 13.8 44.8 66 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 20.4 18.5 80 Thailand
6.02 Unemployment among labor force with advanced education (%) 19.1 23.6 79 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 72.7 65.9 52 Lao PDR
6.06 Workers in vulnerable employment (%) 54.3 9.5 74 Saudi Arabia
- 45.6 49 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 38.9 32.1 56 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 27.0 42.4 44 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 53.1 62.4 33 Switzerland
- 68.1 18 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 79.0 79.0 34 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.0 65.9 26 Singapore
8.03 Pay and productivity (1–7) 4.5 59.0 25 Switzerland
8.04 Employees working more than 48 hours per week (%) 10.8 78.4 38 Bulgaria
8.05 Collective bargaining coverage ratio (%) 58 58.0 20 France
- 42.2 56 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 11.9 47.5 49 Multiple (9)
9.04 Social safety net protection, 1-7 3.2 36.8 72 Norway
- 61.3 39 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 36.0 36.0 59 Denmark
10.02 Government and public services efﬁciency (score) 0.1 54.8 50 Singapore
10.03 Inclusiveness of institutions (score) 0.5 80.1 15 Portugal
10.04 Political stability and protection from violence (score) 0.4 74.5 37 New Zealand

40Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

51st
65th
35th
70th
62nd
49th
57th
47th
51st
37th
45th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions576169
384671
65
475760 60
Argentina 51st /82
Index Component Value Score      Rank/ 82 Best Performer
- 61.4 65 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 62.8 37.2 68 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 17.8 64.4 73 Ghana
1.03 Health Access and Quality Index (0–100 best) 68.1 68.1 57 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 75.8 49 Singapore
- 69.2 35 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 75.9 75.9 35 Malta
2.02 Quality of vocational training (1–7) 4.8 62.9 24 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 19.0 36.6 55 Japan
2.04 Out-of-school children (%) 0.6 94.0 17 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 76.5 32 GermanyArgentina 51st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %44.6
637.7
11,626.90.68
41.2
1.5

41Argentina 51st /82
Index Component Value Score       Rank/ 82 Best Performer
- 38.4 70 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 53.6 23.4 54 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education n/a n/a n/a Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 420.9 55.2 59 Singapore
3.06 Social diversity in schools (score) 63.7 33.1 49 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material58.2 41.8 47 Multiple (2)
- 46.1 62 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.8 46.9 61 Switzerland
4.02 Active labour market policies (1–7) 2.9 30.9 63 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.9 48.6 72 Switzerland
4.04 Percentage of ﬁrms of fering formal training 40.2 53.6 19 Ecuador
4.05 Digital skills among active population (1–7) 4.0 50.2 61 Finland
- 70.8 49 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 74.3 74.3 42 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 19.1 38.2 43 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 80.7 67.2 45 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.0 95.0 58 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.0 50.0 59 Singapore
- 64.8 57 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 10.5 58.0 53 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 10.7 57.2 66 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.6 85.4 30 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 67.2 58.9 62 Lao PDR
6.06 Workers in vulnerable employment (%) 21.4 64.3 44 Saudi Arabia
- 47.0 47 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 23.5 32.9 45 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 51.1 45.7 37 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 28.5 46.2 40 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 37.5 35.8 54 Multiple (4)
7.05 Adjusted labour income share (%) 58.5 74.4 15 Switzerland
- 56.6 51 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 73.0 73.0 41 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.8 46.4 76 Singapore
8.03 Pay and productivity (1–7) 3.5 41.9 68 Switzerland
8.04 Employees working more than 48 hours per week (%) 15.1 69.7 47 Bulgaria
8.05 Collective bargaining coverage ratio (%) 52 51.8 25 France
- 59.6 37 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 66.1 66.1 37 Multiple (6)
9.03 Social protection spending (% of GDP) n/a n/a n/a Multiple (9)
9.04 Social safety net protection, 1-7 4.2 53.1 40 Norway
- 59.7 45 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 40.0 40.0 53 Denmark
10.02 Government and public services efﬁciency (score) 0.0 52.9 53 Singapore
10.03 Inclusiveness of institutions (score) 0.5 79.4 16 Portugal
10.04 Political stability and protection from violence (score) 0.0 66.5 48 New Zealand

42Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

56th
40th
73rd
16th
66th
56th
77th
52nd
54th
59th
54th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5477
3779
4467
43 4455
4053
Armenia 56th /82
Index Component Value Score      Rank/ 82 Best Performer
- 77.3 40 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 21.5 78.5 45 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 6.8 86.4 11 Ghana
1.03 Health Access and Quality Index (0–100 best) 70.7 70.7 50 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 73.5 51 Singapore
- 36.8 73 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 35.1 35.1 62 Malta
2.02 Quality of vocational training (1–7) 3.9 48.3 59 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 36.6 0.0 77 Japan
2.04 Out-of-school children (%) 7.2 28.0 62 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 72.7 39 GermanyArmenia 56th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %3.0
11.6
4,149.30.02
33.6
3.6

43Armenia 56th /82
Index Component Value Score       Rank/ 82 Best Performer
- 79.4 16 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 30.0 57.1 45 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 6.3 95.8 3 Australia
3.03 Pupils per teacher in primary education 15.4 81.9 35 Multiple (3)
3.04 Pupils per teacher in secondary education 4.5 100.0 1 Armenia
3.05 Harmonized learning outcomes (score) 447.7 61.9 49 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 43.6 66 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.7 44.8 64 Switzerland
4.02 Active labour market policies (1–7) 3.2 36.9 54 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 55.8 51 Switzerland
4.04 Percentage of ﬁrms of fering formal training 16.2 21.6 43 Ecuador
4.05 Digital skills among active population (1–7) 4.5 59.0 38 Finland
- 67.3 56 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 64.7 64.7 58 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 11.8 23.5 58 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 75.9 63.2 52 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.2 52.5 54 Singapore
- 42.8 77 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 17.4 30.4 71 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 17.7 29.3 78 Thailand
6.02 Unemployment among labor force with advanced education (%) 17.8 28.7 77 Czech Republic
6.04 Unemployment in rural areas (%) 7.3 70.9 47 Peru
6.05 Ratio of female to male labour force participation rate 71.0 63.8 56 Lao PDR
6.06 Workers in vulnerable employment (%) 39.9 33.5 63 Saudi Arabia
- 44.5 52 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 25.8 26.3 49 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 41.5 35.0 53 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 24.9 37.2 50 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 51.8 76.6 21 Multiple (4)
7.05 Adjusted labour income share (%) 46.3 47.3 58 Switzerland
- 54.7 54 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) n/a n/a n/a Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.9 65.4 27 Singapore
8.03 Pay and productivity (1–7) 4.2 53.5 41 Switzerland
8.04 Employees working more than 48 hours per week (%) 12.5 75.0 42 Bulgaria
8.05 Collective bargaining coverage ratio (%) 25 24.9 42 France
- 39.8 59 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 47.3 47.3 44 Multiple (6)
9.03 Social protection spending (% of GDP) 7.6 30.4 58 Multiple (9)
9.04 Social safety net protection, 1-7 3.5 41.8 60 Norway
- 53.0 54 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 35.0 35.0 63 Denmark
10.02 Government and public services efﬁciency (score) 0.0 51.8 58 Singapore
10.03 Inclusiveness of institutions (score) 0.1 68.5 44 Portugal
10.04 Political stability and protection from violence (score) -0.4 56.9 61 New Zealand

44Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

16th
23rd
23rd
12th
16th
12th
18th
40th
22nd
19th
14th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7587
7682
6889
78
50677382
Australia 16th /82
Index Component Value Score      Rank/ 82 Best Performer
- 87.4 23 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 11.7 88.3 32 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 13.0 74.0 56 Ghana
1.03 Health Access and Quality Index (0–100 best) 95.9 95.9 5 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 91.5 15 Singapore
- 75.6 23 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 85.4 85.4 25 Malta
2.02 Quality of vocational training (1–7) 4.8 63.8 22 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 8.9 70.2 20 Japan
2.04 Out-of-school children (%) 3.2 68.0 48 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 90.4 2 GermanyAustralia 16th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %25.2
1,379.6
56,351.60.98
35.8
2.4

45Australia 16th /82
Index Component Value Score       Rank/ 82 Best Performer
- 82.1 12 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 5.5 92.1 28 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 4.8 100.0 1 Australia
3.03 Pupils per teacher in primary education 15.1 82.9 30 Multiple (3)
3.04 Pupils per teacher in secondary education 12.0 76.7 28 Armenia
3.05 Harmonized learning outcomes (score) 528.4 82.1 17 Singapore
3.06 Social diversity in schools (score) 75.6 61.9 30 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material20.9 79.1 10 Multiple (2)
- 67.8 16 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.8 63.5 19 Switzerland
4.02 Active labour market policies (1–7) 4.9 64.5 16 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.6 76.1 22 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.0 67.0 18 Finland
- 88.7 12 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 86.5 86.5 20 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 32.2 64.4 20 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 134.1 100.0 8 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.4 99.4 30 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.9 81.7 7 Singapore
- 78.3 18 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 8.6 65.5 39 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.9 76.5 37 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.4 86.3 24 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 84.7 80.9 17 Lao PDR
6.06 Workers in vulnerable employment (%) 10.7 82.1 28 Saudi Arabia
- 50.3 40 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 15.7 55.1 24 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 44.8 38.6 45 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 24.4 36.1 53 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 57.2 71.6 22 Switzerland
- 66.7 22 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 82.0 82.0 28 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.6 59.7 38 Singapore
8.03 Pay and productivity (1–7) 4.5 58.1 30 Switzerland
8.04 Employees working more than 48 hours per week (%) 13.1 73.8 43 Bulgaria
8.05 Collective bargaining coverage ratio (%) 60 60.0 18 France
- 72.7 19 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 42.0 56.0 14 Multiple (2)
9.02 Social protection coverage (% of population) 82.0 82.0 28 Multiple (6)
9.03 Social protection spending (% of GDP) 18.8 75.2 29 Multiple (9)
9.04 Social safety net protection, 1-7 5.7 77.7 11 Norway
- 81.7 14 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 77.0 77.0 13 Denmark
10.02 Government and public services efﬁciency (score) 1.6 86.4 13 Singapore
10.03 Inclusiveness of institutions (score) 0.3 75.6 27 Portugal
10.04 Political stability and protection from violence (score) 1.0 87.6 14 New Zealand

46Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

8th
19th
4th
6th
11th
28th
16th
26th
5th
3rd
16th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions808985 85
7380 79
618087
80
Austria 8th/82
Index Component Value Score      Rank/ 82 Best Performer
- 89.4 19 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.3 92.7 19 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.6 78.7 38 Ghana
1.03 Health Access and Quality Index (0–100 best) 93.9 93.9 12 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 92.3 12 Singapore
- 85.3 4 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 87.3 87.3 22 Malta
2.02 Quality of vocational training (1–7) 5.7 78.9 2 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 6.8 77.2 12 Japan
2.04 Out-of-school children (%) 0.0 100.0 1 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 83.0 21 GermanyAustria 8th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %8.9
416.9
51,509.00.34
30.5
1.4

47Austria 8th/82
Index Component Value Score       Rank/ 82 Best Performer
- 85.4 6 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.4 96.6 14 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 13.8 70.7 32 Australia
3.03 Pupils per teacher in primary education 11.3 95.8 10 Multiple (3)
3.04 Pupils per teacher in secondary education 10.1 83.0 15 Armenia
3.05 Harmonized learning outcomes (score) 524.0 81.0 20 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 73.2 11 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.1 68.4 11 Switzerland
4.02 Active labour market policies (1–7) 5.7 79.0 2 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.9 82.3 14 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.8 63.0 30 Finland
- 80.0 28 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 87.7 87.7 18 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 28.4 56.7 30 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 88.0 73.3 38 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.0 98.0 48 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.8 64.1 34 Singapore
- 79.2 16 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 12.9 48.3 62 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.2 83.0 17 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.2 87.1 23 Czech Republic
6.04 Unemployment in rural areas (%) 2.5 90.1 12 Peru
6.05 Ratio of female to male labour force participation rate 83.4 79.2 26 Lao PDR
6.06 Workers in vulnerable employment (%) 7.6 87.3 13 Saudi Arabia
- 61.1 26 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 15.4 55.9 23 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 47.9 42.1 40 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 29.6 48.9 36 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 52.6 78.9 17 Multiple (4)
7.05 Adjusted labour income share (%) 60.9 79.8 10 Switzerland
- 80.5 5 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) n/a n/a n/a Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.5 75.4 9 Singapore
8.03 Pay and productivity (1–7) 4.6 60.3 22 Switzerland
8.04 Employees working more than 48 hours per week (%) 5.9 88.2 22 Bulgaria
8.05 Collective bargaining coverage ratio (%) 98 98.0 2 France
- 87.0 3 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 48.0 64.0 9 Multiple (2)
9.02 Social protection coverage (% of population) 98.6 98.6 9 Multiple (6)
9.03 Social protection spending (% of GDP) 28.0 100.0 6 Multiple (9)
9.04 Social safety net protection, 1-7 6.1 85.5 4 Norway
- 80.2 16 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 76.0 76.0 14 Denmark
10.02 Government and public services efﬁciency (score) 1.5 83.4 17 Singapore
10.03 Inclusiveness of institutions (score) 0.3 75.0 30 Portugal
10.04 Political stability and protection from violence (score) 0.9 86.3 17 New Zealand

48Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

78th
79th
75th
78th
82nd
76th
70th
33rd
79th
81st
80th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4046
3329374655 56
40
2140
Bangladesh 78th /82
Index Component Value Score      Rank/ 82 Best Performer
- 45.7 79 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 83.0 17.0 80 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 20.6 58.7 78 Ghana
1.03 Health Access and Quality Index (0–100 best) 47.6 47.6 73 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 59.6 72 Singapore
- 32.7 75 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 3.4 39.4 77 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 27.4 8.7 68 Japan
2.04 Out-of-school children (%) 4.9 51.0 54 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.3 31.9 78 GermanyBangladesh 78th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %164.9
261.4
1,744.50.56
32.4
5.9

49Bangladesh 78th /82
Index Component Value Score       Rank/ 82 Best Performer
- 29.2 78 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 56.0 20.0 57 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 30.1 33.2 75 Multiple (3)
3.04 Pupils per teacher in secondary education 28.7 21.1 69 Armenia
3.05 Harmonized learning outcomes (score) 369.8 42.5 74 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 37.3 82 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.3 38.7 80 Switzerland
4.02 Active labour market policies (1–7) 2.6 27.3 70 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.9 48.5 73 Switzerland
4.04 Percentage of ﬁrms of fering formal training 21.9 29.2 37 Ecuador
4.05 Digital skills among active population (1–7) 3.5 42.5 74 Finland
- 45.5 76 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 15.0 15.0 82 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 6.3 12.7 67 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 37.6 31.3 77 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.2 95.2 57 Multiple (13)
5.05 Rural population with electricity access (%) 81.3 81.3 75 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.3 37.6 75 Singapore
- 55.3 70 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.5 86.2 15 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 8.5 66.1 57 Thailand
6.02 Unemployment among labor force with advanced education (%) 10.7 57.1 67 Czech Republic
6.04 Unemployment in rural areas (%) 4.1 83.6 26 Peru
6.05 Ratio of female to male labour force participation rate 44.5 30.6 76 Lao PDR
6.06 Workers in vulnerable employment (%) 54.9 8.4 75 Saudi Arabia
- 55.9 33 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 56.0 51.1 31 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 32.2 55.4 29 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 52.6 78.8 18 Multiple (4)
7.05 Adjusted labour income share (%) 42.2 38.2 65 Switzerland
- 40.1 79 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 61.0 61.0 70 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.1 52.4 66 Singapore
8.03 Pay and productivity (1–7) 3.8 47.0 57 Switzerland
8.04 Employees working more than 48 hours per week (%) 58.8 0.0 75 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 20.9 81 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 28.4 28.4 52 Multiple (6)
9.03 Social protection spending (% of GDP) 1.7 6.6 78 Multiple (9)
9.04 Social safety net protection, 1-7 2.7 27.8 82 Norway
- 39.6 80 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 26.0 26.0 81 Denmark
10.02 Government and public services efﬁciency (score) -0.7 36.3 81 Singapore
10.03 Inclusiveness of institutions (score) -0.5 52.6 65 Portugal
10.04 Political stability and protection from violence (score) -1.0 43.4 75 New Zealand

50Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

9th
13th
14th
22nd
15th
27th
28th
1st
8th
5th
19th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions8090
8177
6882
7588
7984
77
Belgium 9th/82
Index Component Value Score      Rank/ 82 Best Performer
- 90.4 13 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 4.7 95.3 9 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 7.9 84.1 13 Ghana
1.03 Health Access and Quality Index (0–100 best) 92.9 92.9 14 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 89.2 25 Singapore
- 80.6 14 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 97.0 97.0 4 Malta
2.02 Quality of vocational training (1–7) 5.1 67.8 13 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 9.1 69.5 21 Japan
2.04 Out-of-school children (%) 1.3 87.0 27 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 81.5 25 GermanyBelgium 9th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %11.4
494.7
46,724.30.41
27.7
1.2

51Belgium 9th/82
Index Component Value Score       Rank/ 82 Best Performer
- 77.3 22 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 5.1 92.7 26 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 14.7 67.7 38 Australia
3.03 Pupils per teacher in primary education 12.9 90.4 19 Multiple (3)
3.04 Pupils per teacher in secondary education 9.7 84.3 12 Armenia
3.05 Harmonized learning outcomes (score) 517.5 79.4 29 Singapore
3.06 Social diversity in schools (score) 76.1 63.0 28 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material36.7 63.3 25 Multiple (2)
- 68.0 15 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.0 66.6 13 Switzerland
4.02 Active labour market policies (1–7) 4.6 59.2 25 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.9 82.3 15 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.8 63.8 27 Finland
- 81.7 27 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 88.7 88.7 16 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 39.2 78.4 11 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 75.7 63.1 53 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.6 60.2 39 Singapore
- 75.1 28 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 13.8 44.8 67 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 6.0 76.2 39 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.4 86.2 25 Czech Republic
6.04 Unemployment in rural areas (%) 4.2 83.2 28 Peru
6.05 Ratio of female to male labour force participation rate 81.6 77.0 31 Lao PDR
6.06 Workers in vulnerable employment (%) 10.2 83.0 25 Saudi Arabia
- 88.4 1 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 4.1 88.3 6 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 94.7 94.1 4 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 44.8 87.1 2 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 56.2 89.3 12 Multiple (4)
7.05 Adjusted labour income share (%) 62.5 83.3 4 Switzerland
- 78.9 8 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 89.0 89.0 18 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.6 60.5 37 Singapore
8.03 Pay and productivity (1–7) 4.4 56.8 32 Switzerland
8.04 Employees working more than 48 hours per week (%) 3.9 92.2 8 Bulgaria
8.05 Collective bargaining coverage ratio (%) 96 96.0 3 France
- 84.1 5 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 38.0 50.7 20 Multiple (2)
9.02 Social protection coverage (% of population) 100.0 100.0 1 Multiple (6)
9.03 Social protection spending (% of GDP) 29.2 100.0 3 Multiple (9)
9.04 Social safety net protection, 1-7 6.2 85.9 3 Norway
- 76.5 19 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 75.0 75.0 16 Denmark
10.02 Government and public services efﬁciency (score) 1.2 77.4 24 Singapore
10.03 Inclusiveness of institutions (score) 0.5 78.5 17 Portugal
10.04 Political stability and protection from violence (score) 0.4 75.2 36 New Zealand

52Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

60th
64th
57th
65th
80th
55th
69th
64th
39th
38th
74th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5262
54
423868
56
366159
45
Brazil 60th /82
Index Component Value Score      Rank/ 82 Best Performer
- 62.0 64 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 59.1 40.9 66 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 13.7 72.6 59 Ghana
1.03 Health Access and Quality Index (0–100 best) 63.8 63.8 63 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 70.8 59 Singapore
- 54.2 57 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 86.5 86.5 24 Malta
2.02 Quality of vocational training (1–7) 3.3 38.6 78 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 24.1 19.5 60 Japan
2.04 Out-of-school children (%) 2.7 73.0 43 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.5 53.5 65 GermanyBrazil 60th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %208.3
2,055.0
8,967.72.49
53.3
1.2

53Brazil 60th /82
Index Component Value Score       Rank/ 82 Best Performer
- 42.2 65 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 46.9 33.0 53 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 20.7 47.7 58 Australia
3.03 Pupils per teacher in primary education 24.3 52.5 67 Multiple (3)
3.04 Pupils per teacher in secondary education 24.1 36.2 65 Armenia
3.05 Harmonized learning outcomes (score) 408.5 52.1 61 Singapore
3.06 Social diversity in schools (score) 60.8 26.0 59 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material52.0 48.0 38 Multiple (2)
- 37.9 80 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.8 47.1 58 Switzerland
4.02 Active labour market policies (1–7) 2.6 27.4 69 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.5 42.1 78 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 3.1 34.8 81 Finland
- 67.8 55 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 67.5 67.5 52 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 14.9 29.8 50 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 88.1 73.4 35 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.5 95.5 56 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.4 40.8 72 Singapore
- 55.9 69 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 15.3 38.6 68 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 14.1 43.6 74 Thailand
6.02 Unemployment among labor force with advanced education (%) 6.9 72.6 57 Czech Republic
6.04 Unemployment in rural areas (%) 9.8 60.8 58 Peru
6.05 Ratio of female to male labour force participation rate 72.6 65.7 53 Lao PDR
6.06 Workers in vulnerable employment (%) 27.4 54.3 54 Saudi Arabia
- 35.9 64 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 21.5 38.6 37 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 29.9 22.1 65 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 21.8 29.5 60 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 28.8 10.8 65 Multiple (4)
7.05 Adjusted labour income share (%) 60.4 78.7 11 Switzerland
- 60.6 39 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 62.0 62.0 65 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.6 44.1 78 Singapore
8.03 Pay and productivity (1–7) 3.4 40.4 73 Switzerland
8.04 Employees working more than 48 hours per week (%) 6.9 86.2 28 Bulgaria
8.05 Collective bargaining coverage ratio (%) 71 70.5 17 France
- 59.2 38 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 61.5 61.5 39 Multiple (6)
9.03 Social protection spending (% of GDP) 18.3 73.1 31 Multiple (9)
9.04 Social safety net protection, 1-7 3.6 42.9 58 Norway
- 45.4 74 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 35.0 35.0 63 Denmark
10.02 Government and public services efﬁciency (score) -0.4 42.8 72 Singapore
10.03 Inclusiveness of institutions (score) -0.8 45.6 75 Portugal
10.04 Political stability and protection from violence (score) -0.4 58.2 60 New Zealand

54Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

40th
54th
54th
42nd
40th
37th
39th
24th
47th
36th
46th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6471
5671
5377
71
61586159
Bulgaria 40th /82
Index Component Value Score      Rank/ 82 Best Performer
- 71.2 54 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 39.9 60.1 56 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 12.5 74.9 52 Ghana
1.03 Health Access and Quality Index (0–100 best) 77.2 77.2 41 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 72.5 54 Singapore
- 55.8 54 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 75.1 75.1 39 Malta
2.02 Quality of vocational training (1–7) 3.8 46.7 62 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 15.0 49.9 42 Japan
2.04 Out-of-school children (%) 6.8 32.0 58 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 75.3 35 GermanyBulgaria 40th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %7.0
56.9
9,267.40.12
37.4
2.0

55Bulgaria 40th /82
Index Component Value Score       Rank/ 82 Best Performer
- 70.9 42 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 5.2 92.6 27 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.3 75.7 24 Australia
3.03 Pupils per teacher in primary education 17.6 74.6 51 Multiple (3)
3.04 Pupils per teacher in secondary education 12.4 75.3 30 Armenia
3.05 Harmonized learning outcomes (score) 506.2 76.5 34 Singapore
3.06 Social diversity in schools (score) 62.9 31.1 54 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material29.5 70.5 22 Multiple (2)
- 52.9 40 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.8 47.0 59 Switzerland
4.02 Active labour market policies (1–7) 3.5 42.3 49 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.4 57.3 47 Switzerland
4.04 Percentage of ﬁrms of fering formal training 42.7 56.9 15 Ecuador
4.05 Digital skills among active population (1–7) 4.7 60.9 36 Finland
- 77.1 37 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 64.8 64.8 57 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 26.6 53.2 37 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 102.3 85.3 21 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.5 59.1 44 Singapore
- 71.2 39 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 17.5 29.8 72 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.5 82.0 21 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.3 90.7 10 Czech Republic
6.04 Unemployment in rural areas (%) 9.2 63.1 54 Peru
6.05 Ratio of female to male labour force participation rate 80.4 75.5 35 Lao PDR
6.06 Workers in vulnerable employment (%) 8.2 86.3 17 Saudi Arabia
- 61.2 24 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 14.0 60.0 18 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 66.1 62.4 22 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 37.8 69.6 14 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 44.4 55.6 38 Multiple (4)
7.05 Adjusted labour income share (%) 51.4 58.7 40 Switzerland
- 57.6 47 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 80.0 80.0 32 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.0 49.4 72 Singapore
8.03 Pay and productivity (1–7) 4.0 49.2 53 Switzerland
8.04 Employees working more than 48 hours per week (%) 0.7 98.6 1 Bulgaria
8.05 Collective bargaining coverage ratio (%) 11 10.8 56 France
- 60.9 36 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 30.0 40.0 30 Multiple (2)
9.02 Social protection coverage (% of population) 88.3 88.3 25 Multiple (6)
9.03 Social protection spending (% of GDP) 18.5 74.0 30 Multiple (9)
9.04 Social safety net protection, 1-7 3.5 41.2 62 Norway
- 59.4 46 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 42.0 42.0 49 Denmark
10.02 Government and public services efﬁciency (score) 0.3 58.1 48 Singapore
10.03 Inclusiveness of institutions (score) -0.2 62.1 54 Portugal
10.04 Political stability and protection from violence (score) 0.4 75.3 34 New Zealand

56Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

80th
82nd
67th
73rd
75th
82nd
65th
81st
62nd
82nd
77th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions36 3641
3440
3158
952
1842
Cameroon 80th /82
Index Component Value Score      Rank/ 82 Best Performer
- 36.4 82 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 105.8 0.0 81 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.2 83.5 18 Ghana
1.03 Health Access and Quality Index (0–100 best) 31.9 31.9 80 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 30.0 81 Singapore
- 40.9 67 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 25.3 25.3 65 Malta
2.02 Quality of vocational training (1–7) 4.1 51.4 53 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 17.0 43.3 48 Japan
2.04 Out-of-school children (%) 5.2 48.0 56 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.4 36.7 73 GermanyCameroon 80th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %24.9
34.0
1,548.00.07
46.6
4.0

57Cameroon 80th /82
Index Component Value Score       Rank/ 82 Best Performer
- 33.6 73 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 75.9 0.0 68 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 20.3 49.1 56 Australia
3.03 Pupils per teacher in primary education 44.8 0.0 81 Multiple (3)
3.04 Pupils per teacher in secondary education 13.1 73.0 37 Armenia
3.05 Harmonized learning outcomes (score) 382.8 45.7 70 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 39.9 75 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.5 41.7 77 Switzerland
4.02 Active labour market policies (1–7) 2.5 24.2 74 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.1 35.2 82 Switzerland
4.04 Percentage of ﬁrms of fering formal training 37.6 50.1 22 Ecuador
4.05 Digital skills among active population (1–7) 3.9 48.3 64 Finland
- 30.9 82 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 23.2 23.2 80 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 0.1 0.1 82 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 23.7 19.7 81 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 77.3 77.3 79 Multiple (13)
5.05 Rural population with electricity access (%) 21.3 21.3 82 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.6 43.8 68 Singapore
- 58.2 65 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 2.6 89.7 10 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 7.4 70.2 49 Thailand
6.02 Unemployment among labor force with advanced education (%) 13.3 46.8 73 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 87.4 84.3 9 Lao PDR
6.06 Workers in vulnerable employment (%) 73.5 0.0 80 Saudi Arabia
- 9.2 81 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 31.0 11.5 53 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 6.3 0.0 80 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 7.0 0.0 80 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 36.4 25.3 74 Switzerland
- 51.7 62 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 67.0 67.0 55 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.8 47.0 75 Singapore
8.03 Pay and productivity (1–7) 3.5 41.0 72 Switzerland
8.04 Employees working more than 48 hours per week (%) n/a n/a n/a Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 17.6 82 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 8.7 8.7 56 Multiple (6)
9.03 Social protection spending (% of GDP) 2.3 9.3 75 Multiple (9)
9.04 Social safety net protection, 1-7 3.1 34.7 76 Norway
- 42.2 77 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 25.0 25.0 82 Denmark
10.02 Government and public services efﬁciency (score) -0.8 35.2 82 Singapore
10.03 Inclusiveness of institutions (score) 0.2 72.6 34 Portugal
10.04 Political stability and protection from violence (score) -1.4 35.8 79 New Zealand

58Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

14th
22nd
18th
10th
13th
19th
33rd
22nd
25th
20th
11th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7688
7882
6985
74
63657285
Canada 14th /82
Index Component Value Score      Rank/ 82 Best Performer
- 87.7 22 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 8.4 91.6 27 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 12.9 74.3 55 Ghana
1.03 Health Access and Quality Index (0–100 best) 93.8 93.8 13 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 91.2 18 Singapore
- 78.4 18 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 5.1 67.6 14 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 12.8 57.2 34 Japan
2.04 Out-of-school children (%) 0.0 100.0 1 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 88.7 6 GermanyCanada 14th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %37.0
1,652.4
46,260.71.36
34.0
2.0

59Canada 14th /82
Index Component Value Score       Rank/ 82 Best Performer
- 82.4 10 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 4.3 93.9 25 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 16.2 79.3 38 Multiple (3)
3.04 Pupils per teacher in secondary education 13.1 73.0 35 Armenia
3.05 Harmonized learning outcomes (score) 539.1 84.8 10 Singapore
3.06 Social diversity in schools (score) 84.9 84.3 7 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material21.1 78.9 12 Multiple (2)
- 69.5 13 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.9 64.4 18 Switzerland
4.02 Active labour market policies (1–7) 4.8 63.3 19 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.9 82.3 13 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.1 67.9 15 Finland
- 84.8 19 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 91.0 91.0 10 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 38.6 77.1 13 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 76.7 63.9 49 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.4 99.4 30 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.6 77.5 15 Singapore
- 74.1 33 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 12.9 48.2 63 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 7.0 72.2 46 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.6 81.5 45 Czech Republic
6.04 Unemployment in rural areas (%) 5.9 76.3 44 Peru
6.05 Ratio of female to male labour force participation rate 87.4 84.2 10 Lao PDR
6.06 Workers in vulnerable employment (%) 10.7 82.1 27 Saudi Arabia
- 62.7 22 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 22.0 37.2 40 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 73.8 70.9 15 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 34.7 61.8 23 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 47.3 63.8 33 Multiple (4)
7.05 Adjusted labour income share (%) 61.0 80.0 8 Switzerland
- 64.8 25 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 79.0 79.0 34 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.1 67.5 20 Singapore
8.03 Pay and productivity (1–7) 4.9 65.0 8 Switzerland
8.04 Employees working more than 48 hours per week (%) 7.8 84.5 32 Bulgaria
8.05 Collective bargaining coverage ratio (%) 28 28.1 37 France
- 72.1 20 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 36.0 48.0 23 Multiple (2)
9.02 Social protection coverage (% of population) 99.8 99.8 7 Multiple (6)
9.03 Social protection spending (% of GDP) 17.2 68.9 34 Multiple (9)
9.04 Social safety net protection, 1-7 5.3 71.6 17 Norway
- 84.9 11 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 81.0 81.0 9 Denmark
10.02 Government and public services efﬁciency (score) 1.7 89.0 9 Singapore
10.03 Inclusiveness of institutions (score) 0.6 81.6 9 Portugal
10.04 Political stability and protection from violence (score) 1.0 87.9 13 New Zealand

60Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

47th
51st
59th
59th
39th
42nd
47th
46th
48th
49th
28th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6072
5452 5375
69
4857
5073
Chile 47th /82
Index Component Value Score      Rank/ 82 Best Performer
- 72.2 51 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 41.1 58.9 57 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 16.1 67.8 67 Ghana
1.03 Health Access and Quality Index (0–100 best) 77.9 77.9 39 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 84.2 30 Singapore
- 53.8 59 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 75.5 75.5 36 Malta
2.02 Quality of vocational training (1–7) 4.9 65.3 17 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 15.9 47.1 43 Japan
2.04 Out-of-school children (%) 9.3 7.0 64 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 74.1 37 GermanyChile 47th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %18.5
277.0
16,078.70.36
46.6
3.2