121Korea, Rep. 25th /82
Index Component Value Score       Rank/ 82 Best Performer
- 76.0 29 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 0.3 99.6 1 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 13.0 73.2 30 Australia
3.03 Pupils per teacher in primary education 16.4 78.6 39 Multiple (3)
3.04 Pupils per teacher in secondary education 13.2 72.7 38 Armenia
3.05 Harmonized learning outcomes (score) 566.7 91.7 2 Singapore
3.06 Social diversity in schools (score) 78.9 69.9 16 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material53.7 46.3 42 Multiple (2)
- 68.1 14 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.5 59.2 29 Switzerland
4.02 Active labour market policies (1–7) 4.8 64.1 18 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.9 82.4 12 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.0 66.5 19 Finland
- 92.4 3 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 95.9 95.9 5 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 41.6 83.2 6 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 113.6 94.7 15 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.9 99.9 18 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.9 80.9 10 Singapore
- 78.6 17 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.7 85.2 20 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.7 85.2 12 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.7 85.2 32 Czech Republic
6.04 Unemployment in rural areas (%) 2.6 89.8 14 Peru
6.05 Ratio of female to male labour force participation rate 71.9 64.9 54 Lao PDR
6.06 Workers in vulnerable employment (%) 23.4 61.0 46 Saudi Arabia
- 41.7 56 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 22.3 36.3 44 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 40.2 33.6 54 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 23.1 32.9 56 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 53.8 64.0 30 Switzerland
- 61.3 36 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 64.0 64.0 57 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.6 43.2 79 Singapore
8.03 Pay and productivity (1–7) 4.8 63.8 10 Switzerland
8.04 Employees working more than 48 hours per week (%) 19.1 61.9 52 Bulgaria
8.05 Collective bargaining coverage ratio (%) 74 73.9 13 France
- 55.4 45 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 43.0 57.3 13 Multiple (2)
9.02 Social protection coverage (% of population) 65.7 65.7 38 Multiple (6)
9.03 Social protection spending (% of GDP) 10.1 40.4 55 Multiple (9)
9.04 Social safety net protection, 1-7 4.5 58.2 31 Norway
- 73.8 25 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 57.0 57.0 34 Denmark
10.02 Government and public services efﬁciency (score) 1.2 77.6 23 Singapore
10.03 Inclusiveness of institutions (score) 0.6 82.4 7 Portugal
10.04 Political stability and protection from violence (score) 0.5 78.1 28 New Zealand

122Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

72nd
74th
76th
58th
65th
77th
66th
78th
37th
78th
58th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4454
3152
44 4558
1961
2351
Lao PDR 72nd /82
Index Component Value Score      Rank/ 82 Best Performer
- 54.4 74 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 65.4 34.6 69 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.1 99.7 6 Ghana
1.03 Health Access and Quality Index (0–100 best) 36.6 36.6 79 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 46.8 76 Singapore
- 31.0 76 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 46.5 46.5 58 Malta
2.02 Quality of vocational training (1–7) 3.7 45.7 64 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 42.1 0.0 78 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.3 32.0 77 GermanyLao PDR 72nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %6.8
17.0
2,720.30.04
36.4
6.5

123Lao PDR 72nd /82
Index Component Value Score       Rank/ 82 Best Performer
- 52.0 58 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 18.2 55.9 51 Australia
3.03 Pupils per teacher in primary education 22.3 58.9 62 Multiple (3)
3.04 Pupils per teacher in secondary education 20.0 49.9 60 Armenia
3.05 Harmonized learning outcomes (score) 373.6 43.4 72 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 43.7 65 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.0 49.9 49 Switzerland
4.02 Active labour market policies (1–7) 3.2 36.8 55 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.8 47.2 76 Switzerland
4.04 Percentage of ﬁrms of fering formal training 24.4 32.5 34 Ecuador
4.05 Digital skills among active population (1–7) 4.1 52.3 58 Finland
- 45.1 77 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 25.5 25.5 79 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 0.6 1.3 80 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 42.0 35.0 75 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 78.0 78.0 77 Multiple (13)
5.05 Rural population with electricity access (%) 90.5 90.5 70 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.4 40.5 73 Singapore
- 58.0 66 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 11.0 55.9 58 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 6.5 74.1 44 Thailand
6.02 Unemployment among labor force with advanced education (%) 6.9 72.4 58 Czech Republic
6.04 Unemployment in rural areas (%) 12.4 50.4 62 Peru
6.05 Ratio of female to male labour force participation rate 96.3 95.3 1 Lao PDR
6.06 Workers in vulnerable employment (%) 79.5 0.0 82 Saudi Arabia
- 18.7 78 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 10.6 0.7 78 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 10.2 0.4 78 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 49.7 54.9 46 Switzerland
- 61.0 37 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 62.0 62.0 65 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.7 61.0 36 Singapore
8.03 Pay and productivity (1–7) 4.4 55.9 34 Switzerland
8.04 Employees working more than 48 hours per week (%) 17.5 64.9 49 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 23.1 78 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 1.2 4.8 79 Multiple (9)
9.04 Social safety net protection, 1-7 3.5 41.4 61 Norway
- 51.0 58 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 29.0 29.0 75 Denmark
10.02 Government and public services efﬁciency (score) -0.7 38.0 79 Singapore
10.03 Inclusiveness of institutions (score) -0.2 61.8 55 Portugal
10.04 Political stability and protection from violence (score) 0.4 75.2 35 New Zealand

124Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

31st
35th
26th
8th
37th
18th
51st
39th
29th
31st
36th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6980
7483
5585
68
5163 6367
Latvia 31st /82
Index Component Value Score      Rank/ 82 Best Performer
- 79.7 35 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 16.2 83.8 39 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.0 81.9 24 Ghana
1.03 Health Access and Quality Index (0–100 best) 80.7 80.7 36 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 72.3 55 Singapore
- 74.5 26 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 93.5 93.5 11 Malta
2.02 Quality of vocational training (1–7) 4.2 53.5 48 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 7.8 73.9 15 Japan
2.04 Out-of-school children (%) 3.2 68.0 48 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 83.4 20 GermanyLatvia 31st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %1.9
30.3
18,032.00.04
34.2
2.5

125Latvia 31st /82
Index Component Value Score       Rank/ 82 Best Performer
- 83.4 8 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 0.8 98.9 2 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 10.3 82.4 14 Australia
3.03 Pupils per teacher in primary education 12.1 93.1 16 Multiple (3)
3.04 Pupils per teacher in secondary education 10.4 81.9 19 Armenia
3.05 Harmonized learning outcomes (score) 539.1 84.8 9 Singapore
3.06 Social diversity in schools (score) 77.1 65.4 22 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material22.8 77.2 15 Multiple (2)
- 55.5 37 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.4 57.1 34 Switzerland
4.02 Active labour market policies (1–7) 4.4 57.3 29 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.0 66.3 33 Switzerland
4.04 Percentage of ﬁrms of fering formal training 25.2 33.6 33 Ecuador
4.05 Digital skills among active population (1–7) 4.8 63.1 29 Finland
- 84.9 18 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 83.6 83.6 25 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 27.3 54.6 35 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 130.2 100.0 9 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.0 99.0 37 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.3 72.1 22 Singapore
- 67.9 51 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 18.5 25.9 75 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 8.5 66.0 58 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.7 85.4 31 Czech Republic
6.04 Unemployment in rural areas (%) 8.5 66.0 51 Peru
6.05 Ratio of female to male labour force participation rate 81.7 77.1 30 Lao PDR
6.06 Workers in vulnerable employment (%) 7.9 86.9 14 Saudi Arabia
- 51.1 39 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 26.0 25.6 50 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 54.7 49.6 33 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 30.6 51.4 32 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 48.0 65.6 30 Multiple (4)
7.05 Adjusted labour income share (%) 53.4 63.1 31 Switzerland
- 63.1 29 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 86.0 86.0 23 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.9 64.9 29 Singapore
8.03 Pay and productivity (1–7) 4.2 54.1 39 Switzerland
8.04 Employees working more than 48 hours per week (%) 1.8 96.5 3 Bulgaria
8.05 Collective bargaining coverage ratio (%) 14 13.8 53 France
- 63.0 31 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 33.0 44.0 28 Multiple (2)
9.02 Social protection coverage (% of population) 96.5 96.5 12 Multiple (6)
9.03 Social protection spending (% of GDP) 14.4 57.7 44 Multiple (9)
9.04 Social safety net protection, 1-7 4.2 53.9 39 Norway
- 66.8 36 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 58.0 58.0 31 Denmark
10.02 Government and public services efﬁciency (score) 1.0 74.6 29 Singapore
10.03 Inclusiveness of institutions (score) -0.3 59.3 61 Portugal
10.04 Political stability and protection from violence (score) 0.4 75.4 33 New Zealand

126Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

26th
33rd
15th
9th
28th
22nd
53rd
43rd
27th
33rd
29th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions70817983
6284
67
4964 6373
Lithuania 26th /82
Index Component Value Score      Rank/ 82 Best Performer
- 80.7 33 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 10.9 89.1 31 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.4 81.1 31 Ghana
1.03 Health Access and Quality Index (0–100 best) 80.5 80.5 37 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 71.9 57 Singapore
- 79.3 15 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 88.0 88.0 21 Malta
2.02 Quality of vocational training (1–7) 4.2 54.2 44 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 8.0 73.2 16 Japan
2.04 Out-of-school children (%) 0.3 97.0 10 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 84.0 18 GermanyLithuania 26th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %2.8
47.3
19,143.40.07
37.4
3.0

127Lithuania 26th /82
Index Component Value Score       Rank/ 82 Best Performer
- 83.2 9 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.7 96.1 16 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 10.8 80.5 16 Australia
3.03 Pupils per teacher in primary education 10.6 97.9 5 Multiple (3)
3.04 Pupils per teacher in secondary education 8.0 90.1 5 Armenia
3.05 Harmonized learning outcomes (score) 520.3 80.1 25 Singapore
3.06 Social diversity in schools (score) 74.6 59.5 35 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material21.9 78.1 14 Multiple (2)
- 62.2 28 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.8 63.0 20 Switzerland
4.02 Active labour market policies (1–7) 4.3 54.7 31 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.4 73.1 29 Switzerland
4.04 Percentage of ﬁrms of fering formal training 42.0 56.0 16 Ecuador
4.05 Digital skills among active population (1–7) 4.9 64.2 26 Finland
- 83.5 22 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 79.7 79.7 35 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 28.2 56.3 32 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 100.6 83.8 22 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 14 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.9 81.4 8 Singapore
- 67.4 53 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 20.2 19.2 77 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 8.0 68.0 53 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.8 88.8 16 Czech Republic
6.04 Unemployment in rural areas (%) 9.1 63.7 52 Peru
6.05 Ratio of female to male labour force participation rate 84.6 80.7 19 Lao PDR
6.06 Workers in vulnerable employment (%) 9.5 84.2 21 Saudi Arabia
- 48.7 43 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 21.3 39.2 36 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 55.4 50.5 32 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 29.8 49.6 34 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 44.0 54.3 42 Multiple (4)
7.05 Adjusted labour income share (%) 47.6 50.2 55 Switzerland
- 63.9 27 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 91.0 91.0 12 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.9 64.2 30 Singapore
8.03 Pay and productivity (1–7) 4.6 60.0 24 Switzerland
8.04 Employees working more than 48 hours per week (%) 1.4 97.3 2 Bulgaria
8.05 Collective bargaining coverage ratio (%) 7 7.1 59 France
- 62.9 33 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 42.0 56.0 14 Multiple (2)
9.02 Social protection coverage (% of population) 92.7 92.7 17 Multiple (6)
9.03 Social protection spending (% of GDP) 14.7 58.8 43 Multiple (9)
9.04 Social safety net protection, 1-7 3.7 44.2 57 Norway
- 72.6 29 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 59.0 59.0 28 Denmark
10.02 Government and public services efﬁciency (score) 1.1 75.2 28 Singapore
10.03 Inclusiveness of institutions (score) 0.3 73.5 33 Portugal
10.04 Political stability and protection from violence (score) 0.8 82.7 23 New Zealand

128Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

10th
12th
20th
11th
6th
17th
11th
19th
13th
13th
2nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions8091
7882
7787
80
65717889
Luxembourg 10th /82
Index Component Value Score      Rank/ 82 Best Performer
- 90.6 12 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 4.7 95.3 10 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.4 81.3 30 Ghana
1.03 Health Access and Quality Index (0–100 best) 96.0 96.0 4 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 89.7 21 Singapore
- 78.3 20 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 88.4 88.4 20 Malta
2.02 Quality of vocational training (1–7) 5.2 70.6 9 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 5.3 82.4 6 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 71.8 40 GermanyLuxembourg 10th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %0.6
62.4
114,234.20.05
33.8
2.5

129Luxembourg 10th /82
Index Component Value Score       Rank/ 82 Best Performer
- 82.2 11 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 11.5 78.5 17 Australia
3.03 Pupils per teacher in primary education 9.0 100.0 2 Multiple (3)
3.04 Pupils per teacher in secondary education 9.2 86.2 9 Armenia
3.05 Harmonized learning outcomes (score) 499.8 75.0 40 Singapore
3.06 Social diversity in schools (score) 72.2 53.5 39 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material0.0 100.0 1 Multiple (2)
- 76.5 6 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.5 75.1 3 Switzerland
4.02 Active labour market policies (1–7) 5.5 75.4 4 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.1 85.7 8 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.2 69.8 14 Finland
- 86.9 17 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 97.1 97.1 3 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 37.1 74.2 15 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 94.0 78.3 30 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.0 99.0 37 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.4 72.8 21 Singapore
- 80.1 11 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 8.8 64.7 40 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.6 77.7 32 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.2 83.0 42 Czech Republic
6.04 Unemployment in rural areas (%) 4.2 83.4 27 Peru
6.05 Ratio of female to male labour force participation rate 85.5 81.9 12 Lao PDR
6.06 Workers in vulnerable employment (%) 6.2 89.7 9 Saudi Arabia
- 64.8 19 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 12.2 65.3 15 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 69.3 65.9 21 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 33.5 58.7 25 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 47.7 65.0 32 Multiple (4)
7.05 Adjusted labour income share (%) 56.2 69.3 24 Switzerland
- 71.1 13 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) n/a n/a n/a Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.7 78.3 6 Singapore
8.03 Pay and productivity (1–7) 4.6 60.8 17 Switzerland
8.04 Employees working more than 48 hours per week (%) 7.0 86.1 29 Bulgaria
8.05 Collective bargaining coverage ratio (%) 59 59.0 19 France
- 78.3 13 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 47.0 62.7 10 Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 22.2 88.7 19 Multiple (9)
9.04 Social safety net protection, 1-7 6.0 83.4 7 Norway
- 89.2 2 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 81.0 81.0 9 Denmark
10.02 Government and public services efﬁciency (score) 1.8 90.3 8 Singapore
10.03 Inclusiveness of institutions (score) n/a n/a n/a Portugal
10.04 Political stability and protection from violence (score) 1.4 96.3 4 New Zealand

130Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

43rd
50th
29th
43rd
29th
34th
24th
67th
55th
57th
41st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6273 7270
627876
3355
4261
Malaysia 43rd /82
Index Component Value Score      Rank/ 82 Best Performer
- 72.6 50 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 13.4 86.6 37 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 20.4 59.2 77 Ghana
1.03 Health Access and Quality Index (0–100 best) 68.1 68.1 57 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 76.4 47 Singapore
- 71.9 29 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 83.4 83.4 28 Malta
2.02 Quality of vocational training (1–7) 5.1 68.1 12 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 11.7 61.0 30 Japan
2.04 Out-of-school children (%) 1.4 86.0 28 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 60.7 54 GermanyMalaysia 43rd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %32.4
314.5
10,941.70.74
41.0
4.8

131Malaysia 43rd /82
Index Component Value Score       Rank/ 82 Best Performer
- 70.1 43 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 11.7 83.3 36 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 18.1 56.3 49 Australia
3.03 Pupils per teacher in primary education 11.7 94.5 13 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 472.9 68.2 44 Singapore
3.06 Social diversity in schools (score) 69.0 45.9 44 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material27.8 72.2 21 Multiple (2)
- 61.8 29 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.3 71.0 8 Switzerland
4.02 Active labour market policies (1–7) 4.9 64.7 15 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.5 75.7 24 Switzerland
4.04 Percentage of ﬁrms of fering formal training 18.5 24.7 40 Ecuador
4.05 Digital skills among active population (1–7) 5.4 72.8 10 Finland
- 77.5 34 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 81.2 81.2 30 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 8.6 17.1 62 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 116.7 97.3 13 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 96.3 96.3 55 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.4 73.2 19 Singapore
- 76.1 24 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 2.1 91.7 7 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.1 83.6 15 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.1 83.8 36 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 65.9 57.3 63 Lao PDR
6.06 Workers in vulnerable employment (%) 21.6 64.0 45 Saudi Arabia
- 32.6 67 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 28.3 19.1 51 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 39.1 32.4 55 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 22.6 31.6 58 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 39.9 42.4 50 Multiple (4)
7.05 Adjusted labour income share (%) 41.8 37.3 67 Switzerland
- 54.6 55 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 73.0 73.0 41 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.4 72.6 11 Singapore
8.03 Pay and productivity (1–7) 5.2 70.3 4 Switzerland
8.04 Employees working more than 48 hours per week (%) 22.0 55.9 54 Bulgaria
8.05 Collective bargaining coverage ratio (%) 1 1.3 67 France
- 41.7 57 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 3.8 15.1 71 Multiple (9)
9.04 Social safety net protection, 1-7 5.1 68.3 20 Norway
- 60.8 41 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 47.0 47.0 41 Denmark
10.02 Government and public services efﬁciency (score) 1.1 75.3 27 Singapore
10.03 Inclusiveness of institutions (score) -0.6 49.4 68 Portugal
10.04 Political stability and protection from violence (score) 0.2 71.3 41 New Zealand

132Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

17th
6th
21st
31st
26th
14th
12th
9th
31st
34th
20th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7592
7775
6489
80
74
63 6276
Malta 17th /82
Index Component Value Score      Rank/ 82 Best Performer
- 91.5 6 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 12.9 87.1 34 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.1 99.7 7 Ghana
1.03 Health Access and Quality Index (0–100 best) 89.9 89.9 26 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 89.4 23 Singapore
- 77.1 21 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 99.8 99.8 1 Malta
2.02 Quality of vocational training (1–7) 4.5 57.8 37 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 7.3 75.8 14 Japan
2.04 Out-of-school children (%) 2.4 76.0 39 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 76.2 34 GermanyMalta 17th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %0.5
12.5
31,058.40.02
29.4
4.8

133Malta 17th /82
Index Component Value Score       Rank/ 82 Best Performer
- 75.2 31 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 26.8 61.7 44 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.1 76.5 22 Australia
3.03 Pupils per teacher in primary education 13.0 89.9 21 Multiple (3)
3.04 Pupils per teacher in secondary education 7.6 91.2 4 Armenia
3.05 Harmonized learning outcomes (score) 482.7 70.7 42 Singapore
3.06 Social diversity in schools (score) 81.9 76.9 11 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material40.6 59.4 30 Multiple (2)
- 63.5 26 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.1 50.9 44 Switzerland
4.02 Active labour market policies (1–7) 4.9 65.1 14 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.6 76.1 23 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.7 62.0 32 Finland
- 88.5 14 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 81.4 81.4 29 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 43.7 87.3 4 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 110.5 92.1 17 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.2 70.3 25 Singapore
- 79.7 12 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 5.6 77.7 27 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.2 87.3 8 Thailand
6.02 Unemployment among labor force with advanced education (%) 1.9 92.3 6 Czech Republic
6.04 Unemployment in rural areas (%) 4.9 80.6 38 Peru
6.05 Ratio of female to male labour force participation rate 65.5 56.9 64 Lao PDR
6.06 Workers in vulnerable employment (%) 9.8 83.6 24 Saudi Arabia
- 74.1 9 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 83.7 81.9 8 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 40.8 77.0 8 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 54.7 84.9 15 Multiple (4)
7.05 Adjusted labour income share (%) 48.6 52.4 51 Switzerland
- 62.8 31 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) n/a n/a n/a Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.0 67.0 21 Singapore
8.03 Pay and productivity (1–7) 4.3 55.1 37 Switzerland
8.04 Employees working more than 48 hours per week (%) 6.4 87.2 24 Bulgaria
8.05 Collective bargaining coverage ratio (%) 42 41.8 30 France
- 62.2 34 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 36.0 48.0 23 Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 18.2 72.8 32 Multiple (9)
9.04 Social safety net protection, 1-7 5.0 65.9 26 Norway
- 75.7 20 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 54.0 54.0 36 Denmark
10.02 Government and public services efﬁciency (score) 1.0 73.0 31 Singapore
10.03 Inclusiveness of institutions (score) 0.6 81.1 11 Portugal
10.04 Political stability and protection from violence (score) 1.3 94.6 6 New Zealand

134Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

58th
66th
45th
68th
64th
58th
32nd
61st
70th
51st
71st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5361 62
39456674
3747 48 47
Mexico 58th /82
Index Component Value Score      Rank/ 82 Best Performer
- 61.3 66 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 60.4 39.6 67 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 16.3 67.3 69 Ghana
1.03 Health Access and Quality Index (0–100 best) 66.3 66.3 61 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 71.9 58 Singapore
- 61.8 45 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 72.2 72.2 44 Malta
2.02 Quality of vocational training (1–7) 4.2 53.9 46 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 18.4 38.6 53 Japan
2.04 Out-of-school children (%) 1.2 88.0 25 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 56.2 63 GermanyMexico 58th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %124.7
1,149.2
9,807.41.90
48.3
2.6

135Mexico 58th /82
Index Component Value Score       Rank/ 82 Best Performer
- 39.1 68 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 42.5 39.3 51 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 25.0 33.3 64 Australia
3.03 Pupils per teacher in primary education 26.6 44.8 70 Multiple (3)
3.04 Pupils per teacher in secondary education 23.0 40.1 63 Armenia
3.05 Harmonized learning outcomes (score) 429.4 57.4 55 Singapore
3.06 Social diversity in schools (score) 61.7 28.3 57 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material69.2 30.8 53 Multiple (2)
- 44.6 64 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.8 47.0 60 Switzerland
4.02 Active labour market policies (1–7) 2.8 29.3 68 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.4 56.1 50 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 3.8 46.0 70 Finland
- 65.6 58 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 65.8 65.8 53 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 14.6 29.3 51 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 70.0 58.3 59 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 91.4 91.4 69 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.9 49.1 60 Singapore
- 74.4 32 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.2 87.2 14 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.0 84.0 14 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.1 83.4 40 Czech Republic
6.04 Unemployment in rural areas (%) 2.0 91.9 8 Peru
6.05 Ratio of female to male labour force participation rate 55.7 44.6 72 Lao PDR
6.06 Workers in vulnerable employment (%) 26.7 55.4 52 Saudi Arabia
- 37.1 61 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 16.1 54.0 26 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 47.1 41.3 42 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 27.6 44.0 42 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 33.7 24.9 60 Multiple (4)
7.05 Adjusted labour income share (%) 34.6 21.3 77 Switzerland
- 46.8 70 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 71.0 71.0 48 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 59.1 42 Singapore
8.03 Pay and productivity (1–7) 3.8 46.4 58 Switzerland
8.04 Employees working more than 48 hours per week (%) 28.2 43.7 61 Bulgaria
8.05 Collective bargaining coverage ratio (%) 14 13.8 53 France
- 48.2 51 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 50.3 50.3 42 Multiple (6)
9.03 Social protection spending (% of GDP) 12.0 47.8 48 Multiple (9)
9.04 Social safety net protection, 1-7 3.8 46.6 55 Norway
- 47.3 71 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 28.0 28.0 78 Denmark
10.02 Government and public services efﬁciency (score) -0.2 49.1 62 Singapore
10.03 Inclusiveness of institutions (score) -0.3 58.8 63 Portugal
10.04 Political stability and protection from violence (score) -0.6 53.5 68 New Zealand

136Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

49th
44th
71st
51st
59th
47th
22nd
16th
44th
47th
73rd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6074
3864
477177
67
59
54
47
Moldova 49th /82
Index Component Value Score      Rank/ 82 Best Performer
- 74.1 44 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 22.4 77.6 46 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 6.9 86.3 12 Ghana
1.03 Health Access and Quality Index (0–100 best) 67.4 67.4 59 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 65.0 64 Singapore
- 38.2 71 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 3.5 41.6 74 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 27.8 7.2 69 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 65.8 50 GermanyMoldova 49th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %3.5
8.1
3,217.70.02
25.9
3.8

137Moldova 49th /82
Index Component Value Score       Rank/ 82 Best Performer
- 63.9 51 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 11.9 77.1 20 Australia
3.03 Pupils per teacher in primary education 17.9 73.6 52 Multiple (3)
3.04 Pupils per teacher in secondary education 10.1 83.0 14 Armenia
3.05 Harmonized learning outcomes (score) 445.7 61.4 50 Singapore
3.06 Social diversity in schools (score) 72.1 53.4 40 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material65.3 34.7 50 Multiple (2)
- 46.5 59 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 42.8 76 Switzerland
4.02 Active labour market policies (1–7) 3.1 34.7 57 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 54.4 58 Switzerland
4.04 Percentage of ﬁrms of fering formal training 32.4 43.2 27 Ecuador
4.05 Digital skills among active population (1–7) 4.5 57.6 43 Finland
- 71.2 47 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 76.1 76.1 38 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 15.4 30.8 49 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 72.8 60.6 56 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.6 59.5 43 Singapore
- 76.5 22 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 4.2 83.3 21 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.1 87.7 6 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.1 87.6 21 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 84.6 80.8 18 Lao PDR
6.06 Workers in vulnerable employment (%) 34.0 43.3 58 Saudi Arabia
- 66.6 16 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 49.2 43.5 38 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 29.3 48.2 37 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 60.2 100.0 4 Multiple (4)
7.05 Adjusted labour income share (%) 58.7 74.9 13 Switzerland
- 59.0 44 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 83.0 83.0 26 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.4 57.5 50 Singapore
8.03 Pay and productivity (1–7) 4.1 52.4 45 Switzerland
8.04 Employees working more than 48 hours per week (%) n/a n/a n/a Bulgaria
8.05 Collective bargaining coverage ratio (%) 43 43.0 29 France
- 53.6 47 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 18.1 72.6 33 Multiple (9)
9.04 Social safety net protection, 1-7 3.1 34.5 77 Norway
- 46.6 73 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 33.0 33.0 70 Denmark
10.02 Government and public services efﬁciency (score) -0.5 42.4 73 Singapore
10.03 Inclusiveness of institutions (score) -0.5 52.8 64 Portugal
10.04 Political stability and protection from violence (score) -0.3 58.4 59 New Zealand

138Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

73rd
52nd
65th
66th
76th
66th
82nd
76th
69th
68th
72nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4472
47
40 4059
30
2447
3347
Morocco 73rd /82
Index Component Value Score      Rank/ 82 Best Performer
- 72.1 52 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 31.0 69.0 53 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.2 99.7 8 Ghana
1.03 Health Access and Quality Index (0–100 best) 57.6 57.6 68 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 62.2 68 Singapore
- 46.5 65 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 47.4 47.4 57 Malta
2.02 Quality of vocational training (1–7) 3.8 46.2 63 Switzerland
2.03 NEET ratio (% of 15–24 year olds) n/a n/a n/a Japan
2.04 Out-of-school children (%) 5.4 46.0 57 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) n/a n/a n/a GermanyMorocco 73rd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %35.2
109.8
3,359.10.23
39.5
3.1

139Morocco 73rd /82
Index Component Value Score       Rank/ 82 Best Performer
- 40.0 66 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 63.8 8.9 60 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 18.1 56.2 50 Australia
3.03 Pupils per teacher in primary education 26.8 44.0 71 Multiple (3)
3.04 Pupils per teacher in secondary education 15.8 63.9 52 Armenia
3.05 Harmonized learning outcomes (score) 375.7 43.9 71 Singapore
3.06 Social diversity in schools (score) 66.0 38.6 47 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material75.1 24.9 59 Multiple (2)
- 39.8 76 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.6 71 Switzerland
4.02 Active labour market policies (1–7) 2.4 23.5 76 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.9 48.8 70 Switzerland
4.04 Percentage of ﬁrms of fering formal training 26.3 35.1 32 Ecuador
4.05 Digital skills among active population (1–7) 3.9 48.0 65 Finland
- 59.1 66 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 64.8 64.8 56 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 4.3 8.6 70 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 59.1 49.2 66 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.0 98.0 48 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.0 33.8 81 Singapore
- 29.7 82 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 10.3 58.7 52 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 18.1 27.7 79 Thailand
6.02 Unemployment among labor force with advanced education (%) n/a n/a n/a Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 30.4 13.0 79 Lao PDR
6.06 Workers in vulnerable employment (%) 48.4 19.4 70 Saudi Arabia
- 23.8 76 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 21.3 12.6 72 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 17.0 17.6 71 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 43.5 41.1 63 Switzerland
- 46.9 69 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 75.0 75.0 39 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.1 52.0 68 Singapore
8.03 Pay and productivity (1–7) 3.7 45.5 60 Switzerland
8.04 Employees working more than 48 hours per week (%) 42.5 15.0 73 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 32.9 68 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 6.6 26.3 59 Multiple (9)
9.04 Social safety net protection, 1-7 3.4 39.5 65 Norway
- 46.7 72 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 43.0 43.0 46 Denmark
10.02 Government and public services efﬁciency (score) -0.2 47.9 63 Singapore
10.03 Inclusiveness of institutions (score) -1.1 37.2 80 Portugal
10.04 Political stability and protection from violence (score) -0.3 58.8 57 New Zealand

140Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

6th
5th
1st
23rd
5th
10th
7th
14th
4th
6th
10th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions829288
77 7889
82
6982 8285
Netherlands 6th/82
Index Component Value Score      Rank/ 82 Best Performer
- 91.9 5 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 3.8 96.2 6 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.0 83.9 16 Ghana
1.03 Health Access and Quality Index (0–100 best) 96.1 96.1 3 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 91.4 17 Singapore
- 88.1 1 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 94.3 94.3 9 Malta
2.02 Quality of vocational training (1–7) 5.6 77.1 3 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 4.2 86.1 3 Japan
2.04 Out-of-school children (%) 0.3 97.0 10 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 85.8 15 GermanyNetherlands 6th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %17.2
825.8
53,106.40.72
28.2
1.3

141Netherlands 6th/82
Index Component Value Score       Rank/ 82 Best Performer
- 77.0 23 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 1.3 98.1 7 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 16.2 62.6 44 Australia
3.03 Pupils per teacher in primary education 16.7 77.8 42 Multiple (3)
3.04 Pupils per teacher in secondary education 18.0 56.6 56 Armenia
3.05 Harmonized learning outcomes (score) 531.8 83.0 14 Singapore
3.06 Social diversity in schools (score) 78.2 68.0 20 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material7.1 92.9 3 Multiple (2)
- 77.8 5 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.3 72.4 5 Switzerland
4.02 Active labour market policies (1–7) 5.2 70.1 7 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.5 91.4 2 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.6 77.1 4 Finland
- 89.0 10 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 94.7 94.7 7 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 42.4 84.7 5 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 90.9 75.7 34 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.0 99.0 37 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.8 79.9 11 Singapore
- 81.9 7 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 8.2 67.1 37 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.6 85.4 11 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.5 90.1 13 Czech Republic
6.04 Unemployment in rural areas (%) 2.7 89.2 16 Peru
6.05 Ratio of female to male labour force participation rate 84.4 80.5 20 Lao PDR
6.06 Workers in vulnerable employment (%) 12.6 79.0 35 Saudi Arabia
- 68.9 14 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 14.5 58.6 20 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 58.8 54.3 28 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 32.4 55.9 27 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 56.3 89.5 11 Multiple (4)
7.05 Adjusted labour income share (%) 63.9 86.4 3 Switzerland
- 81.6 4 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 95.0 95.0 8 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.8 80.8 4 Singapore
8.03 Pay and productivity (1–7) 4.8 63.5 12 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.9 90.2 16 Bulgaria
8.05 Collective bargaining coverage ratio (%) 79 78.6 11 France
- 82.5 6 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 46.0 61.3 11 Multiple (2)
9.02 Social protection coverage (% of population) 97.5 97.5 11 Multiple (6)
9.03 Social protection spending (% of GDP) 22.3 89.3 17 Multiple (9)
9.04 Social safety net protection, 1-7 5.9 81.8 8 Norway
- 84.9 10 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 82.0 82.0 8 Denmark
10.02 Government and public services efﬁciency (score) 1.9 91.9 6 Singapore
10.03 Inclusiveness of institutions (score) 0.5 80.7 13 Portugal
10.04 Political stability and protection from violence (score) 0.9 85.2 20 New Zealand

142Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

22nd
32nd
19th
13th
18th
9th
23rd
42nd
34th
27th
1st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions74827882
6789
76
49626890
New Zealand 22nd /82
Index Component Value Score      Rank/ 82 Best Performer
- 81.7 32 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 19.3 80.7 40 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 16.6 66.9 71 Ghana
1.03 Health Access and Quality Index (0–100 best) 92.4 92.4 15 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 86.9 28 Singapore
- 78.3 19 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 93.1 93.1 13 Malta
2.02 Quality of vocational training (1–7) 4.8 63.2 23 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 11.9 60.3 31 Japan
2.04 Out-of-school children (%) 1.5 85.0 31 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 90.1 3 GermanyNew Zealand 22nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
10-year average annual GDP growth %4.9
201.5
41,266.80.15
2.5

143New Zealand 22nd /82
Index Component Value Score       Rank/ 82 Best Performer
- 81.9 13 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 10.0 85.7 35 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 6.3 95.6 5 Australia
3.03 Pupils per teacher in primary education 16.9 77.0 45 Multiple (3)
3.04 Pupils per teacher in secondary education 13.0 73.4 34 Armenia
3.05 Harmonized learning outcomes (score) 521.5 80.4 24 Singapore
3.06 Social diversity in schools (score) 82.4 78.2 9 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material16.7 83.3 7 Multiple (2)
- 67.0 18 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.8 62.9 21 Switzerland
4.02 Active labour market policies (1–7) 4.7 61.4 21 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.7 78.2 20 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.9 65.5 23 Finland
- 89.4 9 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 90.8 90.8 11 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 34.7 69.4 18 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 114.5 95.4 14 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.0 98.0 48 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 6.0 82.8 4 Singapore
- 76.5 23 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.4 62.2 46 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 6.3 74.9 42 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.0 84.1 35 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 85.4 81.7 14 Lao PDR
6.06 Workers in vulnerable employment (%) 12.3 79.5 34 Saudi Arabia
- 49.5 42 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 11.2 68.0 12 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 43.2 36.9 49 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 23.9 34.7 54 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 51.2 58.2 42 Switzerland
- 61.6 34 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 89.0 89.0 18 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.1 67.9 19 Singapore
8.03 Pay and productivity (1–7) 4.6 60.5 19 Switzerland
8.04 Employees working more than 48 hours per week (%) 12.5 75.0 41 Bulgaria
8.05 Collective bargaining coverage ratio (%) 15 15.3 51 France
- 67.8 27 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 38.0 50.7 20 Multiple (2)
9.02 Social protection coverage (% of population) 66.6 66.6 36 Multiple (6)
9.03 Social protection spending (% of GDP) 19.7 78.7 23 Multiple (9)
9.04 Social safety net protection, 1-7 5.5 75.2 14 Norway
- 89.5 1 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 87.0 87.0 2 Denmark
10.02 Government and public services efﬁciency (score) 1.7 88.0 11 Singapore
10.03 Inclusiveness of institutions (score) 0.6 83.0 6 Portugal
10.04 Political stability and protection from violence (score) 1.5 100.0 1 New Zealand

144Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

2nd
11th
2nd
5th
9th
7th
2nd
6th
6th
9th
6th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions84918785
7490
84
77798287
Norway 2nd/82
Index Component Value Score      Rank/ 82 Best Performer
- 90.9 11 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 5.1 94.9 13 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.8 80.4 32 Ghana
1.03 Health Access and Quality Index (0–100 best) 96.6 96.6 2 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 91.9 14 Singapore
- 86.5 2 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 95.2 95.2 7 Malta
2.02 Quality of vocational training (1–7) 5.2 69.8 10 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 4.8 83.8 4 Japan
2.04 Out-of-school children (%) 0.2 98.0 7 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 85.9 14 GermanyNorway 2nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %5.3
396.5
81,694.60.29
27.5
1.4

145Norway 2nd/82
Index Component Value Score       Rank/ 82 Best Performer
- 85.5 5 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 5.8 91.7 30 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 14.4 68.8 34 Australia
3.03 Pupils per teacher in primary education 10.2 99.5 4 Multiple (3)
3.04 Pupils per teacher in secondary education 10.1 83.0 16 Armenia
3.05 Harmonized learning outcomes (score) 517.9 79.5 28 Singapore
3.06 Social diversity in schools (score) 91.4 100.0 1 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material24.0 76.0 16 Multiple (2)
- 73.6 9 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.1 68.2 12 Switzerland
4.02 Active labour market policies (1–7) 5.2 69.5 8 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.1 85.0 10 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.3 71.6 13 Finland
- 89.8 7 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 96.5 96.5 4 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 41.3 82.7 7 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 99.7 83.1 23 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.9 99.9 18 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.6 76.5 17 Singapore
- 84.5 2 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.4 62.5 43 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.5 86.0 10 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.3 90.7 11 Czech Republic
6.04 Unemployment in rural areas (%) 3.2 87.2 18 Peru
6.05 Ratio of female to male labour force participation rate 90.5 88.2 3 Lao PDR
6.06 Workers in vulnerable employment (%) 4.7 92.1 3 Saudi Arabia
- 76.7 6 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 81.8 79.8 10 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 39.4 73.6 10 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 57.2 92.0 10 Multiple (4)
7.05 Adjusted labour income share (%) 52.7 61.6 35 Switzerland
- 79.5 6 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 97.0 97.0 6 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.7 77.5 8 Singapore
8.03 Pay and productivity (1–7) 4.5 58.8 29 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.2 91.6 9 Bulgaria
8.05 Collective bargaining coverage ratio (%) 73 72.5 14 France
- 81.5 9 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 36.0 48.0 23 Multiple (2)
9.02 Social protection coverage (% of population) 95.8 95.8 13 Multiple (6)
9.03 Social protection spending (% of GDP) 23.9 95.6 12 Multiple (9)
9.04 Social safety net protection, 1-7 6.2 86.7 1 Norway
- 87.4 6 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 84.0 84.0 7 Denmark
10.02 Government and public services efﬁciency (score) 1.9 92.6 4 Singapore
10.03 Inclusiveness of institutions (score) 0.6 81.6 10 Portugal
10.04 Political stability and protection from violence (score) 1.2 91.5 7 New Zealand

146Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

79th
77th
78th
82nd
50th
81st
67th
72nd
65th
77th
82nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions3748
27
1649
3657
2650
2434
Pakistan 79th /82
Index Component Value Score      Rank/ 82 Best Performer
- 48.3 77 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 38.8 61.2 55 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 22.3 55.4 80 Ghana
1.03 Health Access and Quality Index (0–100 best) 37.6 37.6 78 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 38.8 80 Singapore
- 27.4 78 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 66.4 66.4 47 Malta
2.02 Quality of vocational training (1–7) 3.9 48.6 58 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 31.0 0.0 72 Japan
2.04 Out-of-school children (%) 27.3 0.0 70 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.2 22.1 80 GermanyPakistan 79th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %201.0
304.0
1,555.40.84
33.5
3.6

147Pakistan 79th /82
Index Component Value Score       Rank/ 82 Best Performer
- 15.7 82 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 65.0 7.1 62 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 44.3 0.0 80 Multiple (3)
3.04 Pupils per teacher in secondary education 29.0 20.0 70 Armenia
3.05 Harmonized learning outcomes (score) 342.9 35.7 79 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 49.1 50 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.0 50.2 48 Switzerland
4.02 Active labour market policies (1–7) 3.8 46.2 42 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 54.2 59 Switzerland
4.04 Percentage of ﬁrms of fering formal training 32.0 42.7 28 Ecuador
4.05 Digital skills among active population (1–7) 4.1 52.4 57 Finland
- 36.3 81 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 15.5 15.5 81 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 0.9 1.7 77 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 29.2 24.3 80 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 74.0 74.0 80 Multiple (13)
5.05 Rural population with electricity access (%) 54.1 54.1 79 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.9 48.0 63 Singapore
- 56.7 67 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 2.2 91.2 8 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.6 77.6 33 Thailand
6.02 Unemployment among labor force with advanced education (%) 7.1 71.4 60 Czech Republic
6.04 Unemployment in rural areas (%) 3.5 86.2 23 Peru
6.05 Ratio of female to male labour force participation rate 29.6 12.0 81 Lao PDR
6.06 Workers in vulnerable employment (%) 58.9 1.9 76 Saudi Arabia
- 26.0 72 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 37.5 0.0 56 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 15.5 6.1 76 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 12.7 6.8 74 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 52.6 78.9 16 Multiple (4)
7.05 Adjusted labour income share (%) 42.2 38.2 65 Switzerland
- 49.8 65 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 66.0 66.0 56 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.1 52.0 67 Singapore
8.03 Pay and productivity (1–7) 4.1 51.6 48 Switzerland
8.04 Employees working more than 48 hours per week (%) 35.2 29.6 71 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 24.0 77 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 0.2 0.7 81 Multiple (9)
9.04 Social safety net protection, 1-7 3.8 47.3 52 Norway
- 33.5 82 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 33.0 33.0 70 Denmark
10.02 Government and public services efﬁciency (score) -0.6 38.8 78 Singapore
10.03 Inclusiveness of institutions (score) -0.8 46.2 74 Portugal
10.04 Political stability and protection from violence (score) -2.3 16.2 81 New Zealand

148Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

63rd
67th
64th
61st
63rd
60th
35th
75th
66th
52nd
49th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5161
4945 456474
2550
4557
Panama 63rd /82
Index Component Value Score      Rank/ 82 Best Performer
- 60.8 67 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 81.8 18.2 79 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 12.3 75.3 50 Ghana
1.03 Health Access and Quality Index (0–100 best) 68.3 68.3 56 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 81.4 35 Singapore
- 48.6 64 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 62.2 62.2 51 Malta
2.02 Quality of vocational training (1–7) 3.7 45.6 65 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 16.4 45.4 45 Japan
2.04 Out-of-school children (%) 7.1 29.0 61 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 60.5 56 GermanyPanama 63rd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %4.2
61.8
15,679.00.08
49.9
5.7

149Panama 63rd /82
Index Component Value Score       Rank/ 82 Best Performer
- 44.8 61 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 64.1 8.4 61 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 15.4 65.4 41 Australia
3.03 Pupils per teacher in primary education 22.0 60.1 61 Multiple (3)
3.04 Pupils per teacher in secondary education 12.1 76.3 29 Armenia
3.05 Harmonized learning outcomes (score) 392.0 48.0 67 Singapore
3.06 Social diversity in schools (score) 61.0 26.6 58 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material71.3 28.7 57 Multiple (2)
- 44.8 63 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.8 46.1 62 Switzerland
4.02 Active labour market policies (1–7) 2.9 31.8 61 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.6 59.2 43 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 3.5 42.0 76 Finland
- 64.3 60 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 57.9 57.9 64 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 10.8 21.7 60 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 70.3 58.6 58 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.0 95.0 58 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.2 52.8 52 Singapore
- 74.0 35 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.7 85.3 18 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.5 78.0 31 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.2 87.2 22 Czech Republic
6.04 Unemployment in rural areas (%) 2.5 90.0 13 Peru
6.05 Ratio of female to male labour force participation rate 65.3 56.7 65 Lao PDR
6.06 Workers in vulnerable employment (%) 31.9 46.8 56 Saudi Arabia
- 24.9 75 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 11.6 66.9 13 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 22.8 14.2 71 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 18.2 20.6 69 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 28.9 11.3 64 Multiple (4)
7.05 Adjusted labour income share (%) 30.3 11.8 80 Switzerland
- 49.7 66 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 71.0 71.0 48 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.3 55.4 57 Singapore
8.03 Pay and productivity (1–7) 3.3 37.6 79 Switzerland
8.04 Employees working more than 48 hours per week (%) 8.2 83.6 33 Bulgaria
8.05 Collective bargaining coverage ratio (%) 1 1.0 68 France
- 45.3 52 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 9.8 39.2 56 Multiple (9)
9.04 Social safety net protection, 1-7 4.1 51.5 44 Norway
- 56.7 49 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 37.0 37.0 58 Denmark
10.02 Government and public services efﬁciency (score) 0.0 51.9 57 Singapore
10.03 Inclusiveness of institutions (score) 0.0 65.7 50 Portugal
10.04 Political stability and protection from violence (score) 0.3 72.2 39 New Zealand

150Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

69th
63rd
74th
69th
77th
67th
41st
60th
78th
70th
55th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4763
3339 395971
3841
3253
Paraguay 69th /82
Index Component Value Score      Rank/ 82 Best Performer
- 63.2 63 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 70.5 29.5 74 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.1 99.8 4 Ghana
1.03 Health Access and Quality Index (0–100 best) 56.7 56.7 69 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 66.7 63 Singapore
- 33.5 74 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 39.4 39.4 60 Malta
2.02 Quality of vocational training (1–7) 3.1 35.6 81 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 18.1 39.8 52 Japan
2.04 Out-of-school children (%) 10.8 0.0 66 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.5 52.5 66 GermanyParaguay 69th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %7.1
29.6
5,898.80.07
48.8
4.3