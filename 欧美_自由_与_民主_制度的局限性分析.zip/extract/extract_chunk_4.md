91Georgia 53rd /82
Index Component Value Score       Rank/ 82 Best Performer
- 80.1 15 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 13.5 80.7 37 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 9.0 100.0 1 Multiple (3)
3.04 Pupils per teacher in secondary education 6.9 93.6 3 Armenia
3.05 Harmonized learning outcomes (score) n/a n/a n/a Singapore
3.06 Social diversity in schools (score) 80.7 74.0 13 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material47.8 52.2 35 Multiple (2)
- 37.4 81 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.5 41.1 79 Switzerland
4.02 Active labour market policies (1–7) 2.9 30.9 64 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.4 56.5 48 Switzerland
4.04 Percentage of ﬁrms of fering formal training 10.5 14.0 47 Ecuador
4.05 Digital skills among active population (1–7) 3.7 44.3 72 Finland
- 65.9 57 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 64.0 64.0 60 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 21.0 42.0 42 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 45.3 37.7 73 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 15 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.1 51.8 55 Singapore
- 50.4 71 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 10.9 56.3 57 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 13.5 46.0 72 Thailand
6.02 Unemployment among labor force with advanced education (%) 15.4 38.2 76 Czech Republic
6.04 Unemployment in rural areas (%) 5.8 76.7 43 Peru
6.05 Ratio of female to male labour force participation rate 73.5 66.9 49 Lao PDR
6.06 Workers in vulnerable employment (%) 48.9 18.6 71 Saudi Arabia
- 46.5 48 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 41.7 35.3 51 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 27.7 44.2 41 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 43.3 52.2 46 Multiple (4)
7.05 Adjusted labour income share (%) 49.5 54.4 47 Switzerland
- 56.9 49 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 82.0 82.0 28 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.2 53.4 64 Singapore
8.03 Pay and productivity (1–7) 3.7 44.6 62 Switzerland
8.04 Employees working more than 48 hours per week (%) 26.2 47.5 57 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 33.4 67 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 28.6 28.6 51 Multiple (6)
9.03 Social protection spending (% of GDP) 10.6 42.6 52 Multiple (9)
9.04 Social safety net protection, 1-7 2.7 29.1 81 Norway
- 60.1 44 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 58.0 58.0 31 Denmark
10.02 Government and public services efﬁciency (score) 0.6 65.5 36 Singapore
10.03 Inclusiveness of institutions (score) -0.2 60.4 60 Portugal
10.04 Political stability and protection from violence (score) -0.4 56.7 62 New Zealand

92Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

11th
21st
3rd
30th
12th
20th
3rd
30th
11th
4th
17th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions798885
76
7085 84
607585
80
Germany 11th/82
Index Component Value Score      Rank/ 82 Best Performer
- 88.3 21 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 8.1 91.9 25 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.2 79.7 36 Ghana
1.03 Health Access and Quality Index (0–100 best) 92.0 92.0 17 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 89.6 22 Singapore
- 85.4 3 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 5.3 71.7 7 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 5.9 80.3 8 Japan
2.04 Out-of-school children (%) 0.2 98.0 7 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 91.5 1 GermanyGermany 11th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %82.9
3,684.8
48,264.03.22
31.7
1.8

93Germany 11th/82
Index Component Value Score       Rank/ 82 Best Performer
- 75.8 30 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 5.5 92.1 28 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 9.5 85.0 10 Australia
3.03 Pupils per teacher in primary education 15.4 82.0 34 Multiple (3)
3.04 Pupils per teacher in secondary education 12.7 74.3 32 Armenia
3.05 Harmonized learning outcomes (score) 528.6 82.1 16 Singapore
3.06 Social diversity in schools (score) 74.0 57.8 37 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material42.9 57.1 34 Multiple (2)
- 69.6 12 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.9 65.3 17 Switzerland
4.02 Active labour market policies (1–7) 4.9 65.6 13 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.8 79.9 18 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.1 67.8 16 Finland
- 84.6 20 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 89.7 89.7 12 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 41.1 82.2 8 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 81.6 68.0 43 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 97.5 97.5 52 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.2 70.5 24 Singapore
- 84.0 3 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.4 62.2 45 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 2.9 88.5 4 Thailand
6.02 Unemployment among labor force with advanced education (%) 1.9 92.5 5 Czech Republic
6.04 Unemployment in rural areas (%) 2.3 90.7 10 Peru
6.05 Ratio of female to male labour force participation rate 83.6 79.6 25 Lao PDR
6.06 Workers in vulnerable employment (%) 5.8 90.3 8 Saudi Arabia
- 59.7 30 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 19.3 44.9 33 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 54.6 49.5 35 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 29.6 49.0 35 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 51.8 76.5 22 Multiple (4)
7.05 Adjusted labour income share (%) 60.3 78.4 12 Switzerland
- 75.4 11 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 95.0 95.0 8 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.0 66.8 22 Singapore
8.03 Pay and productivity (1–7) 5.2 69.8 5 Switzerland
8.04 Employees working more than 48 hours per week (%) 5.3 89.4 18 Bulgaria
8.05 Collective bargaining coverage ratio (%) 56 56.0 23 France
- 85.4 4 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 54.0 72.0 6 Multiple (2)
9.02 Social protection coverage (% of population) 99.5 99.5 8 Multiple (6)
9.03 Social protection spending (% of GDP) 25.0 99.9 10 Multiple (9)
9.04 Social safety net protection, 1-7 5.2 70.4 19 Norway
- 79.5 17 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 80.0 80.0 11 Denmark
10.02 Government and public services efﬁciency (score) 1.6 86.9 12 Singapore
10.03 Inclusiveness of institutions (score) 0.2 71.8 36 Portugal
10.04 Political stability and protection from violence (score) 0.6 79.4 25 New Zealand

94Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
70th 76th 68th 75th 45th 74th 48th 77th 64th 71st 48th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4553
40
3251 5269
2050
2958
Ghana 70th /82
Index Component Value Score      Rank/ 82 Best Performer
- 53.0 76 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 66.6 33.4 70 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.1 99.8 1 Ghana
1.03 Health Access and Quality Index (0–100 best) 39.3 39.3 77 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 39.3 79 Singapore
- 40.0 68 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 73.5 73.5 41 Malta
2.02 Quality of vocational training (1–7) 4.0 50.1 55 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 30.5 0.0 71 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.4 36.3 74 GermanyGhana 70th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %29.6
47.0
2,205.80.14
43.5
6.2

95Ghana 70th /82
Index Component Value Score       Rank/ 82 Best Performer
- 32.1 75 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 28.8 20.7 68 Australia
3.03 Pupils per teacher in primary education 27.2 42.5 72 Multiple (3)
3.04 Pupils per teacher in secondary education 23.4 38.8 64 Armenia
3.05 Harmonized learning outcomes (score) 306.1 26.5 80 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 51.2 45 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.3 54.9 39 Switzerland
4.02 Active labour market policies (1–7) 3.7 44.2 45 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.0 50.2 66 Switzerland
4.04 Percentage of ﬁrms of fering formal training 40.1 53.5 20 Ecuador
4.05 Digital skills among active population (1–7) 4.2 53.5 54 Finland
- 51.6 74 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 39.0 39.0 74 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 0.2 0.4 81 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 91.8 76.5 31 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 80.0 80.0 75 Multiple (13)
5.05 Rural population with electricity access (%) 65.3 65.3 78 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.9 48.6 61 Singapore
- 69.1 48 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.5 86.2 16 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 7.6 69.6 50 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.6 81.8 44 Czech Republic
6.04 Unemployment in rural areas (%) 2.2 91.2 9 Peru
6.05 Ratio of female to male labour force participation rate 88.9 86.1 5 Lao PDR
6.06 Workers in vulnerable employment (%) 68.5 0.0 78 Saudi Arabia
- 20.3 77 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 7.7 0.0 79 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 7.5 0.0 79 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 35.7 30.7 58 Multiple (4)
7.05 Adjusted labour income share (%) 47.8 50.7 54 Switzerland
- 50.0 64 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 79.0 79.0 34 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 58.4 45 Singapore
8.03 Pay and productivity (1–7) 4.0 50.7 50 Switzerland
8.04 Employees working more than 48 hours per week (%) 26.4 47.2 58 Bulgaria
8.05 Collective bargaining coverage ratio (%) 15 14.7 52 France
- 29.4 71 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 18.3 18.3 54 Multiple (6)
9.03 Social protection spending (% of GDP) 5.4 21.6 65 Multiple (9)
9.04 Social safety net protection, 1-7 3.9 48.3 50 Norway
- 58.0 48 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 41.0 41.0 50 Denmark
10.02 Government and public services efﬁciency (score) -0.2 47.8 64 Singapore
10.03 Inclusiveness of institutions (score) 0.4 76.5 21 Portugal
10.04 Political stability and protection from violence (score) 0.0 66.8 47 New Zealand

96Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

48th
25th
50th
34th
69th
38th
79th
27th
77th
41st
42nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6086
6075
4277
3761
435861
Greece 48th /82
Index Component Value Score      Rank/ 82 Best Performer
- 86.2 25 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.2 92.8 17 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 14.4 71.2 62 Ghana
1.03 Health Access and Quality Index (0–100 best) 90.4 90.4 23 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 90.3 20 Singapore
- 60.2 50 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 72.7 72.7 42 Malta
2.02 Quality of vocational training (1–7) 3.5 42.4 71 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 14.1 53.0 38 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 72.8 38 GermanyGreece 48th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %10.7
200.7
20,407.90.23
36.0
-2.2

97Greece 48th /82
Index Component Value Score       Rank/ 82 Best Performer
- 74.6 34 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 10.4 81.9 15 Australia
3.03 Pupils per teacher in primary education 9.4 100.0 3 Multiple (3)
3.04 Pupils per teacher in secondary education 8.1 89.8 6 Armenia
3.05 Harmonized learning outcomes (score) 481.8 70.5 43 Singapore
3.06 Social diversity in schools (score) 78.2 68.0 19 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material62.6 37.4 48 Multiple (2)
- 42.4 69 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.3 73 Switzerland
4.02 Active labour market policies (1–7) 2.9 32.4 59 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 55.7 52 Switzerland
4.04 Percentage of ﬁrms of fering formal training 21.6 28.8 38 Ecuador
4.05 Digital skills among active population (1–7) 4.1 51.8 59 Finland
- 76.5 38 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 73.0 73.0 45 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 37.7 75.3 14 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 82.0 68.3 42 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.7 99.7 24 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.6 43.0 70 Singapore
- 36.6 79 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 23.9 4.6 78 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 21.8 12.8 81 Thailand
6.02 Unemployment among labor force with advanced education (%) 14.2 43.1 74 Czech Republic
6.04 Unemployment in rural areas (%) 16.3 34.9 65 Peru
6.05 Ratio of female to male labour force participation rate 74.8 68.5 45 Lao PDR
6.06 Workers in vulnerable employment (%) 26.5 55.8 51 Saudi Arabia
- 60.6 27 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 15.9 54.6 25 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 74.1 71.2 14 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 37.2 68.0 16 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 43.5 52.8 45 Multiple (4)
7.05 Adjusted labour income share (%) 50.3 56.2 45 Switzerland
- 43.0 77 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 10.0 10.0 74 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.0 50.3 71 Singapore
8.03 Pay and productivity (1–7) 3.5 41.4 70 Switzerland
8.04 Employees working more than 48 hours per week (%) 6.0 87.9 23 Bulgaria
8.05 Collective bargaining coverage ratio (%) 26 25.5 40 France
- 57.5 41 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 28.0 37.3 31 Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 26.4 100.0 8 Multiple (9)
9.04 Social safety net protection, 1-7 3.1 35.2 74 Norway
- 60.7 42 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 45.0 45.0 44 Denmark
10.02 Government and public services efﬁciency (score) 0.3 59.6 45 Singapore
10.03 Inclusiveness of institutions (score) 0.1 69.9 40 Portugal
10.04 Political stability and protection from violence (score) 0.1 68.1 44 New Zealand

98Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

75th
72nd
77th
57th
56th
75th
42nd
74th
82nd
80th
78th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4455
3054
475171
2538
2341
Guatemala 75th /82
Index Component Value Score      Rank/ 82 Best Performer
- 55.2 72 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 70.9 29.1 75 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 11.0 78.1 43 Ghana
1.03 Health Access and Quality Index (0–100 best) 51.5 51.5 70 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 62.1 69 Singapore
- 29.9 77 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 49.0 49.0 56 Malta
2.02 Quality of vocational training (1–7) 4.5 57.7 39 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 27.3 9.1 67 Japan
2.04 Out-of-school children (%) 10.1 0.0 65 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.3 33.5 76 GermanyGuatemala 75th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %17.3
75.7
4,575.10.11
48.3
3.0

99Guatemala 75th /82
Index Component Value Score       Rank/ 82 Best Performer
- 53.8 57 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 63.6 9.1 59 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 19.2 52.6 52 Australia
3.03 Pupils per teacher in primary education 20.3 65.8 58 Multiple (3)
3.04 Pupils per teacher in secondary education 8.2 89.5 8 Armenia
3.05 Harmonized learning outcomes (score) 408.1 52.0 63 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 47.1 56 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.3 55.3 35 Switzerland
4.02 Active labour market policies (1–7) 1.9 15.7 81 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.1 51.3 64 Switzerland
4.04 Percentage of ﬁrms of fering formal training 55.7 74.3 6 Ecuador
4.05 Digital skills among active population (1–7) 3.3 39.1 78 Finland
- 51.0 75 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 65.0 65.0 54 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 3.1 6.3 74 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 16.5 13.7 82 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.0 95.0 58 Multiple (13)
5.05 Rural population with electricity access (%) 89.3 89.3 72 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.2 36.8 77 Singapore
- 71.0 42 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.1 87.8 12 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.5 78.1 29 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.9 88.4 17 Czech Republic
6.04 Unemployment in rural areas (%) 1.6 93.7 6 Peru
6.05 Ratio of female to male labour force participation rate 48.3 35.3 74 Lao PDR
6.06 Workers in vulnerable employment (%) 34.4 42.7 59 Saudi Arabia
- 25.4 74 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 30.5 22.8 62 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 19.1 22.8 67 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 38.8 30.7 70 Switzerland
- 37.7 82 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 3.0 3.0 76 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.0 66.2 24 Singapore
8.03 Pay and productivity (1–7) 3.8 47.1 56 Switzerland
8.04 Employees working more than 48 hours per week (%) 32.7 34.5 69 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 22.6 80 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 10.3 10.3 55 Multiple (6)
9.03 Social protection spending (% of GDP) 4.4 17.6 68 Multiple (9)
9.04 Social safety net protection, 1-7 3.4 40.0 64 Norway
- 41.4 78 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 27.0 27.0 80 Denmark
10.02 Government and public services efﬁciency (score) -0.7 37.8 80 Singapore
10.03 Inclusiveness of institutions (score) -0.7 46.8 71 Portugal
10.04 Political stability and protection from violence (score) -0.5 54.2 66 New Zealand

100Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

74th
75th
79th
63rd
60th
79th
61st
69th
63rd
75th
65th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4454
2744464362
3052
2849
Honduras 74th /82
Index Component Value Score      Rank/ 82 Best Performer
- 53.5 75 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 72.9 27.1 77 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 11.7 76.7 48 Ghana
1.03 Health Access and Quality Index (0–100 best) 46.5 46.5 74 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 63.7 66 Singapore
- 27.1 79 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 36.8 36.8 61 Malta
2.02 Quality of vocational training (1–7) 3.9 48.9 56 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 26.7 11.1 63 Japan
2.04 Out-of-school children (%) 17.1 0.0 67 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.4 38.8 71 GermanyHonduras 74th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %9.4
23.0
2,521.20.04
50.5
3.3

101Honduras 74th /82
Index Component Value Score       Rank/ 82 Best Performer
- 44.0 63 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 69.4 0.9 66 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 19.3 52.2 53 Australia
3.03 Pupils per teacher in primary education 25.6 48.0 69 Multiple (3)
3.04 Pupils per teacher in secondary education 14.2 69.2 47 Armenia
3.05 Harmonized learning outcomes (score) 398.8 49.7 66 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 46.2 60 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.1 52.1 41 Switzerland
4.02 Active labour market policies (1–7) 2.4 24.0 75 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.9 47.7 74 Switzerland
4.04 Percentage of ﬁrms of fering formal training 47.7 63.6 11 Ecuador
4.05 Digital skills among active population (1–7) 3.6 43.9 73 Finland
- 43.3 79 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 31.7 31.7 78 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 3.7 7.4 71 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 32.1 26.8 79 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 78.4 78.4 76 Multiple (13)
5.05 Rural population with electricity access (%) 71.8 71.8 76 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.6 43.5 69 Singapore
- 62.5 61 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 5.3 78.9 26 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 10.3 58.6 65 Thailand
6.02 Unemployment among labor force with advanced education (%) 7.6 69.4 63 Czech Republic
6.04 Unemployment in rural areas (%) 2.7 89.2 15 Peru
6.05 Ratio of female to male labour force participation rate 56.6 45.8 71 Lao PDR
6.06 Workers in vulnerable employment (%) 40.2 32.9 64 Saudi Arabia
- 30.2 69 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 33.4 4.6 55 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 31.5 23.9 61 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 19.9 24.9 64 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 27.5 7.3 66 Multiple (4)
7.05 Adjusted labour income share (%) 65.7 90.4 2 Switzerland
- 51.5 63 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 63.0 63.0 64 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.7 62.0 34 Singapore
8.03 Pay and productivity (1–7) 3.8 47.3 55 Switzerland
8.04 Employees working more than 48 hours per week (%) 33.1 33.7 70 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 27.7 75 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 4.4 17.6 68 Multiple (9)
9.04 Social safety net protection, 1-7 3.3 37.9 70 Norway
- 49.3 65 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 29.0 29.0 75 Denmark
10.02 Government and public services efﬁciency (score) -0.6 39.1 77 Singapore
10.03 Inclusiveness of institutions (score) 0.3 75.1 29 Portugal
10.04 Political stability and protection from violence (score) -0.6 54.0 67 New Zealand

102Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

37th
39th
38th
40th
68th
43rd
15th
17th
45th
44th
37th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6677
6773
437480
66
585665
Hungary 37th /82
Index Component Value Score      Rank/ 82 Best Performer
- 77.4 39 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 24.0 76.0 48 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 12.7 74.5 53 Ghana
1.03 Health Access and Quality Index (0–100 best) 82.1 82.1 35 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 76.8 46 Singapore
- 67.2 38 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 81.3 81.3 30 Malta
2.02 Quality of vocational training (1–7) 3.6 42.6 70 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 10.7 64.2 28 Japan
2.04 Out-of-school children (%) 3.1 69.0 47 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 78.9 28 GermanyHungary 37th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %9.8
152.3
15,923.80.23
30.4
2.1

103Hungary 37th /82
Index Component Value Score       Rank/ 82 Best Performer
- 72.6 40 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.9 95.9 18 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 11.8 77.3 19 Australia
3.03 Pupils per teacher in primary education 10.8 97.3 7 Multiple (3)
3.04 Pupils per teacher in secondary education 11.5 78.5 25 Armenia
3.05 Harmonized learning outcomes (score) 517.3 79.3 30 Singapore
3.06 Social diversity in schools (score) 63.6 32.8 50 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material52.6 47.4 39 Multiple (2)
- 42.6 68 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.7 44.6 66 Switzerland
4.02 Active labour market policies (1–7) 3.4 39.8 52 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.5 57.8 45 Switzerland
4.04 Percentage of ﬁrms of fering formal training 15.8 21.1 44 Ecuador
4.05 Digital skills among active population (1–7) 4.0 49.5 63 Finland
- 73.8 43 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 76.1 76.1 39 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 31.7 63.4 23 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 67.8 56.5 61 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.2 99.2 34 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.9 47.6 64 Singapore
- 79.6 15 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 11.1 55.7 59 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.3 86.6 9 Thailand
6.02 Unemployment among labor force with advanced education (%) 1.5 94.2 2 Czech Republic
6.04 Unemployment in rural areas (%) 4.4 82.5 33 Peru
6.05 Ratio of female to male labour force participation rate 74.5 68.2 47 Lao PDR
6.06 Workers in vulnerable employment (%) 5.7 90.5 7 Saudi Arabia
- 66.3 17 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 19.6 44.1 34 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 85.4 83.8 7 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 40.1 75.1 9 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 52.5 78.5 19 Multiple (4)
7.05 Adjusted labour income share (%) 47.6 50.2 55 Switzerland
- 58.4 45 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 82.0 82.0 28 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.2 53.8 63 Singapore
8.03 Pay and productivity (1–7) 3.5 41.0 71 Switzerland
8.04 Employees working more than 48 hours per week (%) 3.7 92.6 7 Bulgaria
8.05 Collective bargaining coverage ratio (%) 23 22.8 43 France
- 55.5 44 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 17.0 22.7 36 Multiple (2)
9.02 Social protection coverage (% of population) 86.2 86.2 26 Multiple (6)
9.03 Social protection spending (% of GDP) 20.7 82.7 22 Multiple (9)
9.04 Social safety net protection, 1-7 2.8 30.5 80 Norway
- 64.7 37 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 46.0 46.0 43 Denmark
10.02 Government and public services efﬁciency (score) 0.5 62.7 38 Singapore
10.03 Inclusiveness of institutions (score) 0.0 67.2 47 Portugal
10.04 Political stability and protection from violence (score) 0.8 82.7 22 New Zealand

104Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
5th 10th 7th 3rd 7th 2nd 1st 12th 7th 22nd 9th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions8391
8486
7694
88
7379
7186
Iceland 5th/82
Index Component Value Score      Rank/ 82 Best Performer
- 91.1 10 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 6.3 93.7 16 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.8 78.4 40 Ghana
1.03 Health Access and Quality Index (0–100 best) 97.1 97.1 1 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 95.3 8 Singapore
- 84.0 7 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 94.0 94.0 10 Malta
2.02 Quality of vocational training (1–7) 5.2 69.3 11 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 4.9 83.8 5 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 88.9 5 GermanyIceland 5th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %0.3
23.9
74,278.20.01
27.8
2.6

105Iceland 5th/82
Index Component Value Score       Rank/ 82 Best Performer
- 85.9 3 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 5.2 99.3 2 Australia
3.03 Pupils per teacher in primary education 11.1 96.4 9 Multiple (3)
3.04 Pupils per teacher in secondary education 12.5 75.2 31 Armenia
3.05 Harmonized learning outcomes (score) 504.5 76.1 36 Singapore
3.06 Social diversity in schools (score) 87.3 90.1 3 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material21.6 78.4 13 Multiple (2)
- 75.7 7 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.9 65.3 16 Switzerland
4.02 Active labour market policies (1–7) 5.4 73.2 5 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.2 86.5 7 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.7 77.9 2 Finland
- 93.6 2 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 99.0 99.0 1 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 40.6 81.1 9 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 125.5 100.0 10 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.0 99.0 37 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.9 82.4 6 Singapore
- 88.1 1 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 4.7 81.0 24 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 2.3 90.9 3 Thailand
6.02 Unemployment among labor force with advanced education (%) 1.9 92.6 4 Czech Republic
6.04 Unemployment in rural areas (%) 2.4 90.4 11 Peru
6.05 Ratio of female to male labour force participation rate 89.5 86.9 4 Lao PDR
6.06 Workers in vulnerable employment (%) 7.9 86.8 15 Saudi Arabia
- 72.6 12 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 14.9 57.4 22 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 69.5 66.1 20 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 35.8 64.6 21 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 57.9 94.0 7 Multiple (4)
7.05 Adjusted labour income share (%) 61.3 80.7 6 Switzerland
- 79.4 7 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 99.0 99.0 3 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.4 74.1 10 Singapore
8.03 Pay and productivity (1–7) 4.6 60.8 18 Switzerland
8.04 Employees working more than 48 hours per week (%) 14.4 71.2 46 Bulgaria
8.05 Collective bargaining coverage ratio (%) 92 92.0 5 France
- 70.9 22 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 53.0 70.7 7 Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 15.7 62.7 39 Multiple (9)
9.04 Social safety net protection, 1-7 5.8 79.4 9 Norway
- 85.6 9 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 76.0 76.0 14 Denmark
10.02 Government and public services efﬁciency (score) 1.5 83.6 16 Singapore
10.03 Inclusiveness of institutions (score) n/a n/a n/a Portugal
10.04 Political stability and protection from violence (score) 1.4 97.2 3 New Zealand

106Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

76th
73rd
66th
77th
41st
73rd
75th
79th
53rd
76th
67th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4355
41
3153 52
47
1856
2649
India 76th /82
Index Component Value Score      Rank/ 82 Best Performer
- 54.6 73 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 13.2 86.8 35 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 28.7 42.6 82 Ghana
1.03 Health Access and Quality Index (0–100 best) 41.2 41.2 76 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 47.6 75 Singapore
- 41.1 66 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 4.2 53.3 51 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 30.4 0.0 70 Japan
2.04 Out-of-school children (%) 2.3 77.0 38 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.3 34.1 75 GermanyIndia 76th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %1,334.2
2,611.0
2,036.27.77
35.7
6.4

107India 76th /82
Index Component Value Score       Rank/ 82 Best Performer
- 31.3 77 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 53.7 23.3 55 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 20.1 49.7 55 Australia
3.03 Pupils per teacher in primary education 32.7 24.2 77 Multiple (3)
3.04 Pupils per teacher in secondary education 29.3 19.0 71 Armenia
3.05 Harmonized learning outcomes (score) 361.8 40.4 76 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 52.6 41 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.3 55.1 38 Switzerland
4.02 Active labour market policies (1–7) 3.5 41.8 50 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.7 61.2 40 Switzerland
4.04 Percentage of ﬁrms of fering formal training 35.9 47.9 23 Ecuador
4.05 Digital skills among active population (1–7) 4.4 57.2 46 Finland
- 52.0 73 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 34.5 34.5 75 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 1.3 2.7 76 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 37.5 31.3 78 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 94.0 94.0 64 Multiple (13)
5.05 Rural population with electricity access (%) 89.3 89.3 73 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.6 60.2 40 Singapore
- 46.9 75 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 2.1 91.7 6 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 10.8 56.9 68 Thailand
6.02 Unemployment among labor force with advanced education (%) 15.3 39.0 75 Czech Republic
6.04 Unemployment in rural areas (%) 4.7 81.4 36 Peru
6.05 Ratio of female to male labour force participation rate 29.8 12.2 80 Lao PDR
6.06 Workers in vulnerable employment (%) 76.2 0.0 81 Saudi Arabia
- 17.8 79 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 4.6 0.0 81 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 5.4 0.0 81 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 49.0 53.3 49 Switzerland
- 55.9 53 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 58.0 58.0 72 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 58.4 46 Singapore
8.03 Pay and productivity (1–7) 4.1 51.3 49 Switzerland
8.04 Employees working more than 48 hours per week (%) n/a n/a n/a Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 26.0 76 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 22.0 22.0 53 Multiple (6)
9.03 Social protection spending (% of GDP) 2.7 10.7 74 Multiple (9)
9.04 Social safety net protection, 1-7 3.7 45.3 56 Norway
- 49.1 67 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 41.0 41.0 50 Denmark
10.02 Government and public services efﬁciency (score) 0.3 58.4 47 Singapore
10.03 Inclusiveness of institutions (score) -0.5 51.9 67 Portugal
10.04 Political stability and protection from violence (score) -1.0 45.0 74 New Zealand

108Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

67th
70th
61st
56th
53rd
63rd
54th
71st
67th
73rd
62nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4956
5155
486267
2649
2850
Indonesia 67th /82
Index Component Value Score      Rank/ 82 Best Performer
- 56.2 70 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 47.4 52.6 60 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 16.3 67.5 68 Ghana
1.03 Health Access and Quality Index (0–100 best) 44.5 44.5 75 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 60.3 71 Singapore
- 51.3 61 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 40.5 40.5 59 Malta
2.02 Quality of vocational training (1–7) 4.6 60.1 30 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 21.7 27.6 58 Japan
2.04 Out-of-school children (%) 2.4 76.0 39 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.5 52.0 67 GermanyIndonesia 67th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %264.2
1,015.4
3,870.62.59
38.1
4.8

109Indonesia 67th /82
Index Component Value Score       Rank/ 82 Best Performer
- 54.5 56 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 33.8 51.7 48 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.7 74.4 27 Australia
3.03 Pupils per teacher in primary education 17.0 76.6 47 Multiple (3)
3.04 Pupils per teacher in secondary education 15.0 66.8 49 Armenia
3.05 Harmonized learning outcomes (score) 407.8 51.9 64 Singapore
3.06 Social diversity in schools (score) 62.3 29.6 55 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material69.4 30.6 54 Multiple (2)
- 48.1 53 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.6 60.3 27 Switzerland
4.02 Active labour market policies (1–7) 4.0 49.6 35 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.7 61.7 38 Switzerland
4.04 Percentage of ﬁrms of fering formal training 7.7 10.3 48 Ecuador
4.05 Digital skills among active population (1–7) 4.5 58.5 40 Finland
- 62.5 63 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 39.8 39.8 73 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 3.3 6.6 72 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 87.2 72.7 40 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 93.4 93.4 65 Multiple (13)
5.05 Rural population with electricity access (%) 95.7 95.7 69 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.0 66.9 28 Singapore
- 66.5 54 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 2.9 88.4 11 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 7.9 68.6 52 Thailand
6.02 Unemployment among labor force with advanced education (%) 5.5 78.0 53 Czech Republic
6.04 Unemployment in rural areas (%) 3.2 87.1 19 Peru
6.05 Ratio of female to male labour force participation rate 63.9 54.9 66 Lao PDR
6.06 Workers in vulnerable employment (%) 46.7 22.2 68 Saudi Arabia
- 26.3 71 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 22.2 36.6 42 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 15.5 6.1 75 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 12.1 5.4 77 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 44.1 54.5 41 Multiple (4)
7.05 Adjusted labour income share (%) 38.1 29.1 71 Switzerland
- 49.3 67 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 64.0 64.0 57 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 58.0 48 Singapore
8.03 Pay and productivity (1–7) 4.6 60.4 21 Switzerland
8.04 Employees working more than 48 hours per week (%) 23.0 54.0 55 Bulgaria
8.05 Collective bargaining coverage ratio (%) 10 10.0 58 France
- 28.4 73 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 1.1 4.5 80 Multiple (9)
9.04 Social safety net protection, 1-7 4.1 52.3 43 Norway
- 50.2 62 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 38.0 38.0 56 Denmark
10.02 Government and public services efﬁciency (score) 0.2 56.2 49 Singapore
10.03 Inclusiveness of institutions (score) -0.5 52.1 66 Portugal
10.04 Political stability and protection from violence (score) -0.5 54.4 65 New Zealand

110Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

18th
17th
17th
19th
23rd
26th
29th
35th
17th
16th
12th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7590
78 79
6582
75
54697682
Ireland 18th /82
Index Component Value Score      Rank/ 82 Best Performer
- 89.9 17 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.5 92.5 20 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.8 80.3 33 Ghana
1.03 Health Access and Quality Index (0–100 best) 94.6 94.6 10 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 92.2 13 Singapore
- 78.4 17 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 72.3 72.3 43 Malta
2.02 Quality of vocational training (1–7) 4.8 64.1 20 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 10.1 66.4 25 Japan
2.04 Out-of-school children (%) 0.0 100.0 1 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 89.1 4 GermanyIreland 18th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %4.9
334.0
76,098.60.29
31.8
5.6

111Ireland 18th /82
Index Component Value Score       Rank/ 82 Best Performer
- 78.8 19 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.3 96.7 13 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 15.7 81.2 36 Multiple (3)
3.04 Pupils per teacher in secondary education 13.4 72.0 40 Armenia
3.05 Harmonized learning outcomes (score) 537.4 84.4 12 Singapore
3.06 Social diversity in schools (score) 83.0 79.6 8 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material40.9 59.1 32 Multiple (2)
- 64.9 23 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.0 66.3 14 Switzerland
4.02 Active labour market policies (1–7) 4.7 61.4 22 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.9 65.4 34 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.0 66.5 20 Finland
- 82.3 26 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 84.5 84.5 23 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 29.7 59.4 26 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 103.8 86.5 20 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.0 95.0 58 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.1 68.7 27 Singapore
- 74.9 29 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 11.3 54.8 60 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 6.9 72.3 45 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.8 84.8 34 Czech Republic
6.04 Unemployment in rural areas (%) 5.2 79.0 39 Peru
6.05 Ratio of female to male labour force participation rate 81.2 76.4 32 Lao PDR
6.06 Workers in vulnerable employment (%) 10.8 82.0 29 Saudi Arabia
- 53.8 35 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 24.0 31.4 46 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 70.6 67.3 18 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 36.8 67.1 17 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 52.1 77.5 20 Multiple (4)
7.05 Adjusted labour income share (%) 36.6 25.8 73 Switzerland
- 68.6 17 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 92.0 92.0 11 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.2 69.6 16 Singapore
8.03 Pay and productivity (1–7) 4.7 62.4 14 Switzerland
8.04 Employees working more than 48 hours per week (%) 6.7 86.7 27 Bulgaria
8.05 Collective bargaining coverage ratio (%) 33 32.5 33 France
- 76.4 16 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 60.0 80.0 4 Multiple (2)
9.02 Social protection coverage (% of population) 90.1 90.1 21 Multiple (6)
9.03 Social protection spending (% of GDP) 17.0 67.9 37 Multiple (9)
9.04 Social safety net protection, 1-7 5.0 67.5 22 Norway
- 82.2 12 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 73.0 73.0 17 Denmark
10.02 Government and public services efﬁciency (score) 1.4 82.7 18 Singapore
10.03 Inclusiveness of institutions (score) 0.7 84.3 3 Portugal
10.04 Political stability and protection from violence (score) 1.0 88.8 12 New Zealand

112Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

33rd
26th
43rd
36th
30th
23rd
13th
31st
28th
46th
50th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6886
6674
618380
5663
55 56
Israel 33rd /82
Index Component Value Score      Rank/ 82 Best Performer
- 86.1 26 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 9.6 90.4 29 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 12.8 74.4 54 Ghana
1.03 Health Access and Quality Index (0–100 best) 84.8 84.8 32 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 94.8 9 Singapore
- 65.7 43 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 4.6 59.6 32 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 14.7 51.1 40 Japan
2.04 Out-of-school children (%) 2.9 71.0 45 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 81.3 27 GermanyIsrael 33rd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %8.9
350.6
41,644.10.25
38.9
3.4

113Israel 33rd /82
Index Component Value Score       Rank/ 82 Best Performer
- 74.3 36 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 9.0 87.1 34 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 15.2 82.8 31 Multiple (3)
3.04 Pupils per teacher in secondary education 9.6 84.5 11 Armenia
3.05 Harmonized learning outcomes (score) 506.2 76.5 35 Singapore
3.06 Social diversity in schools (score) 71.6 52.1 41 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material37.2 62.8 26 Multiple (2)
- 61.3 30 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.7 62.5 24 Switzerland
4.02 Active labour market policies (1–7) 4.5 57.8 28 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.2 86.5 6 Switzerland
4.04 Percentage of ﬁrms of fering formal training 18.6 24.8 39 Ecuador
4.05 Digital skills among active population (1–7) 5.5 75.0 6 Finland
- 83.0 23 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 81.6 81.6 28 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 28.8 57.5 28 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 106.1 88.4 18 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.0 99.0 37 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.3 71.6 23 Singapore
- 79.7 13 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.6 61.7 49 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.0 79.8 26 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.9 88.3 18 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 85.8 82.3 11 Lao PDR
6.06 Workers in vulnerable employment (%) 8.2 86.4 16 Saudi Arabia
- 56.1 31 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 24.6 29.7 47 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 70.2 66.8 19 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 36.1 65.3 19 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 53.2 62.7 32 Switzerland
- 63.2 28 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 83.0 83.0 26 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.0 66.5 23 Singapore
8.03 Pay and productivity (1–7) 4.8 62.7 13 Switzerland
8.04 Employees working more than 48 hours per week (%) 11.1 77.7 39 Bulgaria
8.05 Collective bargaining coverage ratio (%) 26 26.1 39 France
- 55.4 46 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 31.0 41.3 29 Multiple (2)
9.02 Social protection coverage (% of population) 54.9 54.9 41 Multiple (6)
9.03 Social protection spending (% of GDP) 16.0 64.2 38 Multiple (9)
9.04 Social safety net protection, 1-7 4.7 61.1 29 Norway
- 56.3 50 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 61.0 61.0 25 Denmark
10.02 Government and public services efﬁciency (score) 1.2 78.1 21 Singapore
10.03 Inclusiveness of institutions (score) -1.0 40.4 77 Portugal
10.04 Political stability and protection from violence (score) -0.9 45.6 73 New Zealand

114Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

34th
16th
37th
17th
74th
36th
63rd
18th
14th
40th
38th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6790
6879
4077
616571
5864
Italy 34th /82
Index Component Value Score      Rank/ 82 Best Performer
- 90.1 16 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 5.2 94.8 14 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 13.1 73.9 57 Ghana
1.03 Health Access and Quality Index (0–100 best) 94.9 94.9 9 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 96.7 4 Singapore
- 68.0 37 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 88.8 88.8 19 Malta
2.02 Quality of vocational training (1–7) 4.5 58.4 35 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 19.2 36.0 56 Japan
2.04 Out-of-school children (%) 1.4 86.0 28 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 70.8 44 GermanyItaly 34th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %60.5
1,937.9
34,260.31.77
35.4
0.2

115Italy 34th /82
Index Component Value Score       Rank/ 82 Best Performer
- 79.1 17 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.1 97.0 12 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.4 75.2 25 Australia
3.03 Pupils per teacher in primary education 11.7 94.5 12 Multiple (3)
3.04 Pupils per teacher in secondary education 10.4 82.2 18 Armenia
3.05 Harmonized learning outcomes (score) 511.3 77.8 32 Singapore
3.06 Social diversity in schools (score) 78.1 67.7 21 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material40.8 59.2 31 Multiple (2)
- 40.2 74 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.6 70 Switzerland
4.02 Active labour market policies (1–7) 2.8 30.4 66 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.4 57.5 46 Switzerland
4.04 Percentage of ﬁrms of fering formal training 12.6 16.8 45 Ecuador
4.05 Digital skills among active population (1–7) 4.2 52.9 56 Finland
- 77.2 36 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 74.4 74.4 41 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 28.0 56.1 33 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 94.5 78.8 29 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.3 54.2 50 Singapore
- 61.2 63 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 15.4 38.6 69 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 10.1 59.5 64 Thailand
6.02 Unemployment among labor force with advanced education (%) 5.9 76.3 54 Czech Republic
6.04 Unemployment in rural areas (%) 10.0 60.2 59 Peru
6.05 Ratio of female to male labour force participation rate 68.7 60.9 60 Lao PDR
6.06 Workers in vulnerable employment (%) 17.0 71.7 40 Saudi Arabia
- 65.2 18 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 7.6 78.2 8 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 62.2 58.0 26 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 34.8 62.0 22 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 44.4 55.5 39 Multiple (4)
7.05 Adjusted labour income share (%) 57.5 72.2 21 Switzerland
- 70.9 14 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 98.0 98.0 5 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.0 49.4 73 Singapore
8.03 Pay and productivity (1–7) 3.1 35.5 81 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.2 91.6 9 Bulgaria
8.05 Collective bargaining coverage ratio (%) 80 80.0 10 France
- 58.3 40 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 15.0 20.0 37 Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 28.9 100.0 4 Multiple (9)
9.04 Social safety net protection, 1-7 4.3 54.8 36 Norway
- 64.2 38 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 52.0 52.0 37 Denmark
10.02 Government and public services efﬁciency (score) 0.4 61.2 41 Singapore
10.03 Inclusiveness of institutions (score) 0.2 70.7 37 Portugal
10.04 Political stability and protection from violence (score) 0.3 72.9 38 New Zealand

116Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

15th
3rd
13th
39th
19th
16th
5th
37th
38th
10th
13th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7694
82
73
668783
526181 82
Japan 15th /82
Index Component Value Score      Rank/ 82 Best Performer
- 94.2 3 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 3.8 96.2 5 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 5.3 89.3 9 Ghana
1.03 Health Access and Quality Index (0–100 best) 94.1 94.1 11 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 97.1 2 Singapore
- 81.8 13 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 4.9 65.3 16 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 2.9 90.2 1 Japan
2.04 Out-of-school children (%) 1.2 88.0 25 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 83.5 19 GermanyJapan 15th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %126.5
4,872.1
39,305.84.14
32.1
1.2

117Japan 15th /82
Index Component Value Score       Rank/ 82 Best Performer
- 73.0 39 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 1.0 98.6 4 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 14.5 68.3 36 Australia
3.03 Pupils per teacher in primary education 16.4 78.6 41 Multiple (3)
3.04 Pupils per teacher in secondary education 11.8 77.4 27 Armenia
3.05 Harmonized learning outcomes (score) 562.0 90.5 3 Singapore
3.06 Social diversity in schools (score) 76.8 64.8 23 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material67.4 32.6 51 Multiple (2)
- 66.4 19 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.3 71.0 9 Switzerland
4.02 Active labour market policies (1–7) 4.7 62.0 20 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.5 75.2 25 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.4 57.2 45 Finland
- 87.0 16 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 84.6 84.6 22 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 32.2 64.3 21 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 188.9 100.0 1 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.9 99.9 18 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.4 73.1 20 Singapore
- 82.7 5 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) n/a n/a n/a Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.1 87.6 7 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.3 90.8 9 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 73.0 66.2 51 Lao PDR
6.06 Workers in vulnerable employment (%) 8.4 86.1 18 Saudi Arabia
- 52.0 37 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 12.3 64.8 16 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 47.0 41.1 43 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 24.8 37.0 52 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 54.2 64.9 28 Switzerland
- 60.9 38 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 90.0 90.0 14 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.8 79.9 5 Singapore
8.03 Pay and productivity (1–7) 4.5 58.9 26 Switzerland
8.04 Employees working more than 48 hours per week (%) 20.4 59.2 53 Bulgaria
8.05 Collective bargaining coverage ratio (%) 17 16.7 49 France
- 81.3 10 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 64.0 85.3 1 Multiple (2)
9.02 Social protection coverage (% of population) 75.4 75.4 31 Multiple (6)
9.03 Social protection spending (% of GDP) 23.1 92.2 14 Multiple (9)
9.04 Social safety net protection, 1-7 5.3 72.2 16 Norway
- 81.9 13 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 73.0 73.0 17 Denmark
10.02 Government and public services efﬁciency (score) 1.7 88.1 10 Singapore
10.03 Inclusiveness of institutions (score) 0.4 77.0 20 Portugal
10.04 Political stability and protection from violence (score) 1.1 89.4 9 New Zealand

118Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

38th
53rd
32nd
33rd
46th
51st
30th
25th
16th
43rd
63rd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6571 7075
517075
6169
56
50
Kazakhstan 38th /82
Index Component Value Score      Rank/ 82 Best Performer
- 71.4 53 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 29.8 70.3 51 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.7 82.6 19 Ghana
1.03 Health Access and Quality Index (0–100 best) 69.1 69.1 54 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 63.8 65 Singapore
- 69.9 32 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 58.7 58.7 53 Malta
2.02 Quality of vocational training (1–7) 3.8 46.8 61 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 9.5 68.4 22 Japan
2.04 Out-of-school children (%) 0.3 97.0 10 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 78.8 29 GermanyKazakhstan 38th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %18.5
160.8
9,237.00.38
27.5
3.9

119Kazakhstan 38th /82
Index Component Value Score       Rank/ 82 Best Performer
- 74.7 33 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 1.9 97.3 9 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 9.3 85.5 9 Australia
3.03 Pupils per teacher in primary education 19.6 67.9 56 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 541.5 85.4 6 Singapore
3.06 Social diversity in schools (score) 78.7 69.3 17 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material57.4 42.6 46 Multiple (2)
- 51.1 46 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.9 48.3 54 Switzerland
4.02 Active labour market policies (1–7) 4.2 52.9 32 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 55.0 55 Switzerland
4.04 Percentage of ﬁrms of fering formal training 28.3 37.7 31 Ecuador
4.05 Digital skills among active population (1–7) 4.7 61.5 33 Finland
- 69.7 51 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 78.9 78.9 36 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 13.4 26.9 54 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 77.6 64.6 48 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 87.9 87.9 73 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.6 59.8 41 Singapore
- 74.9 30 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 6.6 73.4 33 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.4 78.5 28 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.7 85.2 33 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 84.3 80.4 22 Lao PDR
6.06 Workers in vulnerable employment (%) 25.9 56.8 50 Saudi Arabia
- 61.2 25 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 59.6 55.1 27 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 33.5 58.8 24 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 58.4 95.4 6 Multiple (4)
7.05 Adjusted labour income share (%) 41.0 35.6 68 Switzerland
- 69.1 16 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 64.0 64.0 57 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 57.7 49 Singapore
8.03 Pay and productivity (1–7) 4.3 55.3 36 Switzerland
8.04 Employees working more than 48 hours per week (%) 3.1 93.7 6 Bulgaria
8.05 Collective bargaining coverage ratio (%) 75 74.7 12 France
- 56.5 43 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 100.0 100.0 1 Multiple (6)
9.03 Social protection spending (% of GDP) 5.4 21.5 66 Multiple (9)
9.04 Social safety net protection, 1-7 3.9 47.9 51 Norway
- 49.7 63 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 31.0 31.0 74 Denmark
10.02 Government and public services efﬁciency (score) 0.0 52.8 54 Singapore
10.03 Inclusiveness of institutions (score) -0.7 48.7 70 Portugal
10.04 Political stability and protection from violence (score) 0.0 66.1 49 New Zealand

120Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
25th 9th 24th 29th 14th 3rd 17th 56th 36th 45th 25th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7191
76 76
6892
79
4261
5574
Korea, Rep. 25th /82
Index Component Value Score      Rank/ 82 Best Performer
- 91.1 9 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 1.4 98.6 1 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.1 79.8 35 Ghana
1.03 Health Access and Quality Index (0–100 best) 90.3 90.3 24 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 95.8 6 Singapore
- 75.5 24 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 94.9 94.9 8 Malta
2.02 Quality of vocational training (1–7) 4.8 63.9 21 Switzerland
2.03 NEET ratio (% of 15–24 year olds) n/a n/a n/a Japan
2.04 Out-of-school children (%) 2.7 73.0 43 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 70.2 45 GermanyKorea, Rep. 25th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %51.7
1,538.0
31,345.61.58
31.6
3.0