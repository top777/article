61Chile 47th /82
Index Component Value Score       Rank/ 82 Best Performer
- 52.0 59 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 30.3 56.7 46 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 23.6 37.9 61 Australia
3.03 Pupils per teacher in primary education 19.8 67.4 57 Multiple (3)
3.04 Pupils per teacher in secondary education 21.2 46.1 61 Armenia
3.05 Harmonized learning outcomes (score) 464.7 66.2 45 Singapore
3.06 Social diversity in schools (score) 56.3 15.2 61 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material25.6 74.4 17 Multiple (2)
- 53.1 39 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.1 52.1 42 Switzerland
4.02 Active labour market policies (1–7) 3.1 34.4 58 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.3 71.3 30 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.3 54.4 49 Finland
- 74.6 42 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 82.3 82.3 26 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 17.4 34.7 45 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 91.6 76.3 33 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 95.0 95.0 58 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.5 59.0 46 Singapore
- 69.1 47 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 6.3 74.8 29 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 7.8 68.7 51 Thailand
6.02 Unemployment among labor force with advanced education (%) 7.0 71.9 59 Czech Republic
6.04 Unemployment in rural areas (%) 5.5 78.2 41 Peru
6.05 Ratio of female to male labour force participation rate 68.9 61.2 59 Lao PDR
6.06 Workers in vulnerable employment (%) 24.0 60.1 48 Saudi Arabia
- 47.6 46 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 11.9 65.9 14 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 32.4 24.9 59 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 23.5 33.7 55 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 35.9 31.1 57 Multiple (4)
7.05 Adjusted labour income share (%) 62.1 82.4 5 Switzerland
- 57.3 48 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 70.0 70.0 50 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.6 59.3 41 Singapore
8.03 Pay and productivity (1–7) 4.4 56.0 33 Switzerland
8.04 Employees working more than 48 hours per week (%) 9.2 81.6 35 Bulgaria
8.05 Collective bargaining coverage ratio (%) 20 19.6 45 France
- 50.1 49 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 14.0 18.7 38 Multiple (2)
9.02 Social protection coverage (% of population) 69.2 69.2 34 Multiple (6)
9.03 Social protection spending (% of GDP) 15.3 61.4 41 Multiple (9)
9.04 Social safety net protection, 1-7 4.1 51.1 45 Norway
- 73.2 28 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 67.0 67.0 23 Denmark
10.02 Government and public services efﬁciency (score) 1.1 75.5 26 Singapore
10.03 Inclusiveness of institutions (score) 0.3 74.7 32 Portugal
10.04 Political stability and protection from violence (score) 0.4 75.5 32 New Zealand

62Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

45th
34th
28th
52nd
31st
40th
44th
68th
52nd
48th
51st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6180
72
636075
70
3256
5056
China 45th /82
Index Component Value Score      Rank/ 82 Best Performer
- 80.5 34 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.6 92.4 21 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 14.6 70.8 63 Ghana
1.03 Health Access and Quality Index (0–100 best) 77.9 77.9 39 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 80.9 37 Singapore
- 72.0 28 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 4.5 58.9 33 Switzerland
2.03 NEET ratio (% of 15–24 year olds) n/a n/a n/a Japan
2.04 Out-of-school children (%) 0.0 100.0 1 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 57.1 62 GermanyChina 45th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %1,395.4
12,014.6
9,608.418.69
38.6
6.7

63China 45th /82
Index Component Value Score       Rank/ 82 Best Performer
- 63.3 52 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 18.2 74.0 42 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 17.4 58.7 48 Australia
3.03 Pupils per teacher in primary education 16.4 78.6 40 Multiple (3)
3.04 Pupils per teacher in secondary education 14.5 68.4 48 Armenia
3.05 Harmonized learning outcomes (score) 456.0 64.0 48 Singapore
3.06 Social diversity in schools (score) 63.2 31.9 51 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material32.4 67.6 23 Multiple (2)
- 59.7 31 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.5 58.3 31 Switzerland
4.02 Active labour market policies (1–7) 4.5 58.2 27 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.7 61.3 39 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.7 61.0 35 Finland
- 75.0 40 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 54.3 54.3 68 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 28.5 57.1 29 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 95.4 79.5 28 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.4 99.4 30 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 64 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.6 59.7 42 Singapore
- 70.1 44 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 4.4 82.4 22 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.4 82.4 20 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.4 82.4 43 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 80.4 75.5 34 Lao PDR
6.06 Workers in vulnerable employment (%) 43.3 27.9 65 Saudi Arabia
- 32.0 68 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 21.9 37.4 39 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 16.0 6.7 74 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 12.9 7.3 73 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 42.6 50.2 47 Multiple (4)
7.05 Adjusted labour income share (%) 51.3 58.4 41 Switzerland
- 56.2 52 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 64.0 64.0 57 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.6 59.6 39 Singapore
8.03 Pay and productivity (1–7) 4.6 60.5 20 Switzerland
8.04 Employees working more than 48 hours per week (%) n/a n/a n/a Bulgaria
8.05 Collective bargaining coverage ratio (%) 41 40.6 31 France
- 50.3 48 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 67.4 67.4 35 Multiple (6)
9.03 Social protection spending (% of GDP) 6.3 25.1 63 Multiple (9)
9.04 Social safety net protection, 1-7 4.5 58.2 32 Norway
- 55.7 51 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 39.0 39.0 54 Denmark
10.02 Government and public services efﬁciency (score) 0.5 62.5 39 Singapore
10.03 Inclusiveness of institutions (score) -0.2 61.1 58 Portugal
10.04 Political stability and protection from violence (score) -0.3 60.4 55 New Zealand

64Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

65th
59th
63rd
76th
43rd
61st
64th
58th
75th
50th
68th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5067
49
325264
59
394449 49
Colombia 65th /82
Index Component Value Score      Rank/ 82 Best Performer
- 66.6 59 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 66.7 33.3 71 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.0 82.0 22 Ghana
1.03 Health Access and Quality Index (0–100 best) 68.5 68.5 55 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 82.4 32 Singapore
- 48.6 63 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 75.1 75.1 38 Malta
2.02 Quality of vocational training (1–7) 4.5 57.7 38 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 22.6 24.7 59 Japan
2.04 Out-of-school children (%) 6.9 31.0 59 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.5 54.5 64 GermanyColombia 65th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %49.8
309.2
6,684.40.55
49.7
3.3

65Colombia 65th /82
Index Component Value Score       Rank/ 82 Best Performer
- 32.0 76 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 44.7 36.1 52 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 33.0 6.6 71 Australia
3.03 Pupils per teacher in primary education 23.6 54.7 64 Multiple (3)
3.04 Pupils per teacher in secondary education 25.1 33.1 66 Armenia
3.05 Harmonized learning outcomes (score) 422.6 55.7 57 Singapore
3.06 Social diversity in schools (score) 59.5 22.9 60 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material85.2 14.8 62 Multiple (2)
- 52.5 43 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.7 44.3 67 Switzerland
4.02 Active labour market policies (1–7) 2.9 32.2 60 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 55.2 53 Switzerland
4.04 Percentage of ﬁrms of fering formal training 63.0 84.0 4 Ecuador
4.05 Digital skills among active population (1–7) 3.8 46.6 66 Finland
- 64.0 61 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 62.3 62.3 61 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 13.4 26.9 53 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 52.3 43.6 72 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 97.9 97.9 67 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.2 53.2 51 Singapore
- 59.1 64 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 6.5 74.0 30 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 10.7 57.0 67 Thailand
6.02 Unemployment among labor force with advanced education (%) 11.2 55.1 69 Czech Republic
6.04 Unemployment in rural areas (%) 4.5 81.9 34 Peru
6.05 Ratio of female to male labour force participation rate 71.5 64.4 55 Lao PDR
6.06 Workers in vulnerable employment (%) 46.6 22.3 67 Saudi Arabia
- 38.9 58 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 14.9 57.5 21 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 33.2 25.8 58 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 23.0 32.5 57 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 30.8 16.6 63 Multiple (4)
7.05 Adjusted labour income share (%) 53.0 62.2 34 Switzerland
- 43.6 75 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 55.0 55.0 73 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 58.1 47 Singapore
8.03 Pay and productivity (1–7) 3.6 44.0 65 Switzerland
8.04 Employees working more than 48 hours per week (%) 27.5 45.1 60 Bulgaria
8.05 Collective bargaining coverage ratio (%) 16 15.7 50 France
- 49.3 50 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 40.8 40.8 46 Multiple (6)
9.03 Social protection spending (% of GDP) 14.1 56.3 45 Multiple (9)
9.04 Social safety net protection, 1-7 4.0 50.8 46 Norway
- 48.9 68 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 36.0 36.0 59 Denmark
10.02 Government and public services efﬁciency (score) -0.1 50.5 60 Singapore
10.03 Inclusiveness of institutions (score) -0.2 61.0 59 Portugal
10.04 Political stability and protection from violence (score) -0.8 48.2 70 New Zealand

66Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

44th
55th
34th
53rd
38th
41st
62nd
57th
56th
30th
34th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6270 69
61
5375
62
40546468
Costa Rica 44th /82
Index Component Value Score      Rank/ 82 Best Performer
- 69.5 55 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 53.5 46.5 61 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 14.2 71.7 61 Ghana
1.03 Health Access and Quality Index (0–100 best) 73.7 73.7 48 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 86.2 29 Singapore
- 69.2 34 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 90.5 90.5 16 Malta
2.02 Quality of vocational training (1–7) 5.0 66.7 15 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 19.0 36.6 54 Japan
2.04 Out-of-school children (%) 1.1 89.0 24 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 63.4 53 GermanyCosta Rica 44th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %5.0
58.1
11,744.40.07
48.3
3.3

67Costa Rica 44th /82
Index Component Value Score       Rank/ 82 Best Performer
- 61.2 53 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 31.7 54.7 47 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.3 75.8 23 Australia
3.03 Pupils per teacher in primary education 11.6 94.5 11 Multiple (3)
3.04 Pupils per teacher in secondary education 13.4 71.9 42 Armenia
3.05 Harmonized learning outcomes (score) 426.2 56.5 56 Singapore
3.06 Social diversity in schools (score) 63.1 31.7 52 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material56.7 43.3 45 Multiple (2)
- 53.4 38 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.3 55.1 37 Switzerland
4.02 Active labour market policies (1–7) 2.8 29.6 67 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.8 64.0 35 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.9 64.8 24 Finland
- 74.8 41 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 74.1 74.1 43 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 16.6 33.2 47 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 97.2 81.0 26 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 97.3 97.3 53 Multiple (13)
5.05 Rural population with electricity access (%) 98.9 98.9 65 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.9 64.3 33 Singapore
- 62.1 62 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 8.9 64.4 41 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 12.7 49.2 71 Thailand
6.02 Unemployment among labor force with advanced education (%) 5.3 78.7 50 Czech Republic
6.04 Unemployment in rural areas (%) 9.7 61.3 55 Peru
6.05 Ratio of female to male labour force participation rate 61.6 52.0 68 Lao PDR
6.06 Workers in vulnerable employment (%) 19.9 66.8 41 Saudi Arabia
- 40.0 57 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 13.9 60.3 17 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 29.9 22.1 64 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 21.6 28.9 61 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 32.0 20.0 62 Multiple (4)
7.05 Adjusted labour income share (%) 56.0 68.9 25 Switzerland
- 53.8 56 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 86.0 86.0 23 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.2 69.6 17 Singapore
8.03 Pay and productivity (1–7) 4.3 54.6 38 Switzerland
8.04 Employees working more than 48 hours per week (%) 25.8 48.4 56 Bulgaria
8.05 Collective bargaining coverage ratio (%) 11 10.6 57 France
- 64.2 30 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 72.0 72.0 33 Multiple (6)
9.03 Social protection spending (% of GDP) 13.6 54.2 46 Multiple (9)
9.04 Social safety net protection, 1-7 5.0 66.3 25 Norway
- 67.6 34 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 56.0 56.0 35 Denmark
10.02 Government and public services efﬁciency (score) 0.4 60.4 42 Singapore
10.03 Inclusiveness of institutions (score) 0.4 77.3 18 Portugal
10.04 Political stability and protection from violence (score) 0.5 76.8 30 New Zealand

68Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

82nd
81st
82nd
81st
72nd
80th
60th
82nd
68th
79th
70th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions3439
172241 4163
249
2348
Côte d'Ivoire 82nd /82
Index Component Value Score      Rank/ 82 Best Performer
- 39.1 81 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 117.6 0.0 82 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.1 99.8 2 Ghana
1.03 Health Access and Quality Index (0–100 best) 27.3 27.3 82 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 29.1 82 Singapore
- 16.6 82 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 7.6 7.6 69 Malta
2.02 Quality of vocational training (1–7) 4.2 53.4 50 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 34.8 0.0 75 Japan
2.04 Out-of-school children (%) 21.1 0.0 68 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.2 22.3 79 GermanyCôte d'Ivoire 82nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %25.6
40.4
1,680.40.08
41.5
5.5

69Côte d'Ivoire 82nd /82
Index Component Value Score       Rank/ 82 Best Performer
- 22.3 81 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 77.6 0.0 69 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 21.1 46.3 59 Australia
3.03 Pupils per teacher in primary education 41.8 0.0 79 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 371.2 42.8 73 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 40.9 72 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.0 50.5 46 Switzerland
4.02 Active labour market policies (1–7) 2.3 21.0 78 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.4 39.4 80 Switzerland
4.04 Percentage of ﬁrms of fering formal training 35.5 47.3 24 Ecuador
4.05 Digital skills among active population (1–7) 3.8 46.4 67 Finland
- 40.8 80 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 46.8 46.8 71 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 0.7 1.4 79 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 61.6 51.3 64 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 70.0 70.0 82 Multiple (13)
5.05 Rural population with electricity access (%) 36.6 36.6 80 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.3 38.7 74 Singapore
- 63.4 60 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 2.2 91.0 9 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 6.4 74.4 43 Thailand
6.02 Unemployment among labor force with advanced education (%) 12.4 50.4 72 Czech Republic
6.04 Unemployment in rural areas (%) 0.6 97.5 2 Peru
6.05 Ratio of female to male labour force participation rate 73.4 66.7 50 Lao PDR
6.06 Workers in vulnerable employment (%) 72.0 0.0 79 Saudi Arabia
- 1.9 82 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 3.2 0.0 82 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 4.0 0.0 82 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) n/a n/a n/a Multiple (4)
7.05 Adjusted labour income share (%) 27.5 5.6 81 Switzerland
- 49.1 68 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 73.0 73.0 41 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.8 63.4 31 Singapore
8.03 Pay and productivity (1–7) 3.3 38.9 77 Switzerland
8.04 Employees working more than 48 hours per week (%) 39.4 21.3 72 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 22.8 79 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 2.0 8.0 77 Multiple (9)
9.04 Social safety net protection, 1-7 3.3 37.6 71 Norway
- 47.8 70 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 35.0 35.0 63 Denmark
10.02 Government and public services efﬁciency (score) -0.6 40.1 75 Singapore
10.03 Inclusiveness of institutions (score) 0.2 70.6 38 Portugal
10.04 Political stability and protection from violence (score) -0.9 45.6 72 New Zealand

70Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

36th
30th
48th
18th
51st
48th
59th
11th
35th
42nd
33rd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6784
6179
4871
6473
615768
Croatia 36th /82
Index Component Value Score      Rank/ 82 Best Performer
- 83.9 30 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 8.7 91.3 28 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 12.5 75.1 51 Ghana
1.03 Health Access and Quality Index (0–100 best) 86.9 86.9 29 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 82.2 33 Singapore
- 60.7 48 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 62.5 62.5 50 Malta
2.02 Quality of vocational training (1–7) 3.5 41.2 75 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 13.6 54.8 36 Japan
2.04 Out-of-school children (%) 3.0 70.0 46 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 75.2 36 GermanyCroatia 36th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %4.1
54.5
14,815.90.08
31.1
0.7

71Croatia 36th /82
Index Component Value Score       Rank/ 82 Best Performer
- 78.9 18 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 1.0 98.6 4 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.9 73.5 28 Australia
3.03 Pupils per teacher in primary education 13.5 88.3 23 Multiple (3)
3.04 Pupils per teacher in secondary education 6.1 96.5 2 Armenia
3.05 Harmonized learning outcomes (score) 503.3 75.8 37 Singapore
3.06 Social diversity in schools (score) 81.5 76.1 12 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material56.2 43.8 44 Multiple (2)
- 48.4 51 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.3 37.8 81 Switzerland
4.02 Active labour market policies (1–7) 3.3 38.4 53 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.3 54.9 56 Switzerland
4.04 Percentage of ﬁrms of fering formal training 49.3 65.7 10 Ecuador
4.05 Digital skills among active population (1–7) 3.7 45.3 71 Finland
- 71.1 48 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 72.7 72.7 46 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 27.0 53.9 36 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 79.5 66.2 46 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.4 99.4 30 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.1 34.5 80 Singapore
- 63.8 59 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 19.6 21.7 76 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 9.1 63.5 61 Thailand
6.02 Unemployment among labor force with advanced education (%) 6.0 75.9 55 Czech Republic
6.04 Unemployment in rural areas (%) 9.7 61.0 56 Peru
6.05 Ratio of female to male labour force participation rate 78.8 73.5 37 Lao PDR
6.06 Workers in vulnerable employment (%) 7.5 87.5 12 Saudi Arabia
- 72.9 11 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 75.4 72.7 13 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 38.7 71.7 13 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 50.8 73.6 24 Multiple (4)
7.05 Adjusted labour income share (%) 58.1 73.6 18 Switzerland
- 61.5 35 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 90.0 90.0 14 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.4 39.8 80 Singapore
8.03 Pay and productivity (1–7) 3.4 39.8 76 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.5 91.0 14 Bulgaria
8.05 Collective bargaining coverage ratio (%) 47 46.7 27 France
- 56.8 42 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 34.0 45.3 26 Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 21.6 86.4 20 Multiple (9)
9.04 Social safety net protection, 1-7 3.3 38.5 68 Norway
- 68.5 33 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 48.0 48.0 40 Denmark
10.02 Government and public services efﬁciency (score) 0.5 62.1 40 Singapore
10.03 Inclusiveness of institutions (score) 0.5 80.8 12 Portugal
10.04 Political stability and protection from violence (score) 0.8 83.0 21 New Zealand

72Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

29th
1st
41st
26th
36th
35th
49th
32nd
41st
25th
32nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6994
6677
5677
69
566069 69
Cyprus 29th /82
Index Component Value Score      Rank/ 82 Best Performer
- 94.5 1 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 4.6 95.4 8 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.1 99.7 5 Ghana
1.03 Health Access and Quality Index (0–100 best) 90.3 90.3 24 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 92.4 11 Singapore
- 66.2 41 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 70.0 70.0 45 Malta
2.02 Quality of vocational training (1–7) 4.3 55.7 40 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 13.2 56.0 35 Japan
2.04 Out-of-school children (%) 2.2 78.0 36 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 71.4 41 GermanyCyprus 29th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %0.9
21.3
28,339.90.03
34.0
0.6

73Cyprus 29th /82
Index Component Value Score       Rank/ 82 Best Performer
- 76.7 26 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 14.3 79.6 40 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 12.6 74.7 26 Australia
3.03 Pupils per teacher in primary education 11.9 93.6 15 Multiple (3)
3.04 Pupils per teacher in secondary education 10.2 82.6 17 Armenia
3.05 Harmonized learning outcomes (score) 500.5 75.1 39 Singapore
3.06 Social diversity in schools (score) 84.9 84.3 6 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material53.4 46.6 41 Multiple (2)
- 56.0 36 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.1 52.3 40 Switzerland
4.02 Active labour market policies (1–7) 3.8 46.6 39 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.7 60.8 41 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.9 64.3 25 Finland
- 77.5 35 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 84.4 84.4 24 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 26.4 52.7 38 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 80.8 67.3 44 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 16 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.6 60.3 38 Singapore
- 68.5 49 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.6 61.7 48 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 8.8 64.7 59 Thailand
6.02 Unemployment among labor force with advanced education (%) 7.6 69.7 62 Czech Republic
6.04 Unemployment in rural areas (%) 12.1 51.7 61 Peru
6.05 Ratio of female to male labour force participation rate 85.5 81.9 13 Lao PDR
6.06 Workers in vulnerable employment (%) 11.1 81.5 30 Saudi Arabia
- 56.0 32 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 54.6 49.5 34 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 30.1 50.3 33 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 49.9 71.2 28 Multiple (4)
7.05 Adjusted labour income share (%) 48.9 53.1 50 Switzerland
- 60.5 41 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) n/a n/a n/a Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.8 62.7 32 Singapore
8.03 Pay and productivity (1–7) 3.9 48.8 54 Switzerland
8.04 Employees working more than 48 hours per week (%) 8.7 82.7 34 Bulgaria
8.05 Collective bargaining coverage ratio (%) 48 47.7 26 France
- 69.3 25 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 61.2 61.2 40 Multiple (6)
9.03 Social protection spending (% of GDP) 23.0 92.0 15 Multiple (9)
9.04 Social safety net protection, 1-7 4.3 54.8 37 Norway
- 69.3 32 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 59.0 59.0 28 Denmark
10.02 Government and public services efﬁciency (score) 0.9 72.0 33 Singapore
10.03 Inclusiveness of institutions (score) 0.1 68.3 45 Portugal
10.04 Political stability and protection from violence (score) 0.5 78.1 29 New Zealand

74Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

19th
29th
12th
38th
22nd
29th
21st
8th
24th
21st
24th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions758482
74
66807774
657174
Czech Republic 19th /82
Index Component Value Score      Rank/ 82 Best Performer
- 84.3 29 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 12.0 88.0 33 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 11.2 77.5 47 Ghana
1.03 Health Access and Quality Index (0–100 best) 89.0 89.0 27 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 82.8 31 Singapore
- 82.2 12 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 83.5 83.5 27 Malta
2.02 Quality of vocational training (1–7) 4.5 58.1 36 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 5.6 81.2 7 Japan
2.04 Out-of-school children (%) 0.0 100.0 1 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 87.9 10 GermanyCzech Republic 19th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %10.6
213.2
22,850.30.29
25.9
2.0

75Czech Republic 19th /82
Index Component Value Score       Rank/ 82 Best Performer
- 73.5 38 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 3.0 95.7 19 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 13.2 72.8 31 Australia
3.03 Pupils per teacher in primary education 19.1 69.5 53 Multiple (3)
3.04 Pupils per teacher in secondary education 11.1 79.6 22 Armenia
3.05 Harmonized learning outcomes (score) 523.5 80.9 21 Singapore
3.06 Social diversity in schools (score) 72.3 53.9 38 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material37.9 62.1 27 Multiple (2)
- 65.5 22 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.5 58.0 32 Switzerland
4.02 Active labour market policies (1–7) 5.0 66.4 10 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.0 66.7 32 Switzerland
4.04 Percentage of ﬁrms of fering formal training 55.1 73.5 7 Ecuador
4.05 Digital skills among active population (1–7) 4.8 63.0 31 Finland
- 79.7 29 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 80.7 80.7 32 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 29.9 59.9 25 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 88.1 73.4 36 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.8 99.8 23 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.9 64.7 32 Singapore
- 76.6 21 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 13.0 48.0 64 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 2.1 91.8 2 Thailand
6.02 Unemployment among labor force with advanced education (%) 1.2 95.3 1 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 76.9 71.1 42 Lao PDR
6.06 Workers in vulnerable employment (%) 13.8 76.9 37 Saudi Arabia
- 74.3 8 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 20.3 42.0 35 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 90.8 89.8 6 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 43.3 83.3 5 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 60.8 100.0 2 Multiple (4)
7.05 Adjusted labour income share (%) 50.4 56.4 44 Switzerland
- 65.2 24 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 90.0 90.0 14 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.7 61.7 35 Singapore
8.03 Pay and productivity (1–7) 4.4 56.8 31 Switzerland
8.04 Employees working more than 48 hours per week (%) 6.5 87.1 26 Bulgaria
8.05 Collective bargaining coverage ratio (%) 30 30.4 34 France
- 71.3 21 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 39.0 52.0 18 Multiple (2)
9.02 Social protection coverage (% of population) 88.8 88.8 24 Multiple (6)
9.03 Social protection spending (% of GDP) 19.5 77.9 25 Multiple (9)
9.04 Social safety net protection, 1-7 5.0 66.4 24 Norway
- 73.9 24 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 59.0 59.0 28 Denmark
10.02 Government and public services efﬁciency (score) 0.9 72.0 32 Singapore
10.03 Inclusiveness of institutions (score) 0.4 75.7 26 Portugal
10.04 Political stability and protection from violence (score) 1.0 89.0 11 New Zealand

76Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

1st
14th
5th
2nd
8th
1st
6th
3rd
2nd
1st
8th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions8590
85 86
7594
82 81839086
Denmark 1st/82
Index Component Value Score      Rank/ 82 Best Performer
- 90.2 14 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 4.1 95.9 7 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.2 83.6 17 Ghana
1.03 Health Access and Quality Index (0–100 best) 92.1 92.1 16 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 89.4 24 Singapore
- 85.0 5 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 93.1 93.1 14 Malta
2.02 Quality of vocational training (1–7) 5.6 76.8 4 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 6.8 77.2 12 Japan
2.04 Out-of-school children (%) 1.0 90.0 23 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 88.0 8 GermanyDenmark 1st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %5.8
324.5
60,692.40.22
28.2
1.4

77Denmark 1st/82
Index Component Value Score       Rank/ 82 Best Performer
- 86.1 2 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 2.6 96.3 15 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 9.7 84.5 12 Australia
3.03 Pupils per teacher in primary education 11.9 93.8 14 Multiple (3)
3.04 Pupils per teacher in secondary education 13.1 73.0 36 Armenia
3.05 Harmonized learning outcomes (score) 532.2 83.1 13 Singapore
3.06 Social diversity in schools (score) 85.6 85.8 5 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material13.9 86.1 5 Multiple (2)
- 75.1 8 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.3 71.2 7 Switzerland
4.02 Active labour market policies (1–7) 5.2 70.6 6 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.1 85.1 9 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.4 73.6 9 Finland
- 94.1 1 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 97.6 97.6 2 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 44.1 88.1 3 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 136.7 100.0 7 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.7 79.0 13 Singapore
- 82.1 6 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.0 64.0 42 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 3.9 84.3 13 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.1 83.8 37 Czech Republic
6.04 Unemployment in rural areas (%) 4.1 83.8 25 Peru
6.05 Ratio of female to male labour force participation rate 88.1 85.1 8 Lao PDR
6.06 Workers in vulnerable employment (%) 5.1 91.5 4 Saudi Arabia
- 80.7 3 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 8.2 76.5 9 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 82.0 80.0 9 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 42.5 81.2 7 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 57.4 92.5 9 Multiple (4)
7.05 Adjusted labour income share (%) 58.1 73.6 18 Switzerland
- 82.7 2 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 95.0 95.0 8 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.9 81.0 3 Singapore
8.03 Pay and productivity (1–7) 4.9 65.1 7 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.9 90.2 15 Bulgaria
8.05 Collective bargaining coverage ratio (%) 82 82.0 9 France
- 89.8 1 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 64.0 85.3 1 Multiple (2)
9.02 Social protection coverage (% of population) 89.5 89.5 23 Multiple (6)
9.03 Social protection spending (% of GDP) 28.8 100.0 5 Multiple (9)
9.04 Social safety net protection, 1-7 6.1 84.4 6 Norway
- 85.8 8 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 88.0 88.0 1 Denmark
10.02 Government and public services efﬁciency (score) 1.9 92.3 5 Singapore
10.03 Inclusiveness of institutions (score) 0.4 75.8 25 Portugal
10.04 Political stability and protection from violence (score) 1.0 87.2 15 New Zealand

78Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

57th
62nd
49th
64th
42nd
65th
40th
65th
50th
62nd
53rd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions546461
44536271
3557
3854
Ecuador 57th /82
Index Component Value Score      Rank/ 82 Best Performer
- 64.0 62 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 79.3 20.7 78 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 0.1 99.8 3 Ghana
1.03 Health Access and Quality Index (0–100 best) 62.2 62.2 65 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 73.2 53 Singapore
- 60.7 49 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 67.2 67.2 46 Malta
2.02 Quality of vocational training (1–7) 4.2 54.2 45 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 17.7 41.1 49 Japan
2.04 Out-of-school children (%) 1.9 81.0 33 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 60.1 57 GermanyEcuador 57th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %17.0
102.3
6,315.50.15
44.7
2.7

79Ecuador 57th /82
Index Component Value Score       Rank/ 82 Best Performer
- 43.8 64 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 62.1 11.3 58 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 20.4 48.7 57 Australia
3.03 Pupils per teacher in primary education 24.5 51.7 68 Multiple (3)
3.04 Pupils per teacher in secondary education 19.4 52.1 59 Armenia
3.05 Harmonized learning outcomes (score) 421.2 55.3 58 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 52.6 42 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.4 72 Switzerland
4.02 Active labour market policies (1–7) 2.3 21.2 77 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.2 54.1 60 Switzerland
4.04 Percentage of ﬁrms of fering formal training 73.7 98.3 1 Ecuador
4.05 Digital skills among active population (1–7) 3.8 46.0 69 Finland
- 61.5 65 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 57.3 57.3 65 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 11.4 22.9 59 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 54.7 45.6 70 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 93.0 93.0 66 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.0 50.3 58 Singapore
- 71.2 40 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 2.0 91.9 5 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.7 77.4 34 Thailand
6.02 Unemployment among labor force with advanced education (%) 5.3 78.9 49 Czech Republic
6.04 Unemployment in rural areas (%) 1.5 94.0 4 Peru
6.05 Ratio of female to male labour force participation rate 69.3 61.6 58 Lao PDR
6.06 Workers in vulnerable employment (%) 45.9 23.5 66 Saudi Arabia
- 35.3 65 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 17.2 50.9 29 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 26.1 17.8 70 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 17.4 18.4 70 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 35.3 29.3 59 Multiple (4)
7.05 Adjusted labour income share (%) 52.1 60.2 38 Switzerland
- 56.8 50 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 64.0 64.0 57 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.4 56.3 55 Singapore
8.03 Pay and productivity (1–7) 3.5 41.8 69 Switzerland
8.04 Employees working more than 48 hours per week (%) 17.5 65.0 48 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 38.4 62 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 31.7 31.7 49 Multiple (6)
9.03 Social protection spending (% of GDP) 7.8 31.1 57 Multiple (9)
9.04 Social safety net protection, 1-7 4.1 52.4 42 Norway
- 54.3 53 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 34.0 34.0 69 Denmark
10.02 Government and public services efﬁciency (score) -0.3 46.7 68 Singapore
10.03 Inclusiveness of institutions (score) 0.2 71.9 35 Portugal
10.04 Political stability and protection from violence (score) -0.1 64.5 50 New Zealand

80Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

71st
71st
70th
67th
78th
68th
76th
50th
72nd
53rd
81st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4555
39 403857
44 45 44 45
39
Egypt 71st /82
Index Component Value Score      Rank/ 82 Best Performer
- 55.3 71 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 53.8 46.2 62 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 20.2 59.7 76 Ghana
1.03 Health Access and Quality Index (0–100 best) 58.0 58.0 67 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 57.5 73 Singapore
- 39.4 70 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 25.6 25.6 64 Malta
2.02 Quality of vocational training (1–7) 3.2 36.7 80 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 26.9 10.4 64 Japan
2.04 Out-of-school children (%) 1.4 86.0 28 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.4 38.1 72 GermanyEgypt 71st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %97.0
237.1
2,573.30.96
31.8
3.3

81Egypt 71st /82
Index Component Value Score       Rank/ 82 Best Performer
- 39.9 67 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 69.2 1.1 65 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 26.0 29.9 65 Australia
3.03 Pupils per teacher in primary education 23.7 54.4 65 Multiple (3)
3.04 Pupils per teacher in secondary education 13.4 71.8 43 Armenia
3.05 Harmonized learning outcomes (score) 368.1 42.0 75 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 38.4 78 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.9 48.4 53 Switzerland
4.02 Active labour market policies (1–7) 2.6 27.1 71 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.9 48.7 71 Switzerland
4.04 Percentage of ﬁrms of fering formal training 5.2 6.9 49 Ecuador
4.05 Digital skills among active population (1–7) 4.7 61.0 34 Finland
- 56.9 68 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 46.9 46.9 70 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 6.7 13.4 66 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 53.9 44.9 71 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.7 98.7 44 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.2 37.3 76 Singapore
- 44.5 76 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 6.8 72.6 34 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 15.6 37.4 76 Thailand
6.02 Unemployment among labor force with advanced education (%) 20.7 17.0 80 Czech Republic
6.04 Unemployment in rural areas (%) 9.8 60.9 57 Peru
6.05 Ratio of female to male labour force participation rate 31.3 14.2 78 Lao PDR
6.06 Workers in vulnerable employment (%) 21.1 64.8 43 Saudi Arabia
- 45.3 50 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 43.3 37.0 48 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 24.8 37.1 51 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 54.8 85.2 13 Multiple (4)
7.05 Adjusted labour income share (%) 34.9 22.0 76 Switzerland
- 44.4 72 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 62.0 62.0 65 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.7 62.4 33 Singapore
8.03 Pay and productivity (1–7) 4.2 52.6 44 Switzerland
8.04 Employees working more than 48 hours per week (%) 29.3 41.4 63 Bulgaria
8.05 Collective bargaining coverage ratio (%) 4 3.5 64 France
- 45.2 53 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 36.9 36.9 48 Multiple (6)
9.03 Social protection spending (% of GDP) 11.2 44.8 51 Multiple (9)
9.04 Social safety net protection, 1-7 4.2 53.9 38 Norway
- 39.0 81 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 35.0 35.0 63 Denmark
10.02 Government and public services efﬁciency (score) -0.6 39.8 76 Singapore
10.03 Inclusiveness of institutions (score) -1.0 40.8 76 Portugal
10.04 Political stability and protection from violence (score) -1.2 40.5 77 New Zealand

82Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

68th
68th
72nd
74th
73rd
72nd
46th
44th
74th
60th
59th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions4759
3733415369
49
44
3951
El Salvador 68th /82
Index Component Value Score      Rank/ 82 Best Performer
- 58.8 68 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 69.5 30.5 73 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 13.5 73.0 58 Ghana
1.03 Health Access and Quality Index (0–100 best) 63.2 63.2 64 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 68.6 61 Singapore
- 37.2 72 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 54.6 54.6 54 Malta
2.02 Quality of vocational training (1–7) 3.7 44.2 67 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 27.1 9.5 66 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.4 40.4 70 GermanyEl Salvador 68th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %6.6
28.0
3,923.70.04
38.0
2.2

83El Salvador 68th /82
Index Component Value Score       Rank/ 82 Best Performer
- 33.0 74 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 27.3 25.7 67 Australia
3.03 Pupils per teacher in primary education 28.3 39.1 73 Multiple (3)
3.04 Pupils per teacher in secondary education 26.4 28.8 67 Armenia
3.05 Harmonized learning outcomes (score) 354.0 38.5 78 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 40.8 73 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.6 43.1 75 Switzerland
4.02 Active labour market policies (1–7) 1.8 13.6 82 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.4 39.6 79 Switzerland
4.04 Percentage of ﬁrms of fering formal training 53.8 71.7 8 Ecuador
4.05 Digital skills among active population (1–7) 3.2 36.0 80 Finland
- 52.9 72 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 33.8 33.8 77 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 7.7 15.3 63 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 55.8 46.5 69 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 85.0 85.0 74 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.2 36.7 78 Singapore
- 69.5 46 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.7 85.2 19 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 6.0 76.1 40 Thailand
6.02 Unemployment among labor force with advanced education (%) 5.0 80.1 48 Czech Republic
6.04 Unemployment in rural areas (%) 3.3 87.0 21 Peru
6.05 Ratio of female to male labour force participation rate 58.6 48.3 70 Lao PDR
6.06 Workers in vulnerable employment (%) 35.8 40.3 60 Saudi Arabia
- 48.7 44 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 54.4 49.4 36 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 29.2 48.0 38 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 43.5 52.9 43 Multiple (4)
7.05 Adjusted labour income share (%) 45.0 44.4 61 Switzerland
- 43.8 74 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 81.0 81.0 31 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.3 54.9 59 Singapore
8.03 Pay and productivity (1–7) 3.1 35.3 82 Switzerland
8.04 Employees working more than 48 hours per week (%) 28.7 42.6 62 Bulgaria
8.05 Collective bargaining coverage ratio (%) 5 5.0 61 France
- 38.6 60 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 11.6 46.4 50 Multiple (9)
9.04 Social safety net protection, 1-7 2.9 30.9 79 Norway
- 50.8 59 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 35.0 35.0 63 Denmark
10.02 Government and public services efﬁciency (score) -0.4 42.8 71 Singapore
10.03 Inclusiveness of institutions (score) 0.0 66.9 48 Portugal
10.04 Political stability and protection from violence (score) -0.3 58.7 58 New Zealand

84Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

23rd
28th
25th
27th
21st
8th
20th
34th
23rd
24th
21st
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7486
7577
6690
77
54666975
Estonia 23rd /82
Index Component Value Score      Rank/ 82 Best Performer
- 85.8 28 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.7 92.3 22 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.0 84.0 14 Ghana
1.03 Health Access and Quality Index (0–100 best) 85.9 85.9 30 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 80.8 38 Singapore
- 75.2 25 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 87.2 87.2 23 Malta
2.02 Quality of vocational training (1–7) 4.7 61.7 27 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 9.9 67.2 24 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 84.9 17 GermanyEstonia 23rd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %1.3
26.0
22,989.90.03
32.7
3.2

85Estonia 23rd /82
Index Component Value Score       Rank/ 82 Best Performer
- 76.5 27 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 8.8 87.4 6 Australia
3.03 Pupils per teacher in primary education 13.2 89.4 22 Multiple (3)
3.04 Pupils per teacher in secondary education 15.8 64.1 51 Armenia
3.05 Harmonized learning outcomes (score) 545.2 86.3 5 Singapore
3.06 Social diversity in schools (score) 79.5 71.3 15 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material39.3 60.7 28 Multiple (2)
- 66.1 21 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.7 62.2 25 Switzerland
4.02 Active labour market policies (1–7) 5.0 66.2 11 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.9 81.5 16 Switzerland
4.04 Percentage of ﬁrms of fering formal training 35.2 46.9 25 Ecuador
4.05 Digital skills among active population (1–7) 5.4 73.8 8 Finland
- 89.8 8 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 89.4 89.4 14 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 33.3 66.7 19 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 146.7 100.0 4 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 6.0 82.6 5 Singapore
- 77.4 20 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 10.8 56.6 54 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.8 76.8 36 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.6 85.8 27 Czech Republic
6.04 Unemployment in rural areas (%) 5.3 79.0 40 Peru
6.05 Ratio of female to male labour force participation rate 80.5 75.6 33 Lao PDR
6.06 Workers in vulnerable employment (%) 5.5 90.9 6 Saudi Arabia
- 53.9 34 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 22.1 36.9 41 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 47.7 41.9 41 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 28.5 46.2 39 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 49.7 70.6 29 Multiple (4)
7.05 Adjusted labour income share (%) 58.2 73.8 17 Switzerland
- 66.4 23 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 89.0 89.0 18 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.3 72.3 13 Singapore
8.03 Pay and productivity (1–7) 4.8 63.5 11 Switzerland
8.04 Employees working more than 48 hours per week (%) 5.6 88.8 21 Bulgaria
8.05 Collective bargaining coverage ratio (%) 19 18.6 46 France
- 69.4 24 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 41.0 54.7 16 Multiple (2)
9.02 Social protection coverage (% of population) 98.4 98.4 10 Multiple (6)
9.03 Social protection spending (% of GDP) 17.0 68.1 35 Multiple (9)
9.04 Social safety net protection, 1-7 4.4 56.2 33 Norway
- 74.7 21 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 73.0 73.0 17 Denmark
10.02 Government and public services efﬁciency (score) 1.2 77.8 22 Singapore
10.03 Inclusiveness of institutions (score) 0.1 68.7 42 Portugal
10.04 Political stability and protection from violence (score) 0.6 79.3 26 New Zealand

86Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

3rd
15th
11th
7th
4th
11th
43rd
2nd
3rd
2nd
4th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions8490
8284
7889
70858288 88
Finland 3rd/82
Index Component Value Score      Rank/ 82 Best Performer
- 90.2 15 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 5.8 94.2 15 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.9 80.1 34 Ghana
1.03 Health Access and Quality Index (0–100 best) 95.9 95.9 5 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 90.4 19 Singapore
- 82.2 11 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 83.3 83.3 29 Malta
2.02 Quality of vocational training (1–7) 5.6 76.4 5 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 8.5 71.6 18 Japan
2.04 Out-of-school children (%) 0.9 91.0 20 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 88.7 6 GermanyFinland 3rd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %5.5
253.2
49,845.00.19
27.1
1.0

87Finland 3rd/82
Index Component Value Score       Rank/ 82 Best Performer
- 83.8 7 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 1.7 97.6 8 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 9.7 84.3 13 Australia
3.03 Pupils per teacher in primary education 13.7 87.8 25 Multiple (3)
3.04 Pupils per teacher in secondary education 18.2 56.0 57 Armenia
3.05 Harmonized learning outcomes (score) 558.3 89.6 4 Singapore
3.06 Social diversity in schools (score) 87.5 90.5 2 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material19.2 80.8 9 Multiple (2)
- 78.0 4 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.5 75.3 2 Switzerland
4.02 Active labour market policies (1–7) 5.2 69.5 9 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.2 86.7 5 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.8 80.5 1 Finland
- 88.8 11 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 88.9 88.9 15 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 31.5 62.9 24 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 156.4 100.0 3 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.9 99.9 18 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.9 81.2 9 Singapore
- 70.5 43 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 17.9 28.3 73 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 8.3 66.9 56 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.2 83.3 41 Czech Republic
6.04 Unemployment in rural areas (%) 6.5 74.2 46 Peru
6.05 Ratio of female to male labour force participation rate 88.5 85.6 6 Lao PDR
6.06 Workers in vulnerable employment (%) 9.2 84.6 20 Saudi Arabia
- 85.1 2 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 7.1 79.8 7 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 95.5 95.0 3 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 44.2 85.4 4 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 58.5 95.8 5 Multiple (4)
7.05 Adjusted labour income share (%) 56.3 69.6 23 Switzerland
- 81.9 3 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 97.0 97.0 6 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.3 71.8 14 Singapore
8.03 Pay and productivity (1–7) 4.7 61.6 16 Switzerland
8.04 Employees working more than 48 hours per week (%) 5.2 89.7 17 Bulgaria
8.05 Collective bargaining coverage ratio (%) 89 89.3 7 France
- 87.9 2 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 49.0 65.3 8 Multiple (2)
9.02 Social protection coverage (% of population) 100.0 100.0 1 Multiple (6)
9.03 Social protection spending (% of GDP) 30.6 100.0 2 Multiple (9)
9.04 Social safety net protection, 1-7 6.2 86.2 2 Norway
- 87.6 4 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 85.0 85.0 3 Denmark
10.02 Government and public services efﬁciency (score) 2.0 94.7 3 Singapore
10.03 Inclusiveness of institutions (score) 0.7 84.3 4 Portugal
10.04 Political stability and protection from violence (score) 0.9 86.5 16 New Zealand

88Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

12th
8th
16th
41st
24th
21st
50th
7th
10th
8th
27th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7791
79
73
6484
68757782
74
France 12th /82
Index Component Value Score      Rank/ 82 Best Performer
- 91.3 8 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 4.7 95.3 10 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.7 82.6 20 Ghana
1.03 Health Access and Quality Index (0–100 best) 91.7 91.7 19 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 95.6 7 Singapore
- 78.5 16 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 99.5 99.5 3 Malta
2.02 Quality of vocational training (1–7) 4.7 62.1 26 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 11.1 63.1 29 Japan
2.04 Out-of-school children (%) 0.9 91.0 20 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 76.8 30 GermanyFrance 12th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %64.7
2,583.6
42,877.62.19
32.7
1.2

89France 12th /82
Index Component Value Score       Rank/ 82 Best Performer
- 72.6 41 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 6.3 91.0 31 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 21.8 44.1 60 Australia
3.03 Pupils per teacher in primary education 19.6 67.9 55 Multiple (3)
3.04 Pupils per teacher in secondary education 11.1 79.7 21 Armenia
3.05 Harmonized learning outcomes (score) 508.2 77.1 33 Singapore
3.06 Social diversity in schools (score) 76.8 64.7 24 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material16.3 83.7 6 Multiple (2)
- 64.4 24 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.8 62.8 22 Switzerland
4.02 Active labour market policies (1–7) 4.5 58.6 26 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.7 77.8 21 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.5 58.2 42 Finland
- 84.3 21 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 82.0 82.0 27 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 44.8 89.5 2 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 91.6 76.3 32 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.0 99.0 37 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.5 59.0 47 Singapore
- 68.4 50 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 16.9 32.4 70 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 9.7 61.2 62 Thailand
6.02 Unemployment among labor force with advanced education (%) 5.4 78.3 52 Czech Republic
6.04 Unemployment in rural areas (%) 7.3 70.9 47 Peru
6.05 Ratio of female to male labour force participation rate 84.1 80.1 23 Lao PDR
6.06 Workers in vulnerable employment (%) 7.4 87.6 11 Saudi Arabia
- 74.9 7 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 9.1 74.0 10 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 75.6 72.9 12 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 38.8 72.0 11 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 51.5 75.6 23 Multiple (4)
7.05 Adjusted labour income share (%) 61.0 80.0 8 Switzerland
- 76.6 10 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 91.0 91.0 12 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.2 54.1 62 Singapore
8.03 Pay and productivity (1–7) 4.1 52.0 46 Switzerland
8.04 Employees working more than 48 hours per week (%) 6.5 87.1 25 Bulgaria
8.05 Collective bargaining coverage ratio (%) 99 98.5 1 France
- 82.2 8 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 39.0 52.0 18 Multiple (2)
9.02 Social protection coverage (% of population) 100.0 100.0 1 Multiple (6)
9.03 Social protection spending (% of GDP) 31.7 100.0 1 Multiple (9)
9.04 Social safety net protection, 1-7 5.6 76.7 13 Norway
- 73.7 27 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 72.0 72.0 20 Denmark
10.02 Government and public services efﬁciency (score) 1.5 84.0 15 Singapore
10.03 Inclusiveness of institutions (score) 0.1 70.2 39 Portugal
10.04 Political stability and protection from violence (score) 0.1 68.5 43 New Zealand

90Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

53rd
57th
53rd
15th
81st
57th
71st
48th
49th
67th
44th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5668
5880
3766
504757
3360
Georgia 53rd /82
Index Component Value Score      Rank/ 82 Best Performer
- 67.6 57 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 46.4 53.6 59 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.3 81.5 27 Ghana
1.03 Health Access and Quality Index (0–100 best) 67.1 67.1 60 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 68.4 62 Singapore
- 57.7 53 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 3.1 34.9 82 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 24.8 17.5 62 Japan
2.04 Out-of-school children (%) 0.4 96.0 13 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 82.6 22 GermanyGeorgia 53rd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %3.7
15.1
4,400.40.03
37.9
4.2