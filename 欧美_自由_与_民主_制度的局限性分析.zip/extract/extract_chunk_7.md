181Sri Lanka 59th /82
Index Component Value Score       Rank/ 82 Best Performer
- 66.1 46 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 14.0 80.0 38 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 13.8 70.6 33 Australia
3.03 Pupils per teacher in primary education 22.9 56.9 63 Multiple (3)
3.04 Pupils per teacher in secondary education 17.9 57.1 55 Armenia
3.05 Harmonized learning outcomes (score) n/a n/a n/a Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 49.1 49 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.9 48.2 55 Switzerland
4.02 Active labour market policies (1–7) 3.6 43.6 47 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.1 51.0 65 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.2 53.8 53 Finland
- 53.5 71 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 34.1 34.1 76 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 7.2 14.4 65 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 58.8 49.0 67 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 91.0 91.0 70 Multiple (13)
5.05 Rural population with electricity access (%) 97.0 97.0 68 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.1 35.3 79 Singapore
- 64.8 56 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 3.1 87.8 13 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 7.1 71.8 47 Thailand
6.02 Unemployment among labor force with advanced education (%) 6.2 75.1 56 Czech Republic
6.04 Unemployment in rural areas (%) 4.3 82.8 30 Peru
6.05 Ratio of female to male labour force participation rate 48.4 35.5 73 Lao PDR
6.06 Workers in vulnerable employment (%) 38.5 35.9 62 Saudi Arabia
- 32.7 66 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 32.0 24.4 60 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 19.9 24.7 65 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 44.2 54.9 40 Multiple (4)
7.05 Adjusted labour income share (%) 37.1 26.9 72 Switzerland
- 44.1 73 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 70.0 70.0 50 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.5 58.8 44 Singapore
8.03 Pay and productivity (1–7) 4.0 49.4 52 Switzerland
8.04 Employees working more than 48 hours per week (%) 31.3 37.5 67 Bulgaria
8.05 Collective bargaining coverage ratio (%) 5 4.8 62 France
- 35.4 65 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 30.4 30.4 50 Multiple (6)
9.03 Social protection spending (% of GDP) 6.5 26.0 60 Multiple (9)
9.04 Social safety net protection, 1-7 4.0 49.8 49 Norway
- 49.1 66 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 38.0 38.0 56 Denmark
10.02 Government and public services efﬁciency (score) -0.2 47.3 65 Singapore
10.03 Inclusiveness of institutions (score) -0.7 49.0 69 Portugal
10.04 Political stability and protection from violence (score) -0.2 62.1 53 New Zealand

182Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
4th 4th 6th 1st 2nd 4th 31st 10th 1st 7th 7th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions8492
8587
7892
75 74848286
Sweden 4th/82
Index Component Value Score      Rank/ 82 Best Performer
- 92.1 4 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 5.1 94.9 12 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 8.0 84.0 15 Ghana
1.03 Health Access and Quality Index (0–100 best) 95.5 95.5 8 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 94.0 10 Singapore
- 84.6 6 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 95.8 95.8 6 Malta
2.02 Quality of vocational training (1–7) 4.9 64.6 19 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 6.1 79.6 10 Japan
2.04 Out-of-school children (%) 0.4 96.0 13 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 87.0 12 GermanySweden 4th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %10.2
538.6
53,873.40.40
29.2
2.3

183Sweden 4th/82
Index Component Value Score       Rank/ 82 Best Performer
- 87.4 1 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 1.9 97.3 9 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 6.3 95.6 4 Australia
3.03 Pupils per teacher in primary education 12.8 90.6 18 Multiple (3)
3.04 Pupils per teacher in secondary education 13.7 71.0 45 Armenia
3.05 Harmonized learning outcomes (score) 531.1 82.8 15 Singapore
3.06 Social diversity in schools (score) 85.6 86.0 4 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material11.6 88.4 4 Multiple (2)
- 78.3 2 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.2 70.7 10 Switzerland
4.02 Active labour market policies (1–7) 4.6 60.8 23 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.3 88.3 3 Switzerland
4.04 Percentage of ﬁrms of fering formal training 70.3 93.7 2 Ecuador
4.05 Digital skills among active population (1–7) 5.7 77.8 3 Finland
- 92.2 4 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 92.1 92.1 9 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 39.1 78.3 12 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 123.0 100.0 12 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 6.0 82.9 2 Singapore
- 74.7 31 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 18.5 25.9 74 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.5 81.9 22 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.6 85.7 28 Czech Republic
6.04 Unemployment in rural areas (%) 5.8 77.0 42 Peru
6.05 Ratio of female to male labour force participation rate 90.5 88.2 2 Lao PDR
6.06 Workers in vulnerable employment (%) 6.2 89.6 10 Saudi Arabia
- 74.0 10 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 3.0 91.4 5 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 65.0 61.1 23 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 35.9 64.8 20 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 54.8 85.0 14 Multiple (4)
7.05 Adjusted labour income share (%) 55.4 67.6 26 Switzerland
- 83.6 1 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 100.0 100.0 1 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.7 77.7 7 Singapore
8.03 Pay and productivity (1–7) 4.5 58.9 27 Switzerland
8.04 Employees working more than 48 hours per week (%) 4.3 91.5 11 Bulgaria
8.05 Collective bargaining coverage ratio (%) 90 90.0 6 France
- 82.3 7 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 38.0 50.7 20 Multiple (2)
9.02 Social protection coverage (% of population) 100.0 100.0 1 Multiple (6)
9.03 Social protection spending (% of GDP) 26.7 100.0 7 Multiple (9)
9.04 Social safety net protection, 1-7 5.7 78.7 10 Norway
- 86.1 7 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 85.0 85.0 3 Denmark
10.02 Government and public services efﬁciency (score) 1.8 91.4 7 Singapore
10.03 Inclusiveness of institutions (score) 0.6 81.7 8 Portugal
10.04 Political stability and protection from violence (score) 0.9 86.2 18 New Zealand

184Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

7th
2nd
9th
20th
1st
5th
10th
13th
9th
15th
3rd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions8294
84
778190
81
7077 7888
Switzerland 7th/82
Index Component Value Score      Rank/ 82 Best Performer
- 94.2 2 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 2.8 97.2 2 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 6.2 87.6 10 Ghana
1.03 Health Access and Quality Index (0–100 best) 95.6 95.6 7 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 96.4 5 Singapore
- 83.5 9 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 75.9 75.9 34 Malta
2.02 Quality of vocational training (1–7) 6.4 90.8 1 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 6.0 79.9 9 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 87.6 11 GermanySwitzerland 7th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %8.5
678.6
82,950.30.41
32.3
1.7

185Switzerland 7th/82
Index Component Value Score       Rank/ 82 Best Performer
- 77.4 20 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 15.7 64.5 43 Australia
3.03 Pupils per teacher in primary education 15.3 82.3 33 Multiple (3)
3.04 Pupils per teacher in secondary education 11.2 79.4 23 Armenia
3.05 Harmonized learning outcomes (score) 524.6 81.2 18 Singapore
3.06 Social diversity in schools (score) 82.3 77.9 10 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material21.0 79.0 11 Multiple (2)
- 81.1 1 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.7 79.0 1 Switzerland
4.02 Active labour market policies (1–7) 5.8 79.2 1 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.5 91.8 1 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.5 74.4 7 Finland
- 90.4 5 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 89.7 89.7 13 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 46.3 92.7 1 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 98.2 81.9 25 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 100.0 100.0 1 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.7 78.4 14 Singapore
- 81.3 10 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 8.2 67.3 36 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.7 81.2 25 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.5 86.1 26 Czech Republic
6.04 Unemployment in rural areas (%) 3.2 87.0 20 Peru
6.05 Ratio of female to male labour force participation rate 84.8 81.0 16 Lao PDR
6.06 Workers in vulnerable employment (%) 9.0 85.1 19 Saudi Arabia
- 69.7 13 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 10.2 71.0 11 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 56.4 51.6 30 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 31.2 52.9 31 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 50.6 73.2 25 Multiple (4)
7.05 Adjusted labour income share (%) 70.7 100.0 1 Switzerland
- 77.2 9 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 89.0 89.0 18 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 6.1 85.2 2 Singapore
8.03 Pay and productivity (1–7) 5.5 74.6 1 Switzerland
8.04 Employees working more than 48 hours per week (%) 10.3 79.5 37 Bulgaria
8.05 Collective bargaining coverage ratio (%) 58 57.9 21 France
- 77.6 15 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 41.0 54.7 16 Multiple (2)
9.02 Social protection coverage (% of population) 92.7 92.7 17 Multiple (6)
9.03 Social protection spending (% of GDP) 19.6 78.4 24 Multiple (9)
9.04 Social safety net protection, 1-7 6.1 84.6 5 Norway
- 88.2 3 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 85.0 85.0 3 Denmark
10.02 Government and public services efﬁciency (score) 2.0 95.9 2 Singapore
10.03 Inclusiveness of institutions (score) 0.4 76.2 22 Portugal
10.04 Political stability and protection from violence (score) 1.3 95.7 5 New Zealand

186Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

55th
58th
51st
62nd
54th
46th
14th
38th
60th
69th
69th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5567
59
44487280
52 52
3248
Thailand 55th /82
Index Component Value Score      Rank/ 82 Best Performer
- 66.8 58 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 44.9 55.1 58 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 19.1 61.7 74 Ghana
1.03 Health Access and Quality Index (0–100 best) 69.5 69.5 52 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 80.7 39 Singapore
- 58.6 51 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 53.2 53.2 55 Malta
2.02 Quality of vocational training (1–7) 4.1 51.6 52 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 14.8 50.7 41 Japan
2.04 Out-of-school children (%) 2.0 80.0 34 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 57.3 61 GermanyThailand 55th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %67.8
455.4
7,187.20.98
36.5
3.3

187Thailand 55th /82
Index Component Value Score       Rank/ 82 Best Performer
- 44.4 62 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 21.9 68.7 43 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 16.2 79.3 37 Multiple (3)
3.04 Pupils per teacher in secondary education 31.2 12.6 72 Armenia
3.05 Harmonized learning outcomes (score) 443.9 61.0 53 Singapore
3.06 Social diversity in schools (score) 62.1 29.3 56 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material84.3 15.7 61 Multiple (2)
- 47.7 54 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.3 55.1 36 Switzerland
4.02 Active labour market policies (1–7) 3.8 46.3 41 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.5 58.7 44 Switzerland
4.04 Percentage of ﬁrms of fering formal training 18.0 24.0 41 Ecuador
4.05 Digital skills among active population (1–7) 4.3 54.3 51 Finland
- 71.6 46 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 56.8 56.8 66 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 13.2 26.5 55 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 104.7 87.2 19 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.0 98.0 48 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.7 61.2 37 Singapore
- 79.7 14 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 0.6 97.4 1 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 1.1 95.6 1 Thailand
6.02 Unemployment among labor force with advanced education (%) 1.6 93.7 3 Czech Republic
6.04 Unemployment in rural areas (%) 0.7 97.1 3 Peru
6.05 Ratio of female to male labour force participation rate 78.0 72.5 39 Lao PDR
6.06 Workers in vulnerable employment (%) 46.9 21.8 69 Saudi Arabia
- 52.0 38 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 0.0 99.9 2 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 30.3 22.6 63 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 20.4 26.0 63 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 45.9 59.8 36 Multiple (4)
7.05 Adjusted labour income share (%) 48.2 51.6 52 Switzerland
- 52.3 60 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 62.0 62.0 65 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.9 64.9 28 Singapore
8.03 Pay and productivity (1–7) 4.6 60.1 23 Switzerland
8.04 Employees working more than 48 hours per week (%) 14.2 71.5 45 Bulgaria
8.05 Collective bargaining coverage ratio (%) 3 3.1 65 France
- 32.5 69 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 3.7 14.8 72 Multiple (9)
9.04 Social safety net protection, 1-7 4.0 50.1 47 Norway
- 48.1 69 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 36.0 36.0 59 Denmark
10.02 Government and public services efﬁciency (score) 0.3 59.8 43 Singapore
10.03 Inclusiveness of institutions (score) -0.7 46.7 72 Portugal
10.04 Political stability and protection from violence (score) -0.7 50.0 69 New Zealand

188Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

62nd
41st
46th
60th
70th
59th
78th
54th
61st
58th
57th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5277
61
49
4264
374252
4051
Tunisia 62nd /82
Index Component Value Score      Rank/ 82 Best Performer
- 77.0 41 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 7.8 92.2 24 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 15.0 70.1 64 Ghana
1.03 Health Access and Quality Index (0–100 best) 69.4 69.4 53 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 76.2 48 Singapore
- 61.2 46 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 3.7 44.6 66 Switzerland
2.03 NEET ratio (% of 15–24 year olds) n/a n/a n/a Japan
2.04 Out-of-school children (%) 0.4 96.0 13 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.4 43.1 69 GermanyTunisia 62nd  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %11.7
40.3
3,423.20.11
32.8
1.8

189Tunisia 62nd /82
Index Component Value Score       Rank/ 82 Best Performer
- 49.1 60 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 65.1 7.0 63 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 15.2 65.9 40 Australia
3.03 Pupils per teacher in primary education 16.9 77.1 43 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 386.3 46.6 68 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 42.3 70 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.7 45.5 63 Switzerland
4.02 Active labour market policies (1–7) 2.8 30.7 65 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 3.6 42.7 77 Switzerland
4.04 Percentage of ﬁrms of fering formal training 28.9 38.5 30 Ecuador
4.05 Digital skills among active population (1–7) 4.2 53.9 52 Finland
- 64.3 59 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 64.2 64.2 59 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 8.8 17.5 61 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 76.1 63.4 50 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.0 99.0 37 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.5 41.9 71 Singapore
- 37.3 78 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.9 60.4 51 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 16.2 35.0 77 Thailand
6.02 Unemployment among labor force with advanced education (%) 30.2 0.0 81 Czech Republic
6.04 Unemployment in rural areas (%) 13.9 44.5 63 Peru
6.05 Ratio of female to male labour force participation rate 34.3 17.9 77 Lao PDR
6.06 Workers in vulnerable employment (%) 20.5 65.8 42 Saudi Arabia
- 42.0 54 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 29.9 22.1 66 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 20.9 27.2 62 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 50.3 72.3 27 Multiple (4)
7.05 Adjusted labour income share (%) 45.9 46.4 60 Switzerland
- 52.3 61 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 72.0 72.0 47 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.7 44.2 77 Singapore
8.03 Pay and productivity (1–7) 3.2 36.1 80 Switzerland
8.04 Employees working more than 48 hours per week (%) n/a n/a n/a Bulgaria
8.05 Collective bargaining coverage ratio (%) 57 56.9 22 France
- 40.2 58 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 10.4 41.6 53 Multiple (9)
9.04 Social safety net protection, 1-7 3.3 38.8 67 Norway
- 51.0 57 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 43.0 43.0 46 Denmark
10.02 Government and public services efﬁciency (score) -0.1 50.1 61 Singapore
10.03 Inclusiveness of institutions (score) -0.1 64.8 52 Portugal
10.04 Political stability and protection from violence (score) -0.9 46.2 71 New Zealand

190Key Upper-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
64th 46th 69th 45th 58th 53rd 73rd 45th 80th 64th 75th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5173
4066
4768
5048
403644
Turkey 64th /82
Index Component Value Score      Rank/ 82 Best Performer
- 73.4 46 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 26.6 73.4 50 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 16.4 67.2 70 Ghana
1.03 Health Access and Quality Index (0–100 best) 74.4 74.4 47 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 78.8 41 Singapore
- 39.6 69 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 32.7 32.7 63 Malta
2.02 Quality of vocational training (1–7) 3.2 36.9 79 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 24.4 18.6 61 Japan
2.04 Out-of-school children (%) 5.0 50.0 55 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.6 59.5 58 GermanyTurkey 64th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %82.0
849.5
9,346.21.70
41.9
5.5

191Turkey 64th /82
Index Component Value Score       Rank/ 82 Best Performer
- 66.4 45 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 17.6 74.9 41 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 17.2 59.3 46 Australia
3.03 Pupils per teacher in primary education 17.0 76.7 46 Multiple (3)
3.04 Pupils per teacher in secondary education 12.9 73.7 33 Armenia
3.05 Harmonized learning outcomes (score) 463.2 65.8 46 Singapore
3.06 Social diversity in schools (score) 67.2 41.4 45 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material27.0 73.0 19 Multiple (2)
- 46.5 58 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.5 41.3 78 Switzerland
4.02 Active labour market policies (1–7) 3.8 46.1 43 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.7 62.3 36 Switzerland
4.04 Percentage of ﬁrms of fering formal training 30.7 40.9 29 Ecuador
4.05 Digital skills among active population (1–7) 3.5 42.1 75 Finland
- 68.0 53 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 71.0 71.0 48 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 16.3 32.6 48 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 74.2 61.8 54 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 98.3 98.3 46 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 3.7 44.5 67 Singapore
- 50.1 73 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.7 61.3 50 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 12.1 51.4 70 Thailand
6.02 Unemployment among labor force with advanced education (%) 12.2 51.2 71 Czech Republic
6.04 Unemployment in rural areas (%) n/a n/a n/a Peru
6.05 Ratio of female to male labour force participation rate 46.2 32.8 75 Lao PDR
6.06 Workers in vulnerable employment (%) 27.8 53.6 55 Saudi Arabia
- 47.9 45 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 0.8 97.8 4 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 43.4 37.1 47 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 25.8 39.4 47 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 39.1 40.3 51 Multiple (4)
7.05 Adjusted labour income share (%) 36.2 24.9 75 Switzerland
- 40.1 80 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 61.0 61.0 70 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.8 47.3 74 Singapore
8.03 Pay and productivity (1–7) 3.6 43.7 66 Switzerland
8.04 Employees working more than 48 hours per week (%) 29.4 41.3 64 Bulgaria
8.05 Collective bargaining coverage ratio (%) 7 7.0 60 France
- 36.5 64 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 0.0 0.0 39 Multiple (2)
9.02 Social protection coverage (% of population) n/a n/a n/a Multiple (6)
9.03 Social protection spending (% of GDP) 13.5 54.0 47 Multiple (9)
9.04 Social safety net protection, 1-7 4.3 55.5 34 Norway
- 44.1 75 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 41.0 41.0 50 Denmark
10.02 Government and public services efﬁciency (score) 0.0 52.5 55 Singapore
10.03 Inclusiveness of institutions (score) -0.8 46.2 73 Portugal
10.04 Political stability and protection from violence (score) -1.3 36.8 78 New Zealand

192Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL
46th 47th 52nd 47th 55th 64th 38th 20th 42nd 23rd 79th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions6173
5866
476272
64
5970
41
Ukraine 46th /82
Index Component Value Score      Rank/ 82 Best Performer
- 73.3 47 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 23.7 76.3 47 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 9.2 81.7 26 Ghana
1.03 Health Access and Quality Index (0–100 best) 74.6 74.6 46 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 60.7 70 Singapore
- 58.4 52 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) n/a n/a n/a Malta
2.02 Quality of vocational training (1–7) 4.2 53.4 49 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 16.5 45.1 46 Japan
2.04 Out-of-school children (%) n/a n/a n/a Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.8 76.6 31 GermanyUkraine 46th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %42.0
109.3
2,963.50.29
25.0
0.1

193Ukraine 46th /82
Index Component Value Score       Rank/ 82 Best Performer
- 65.5 47 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) n/a n/a n/a Korea, Rep.
3.02 Pupils per teacher in pre-primary education 9.3 85.5 8 Australia
3.03 Pupils per teacher in primary education 13.0 90.1 20 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 488.3 72.1 41 Singapore
3.06 Social diversity in schools (score) 75.2 60.9 32 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material80.8 19.2 60 Multiple (2)
- 47.2 55 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.0 50.4 47 Switzerland
4.02 Active labour market policies (1–7) 3.8 46.5 40 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.1 51.5 63 Switzerland
4.04 Percentage of ﬁrms of fering formal training 22.6 30.1 35 Ecuador
4.05 Digital skills among active population (1–7) 4.5 57.5 44 Finland
- 61.6 64 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 58.9 58.9 63 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 12.3 24.6 57 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 45.2 37.7 74 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 90.0 90.0 72 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.5 58.5 48 Singapore
- 71.9 38 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 1.1 95.7 2 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 9.9 60.5 63 Thailand
6.02 Unemployment among labor force with advanced education (%) 7.7 69.2 64 Czech Republic
6.04 Unemployment in rural areas (%) 9.2 63.2 53 Peru
6.05 Ratio of female to male labour force participation rate 74.2 67.7 48 Lao PDR
6.06 Workers in vulnerable employment (%) 14.8 75.3 38 Saudi Arabia
- 63.8 20 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) n/a n/a n/a Philippines
7.02 Ratio of bottom 40% to top10% labour income share 62.3 58.1 25 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 33.0 57.4 26 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 61.2 100.0 1 Multiple (4)
7.05 Adjusted labour income share (%) 42.8 39.6 64 Switzerland
- 59.5 42 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 64.0 64.0 57 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.3 54.8 60 Singapore
8.03 Pay and productivity (1–7) 4.3 55.6 35 Switzerland
8.04 Employees working more than 48 hours per week (%) 11.5 77.0 40 Bulgaria
8.05 Collective bargaining coverage ratio (%) 46 45.9 28 France
- 69.6 23 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 73.0 73.0 32 Multiple (6)
9.03 Social protection spending (% of GDP) 22.2 88.9 18 Multiple (9)
9.04 Social safety net protection, 1-7 3.8 46.8 54 Norway
- 40.7 79 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 32.0 32.0 73 Denmark
10.02 Government and public services efﬁciency (score) -0.4 43.5 70 Singapore
10.03 Inclusiveness of institutions (score) -0.2 61.6 56 Portugal
10.04 Political stability and protection from violence (score) -1.8 25.9 80 New Zealand

194Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

21st
27th
10th
44th
20th
13th
9th
36th
30th
12th
23rd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions748683
696689
82
536379
74
United Kingdom 21st /82
Index Component Value Score      Rank/ 82 Best Performer
- 85.8 27 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 13.4 86.6 36 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 10.8 78.3 41 Ghana
1.03 Health Access and Quality Index (0–100 best) 90.5 90.5 22 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 87.9 26 Singapore
- 82.5 10 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 96.6 96.6 5 Malta
2.02 Quality of vocational training (1–7) 4.9 64.7 18 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 10.4 65.2 27 Japan
2.04 Out-of-school children (%) 0.2 98.0 7 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 88.0 8 GermanyUnited Kingdom 21st  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %66.5
2,624.5
42,558.02.25
33.2
1.7

195United Kingdom 21st /82
Index Component Value Score       Rank/ 82 Best Performer
- 69.1 44 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 3.2 95.4 21 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 24.8 34.1 63 Australia
3.03 Pupils per teacher in primary education 16.9 77.0 44 Multiple (3)
3.04 Pupils per teacher in secondary education 17.2 59.5 53 Armenia
3.05 Harmonized learning outcomes (score) 518.2 79.6 27 Singapore
3.06 Social diversity in schools (score) 76.6 64.2 26 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material26.3 73.7 18 Multiple (2)
- 66.2 20 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.8 62.7 23 Switzerland
4.02 Active labour market policies (1–7) 4.3 55.1 30 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.9 81.5 17 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 4.9 65.6 22 Finland
- 88.6 13 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 94.9 94.9 6 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 39.6 79.2 10 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 96.9 80.7 27 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.7 99.7 24 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.6 77.2 16 Singapore
- 81.8 9 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 7.2 71.3 35 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 4.6 81.5 23 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.5 90.0 14 Czech Republic
6.04 Unemployment in rural areas (%) 2.8 88.7 17 Peru
6.05 Ratio of female to male labour force participation rate 84.4 80.5 21 Lao PDR
6.06 Workers in vulnerable employment (%) 12.9 78.6 36 Saudi Arabia
- 53.1 36 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 19.3 44.9 32 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 45.0 38.8 44 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 27.2 43.0 43 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 47.8 65.2 31 Multiple (4)
7.05 Adjusted labour income share (%) 58.0 73.3 20 Switzerland
- 62.9 30 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 80.0 80.0 32 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.0 66.1 25 Singapore
8.03 Pay and productivity (1–7) 4.7 62.2 15 Switzerland
8.04 Employees working more than 48 hours per week (%) 10.2 79.7 36 Bulgaria
8.05 Collective bargaining coverage ratio (%) 26 26.3 38 France
- 79.4 12 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 56.0 74.7 5 Multiple (2)
9.02 Social protection coverage (% of population) 93.5 93.5 16 Multiple (6)
9.03 Social protection spending (% of GDP) 21.5 86.0 21 Multiple (9)
9.04 Social safety net protection, 1-7 4.8 63.4 27 Norway
- 74.3 23 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 80.0 80.0 11 Denmark
10.02 Government and public services efﬁciency (score) 1.3 81.0 19 Singapore
10.03 Inclusiveness of institutions (score) 0.1 68.9 41 Portugal
10.04 Political stability and protection from violence (score) 0.0 67.2 46 New Zealand

196Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

27th
42nd
40th
25th
10th
6th
4th
53rd
43rd
35th
26th
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions7076
67777390
83
44596274
United States 27th /82
Index Component Value Score      Rank/ 82 Best Performer
- 75.8 42 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 19.9 80.1 42 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 22.1 55.8 79 Ghana
1.03 Health Access and Quality Index (0–100 best) 88.7 88.7 28 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 78.4 42 Singapore
- 66.8 40 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 64.6 64.6 48 Malta
2.02 Quality of vocational training (1–7) 5.2 70.7 8 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 13.7 54.5 37 Japan
2.04 Out-of-school children (%) 4.1 59.0 51 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.9 85.3 16 GermanyUnited States 27th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %327.4
19,390.6
62,605.615.16
41.5
2.0

197United States 27th /82
Index Component Value Score       Rank/ 82 Best Performer
- 76.8 25 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 3.9 94.4 24 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 13.0 73.4 29 Australia
3.03 Pupils per teacher in primary education 15.2 82.7 32 Multiple (3)
3.04 Pupils per teacher in secondary education 15.4 65.2 50 Armenia
3.05 Harmonized learning outcomes (score) 523.4 80.8 22 Singapore
3.06 Social diversity in schools (score) 74.2 58.4 36 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material17.6 82.4 8 Multiple (2)
- 73.3 10 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 5.3 72.3 6 Switzerland
4.02 Active labour market policies (1–7) 4.9 65.7 12 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 6.0 83.0 11 Switzerland
4.04 Percentage of ﬁrms of fering formal training n/a n/a n/a Ecuador
4.05 Digital skills among active population (1–7) 5.3 72.2 11 Finland
- 90.2 6 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 87.3 87.3 19 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 35.6 71.2 17 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 142.5 100.0 6 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.9 99.9 18 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 6.0 82.9 3 Singapore
- 83.0 4 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 6.6 73.8 31 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 5.2 79.3 27 Thailand
6.02 Unemployment among labor force with advanced education (%) 2.5 90.2 12 Czech Republic
6.04 Unemployment in rural areas (%) 4.2 83.2 29 Peru
6.05 Ratio of female to male labour force participation rate 82.1 77.6 28 Lao PDR
6.06 Workers in vulnerable employment (%) 3.7 93.8 2 Saudi Arabia
- 43.8 53 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 24.9 28.8 48 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 42.9 36.5 50 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 26.4 41.1 46 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 38.2 37.8 52 Multiple (4)
7.05 Adjusted labour income share (%) 58.6 74.7 14 Switzerland
- 59.1 43 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 69.0 69.0 52 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 5.2 70.6 15 Singapore
8.03 Pay and productivity (1–7) 5.3 71.1 3 Switzerland
8.04 Employees working more than 48 hours per week (%) 13.5 73.0 44 Bulgaria
8.05 Collective bargaining coverage ratio (%) 12 11.5 55 France
- 61.7 35 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) 20.0 26.7 34 Multiple (2)
9.02 Social protection coverage (% of population) 76.1 76.1 30 Multiple (6)
9.03 Social protection spending (% of GDP) 19.0 75.8 28 Multiple (9)
9.04 Social safety net protection, 1-7 5.1 68.2 21 Norway
- 73.7 26 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 71.0 71.0 21 Denmark
10.02 Government and public services efﬁciency (score) 1.6 86.0 14 Singapore
10.03 Inclusiveness of institutions (score) -0.2 61.2 57 Portugal
10.04 Political stability and protection from violence (score) 0.5 76.6 31 New Zealand

198Key High-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

35th
61st
30th
54th
33rd
25th
37th
55th
20th
14th
22nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions676571
59 5883
73
42677875
Uruguay 35th /82
Index Component Value Score      Rank/ 82 Best Performer
- 64.7 61 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 58.7 41.3 65 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 15.3 69.3 65 Ghana
1.03 Health Access and Quality Index (0–100 best) 71.0 71.0 49 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 77.4 45 Singapore
- 71.2 30 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 93.3 93.3 12 Malta
2.02 Quality of vocational training (1–7) 4.6 59.6 31 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 18.0 40.2 51 Japan
2.04 Out-of-school children (%) 0.5 95.0 16 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.7 67.9 47 GermanyUruguay 35th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %3.5
58.4
17,164.90.06
39.5
3.0

199Uruguay 35th /82
Index Component Value Score       Rank/ 82 Best Performer
- 59.4 54 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 41.4 40.9 50 Korea, Rep.
3.02 Pupils per teacher in pre-primary education n/a n/a n/a Australia
3.03 Pupils per teacher in primary education 11.0 96.6 8 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 444.3 61.1 52 Singapore
3.06 Social diversity in schools (score) 64.2 34.4 48 Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education material35.8 64.2 24 Multiple (2)
- 57.9 33 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 3.9 47.8 57 Switzerland
4.02 Active labour market policies (1–7) 4.0 49.3 36 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 5.0 66.9 31 Switzerland
4.04 Percentage of ﬁrms of fering formal training 53.3 71.1 9 Ecuador
4.05 Digital skills among active population (1–7) 4.3 54.4 50 Finland
- 82.5 25 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 68.3 68.3 51 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 28.3 56.7 31 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 123.8 100.0 11 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 91.0 91.0 70 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 5.7 79.2 12 Singapore
- 73.1 37 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 9.4 62.4 44 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 6.2 75.3 41 Thailand
6.02 Unemployment among labor force with advanced education (%) 3.0 88.0 19 Czech Republic
6.04 Unemployment in rural areas (%) 4.3 82.8 31 Peru
6.05 Ratio of female to male labour force participation rate 75.8 69.7 43 Lao PDR
6.06 Workers in vulnerable employment (%) 23.8 60.3 47 Saudi Arabia
- 41.9 55 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 22.3 36.3 43 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 43.4 37.2 46 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 26.6 41.5 45 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 41.2 46.2 49 Multiple (4)
7.05 Adjusted labour income share (%) 46.7 48.2 57 Switzerland
- 67.5 20 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 99.0 99.0 3 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 3.2 37.4 81 Singapore
8.03 Pay and productivity (1–7) 3.3 38.9 78 Switzerland
8.04 Employees working more than 48 hours per week (%) n/a n/a n/a Bulgaria
8.05 Collective bargaining coverage ratio (%) 95 94.6 4 France
- 77.9 14 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 94.5 94.5 15 Multiple (6)
9.03 Social protection spending (% of GDP) 17.0 67.9 36 Multiple (9)
9.04 Social safety net protection, 1-7 5.3 71.4 18 Norway
- 74.5 22 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 70.0 70.0 22 Denmark
10.02 Government and public services efﬁciency (score) 0.6 64.3 37 Singapore
10.03 Inclusiveness of institutions (score) 0.3 74.8 31 Portugal
10.04 Political stability and protection from violence (score) 1.0 89.1 10 New Zealand

200Key Lower-middle-income  group average Performance Overview 2020
Best
Rank /82Score0102030405060708090100Overall
Score Health Education Technology WorkResilience &
Institutions
DNK CYP NLD SWE CHE DNK ISL BEL SWE DNK NZL

50th
60th
39th
28th
71st
54th
25th
62nd
57th
63rd
52nd
Overall Health Education
AccessEducation
Quality
and
EquityLifelong
LearningTechnology
AccessWork
Oppor tunitiesFair
Wage
DistributionWorking
ConditionsSocial
ProtectionInclusive
Institutions5867 6776
426876
3653
3756
Viet Nam 50th /82
Index Component Value Score      Rank/ 82 Best Performer
- 66.5 60 Cyprus Pillar 1: Health (0–100 best)
1.01 Adolescent birth rate per 1,000 women 30.9 69.1 52 Korea, Rep.
1.02 Prevalence of malnourishment (% of 5-19 year olds) 16.8 66.5 72 Ghana
1.03 Health Access and Quality Index (0–100 best) 60.3 60.3 66 Iceland
1.04 Inequality-adjusted healthy life expectancy index (0–100 best) - 70.3 60 Singapore
- 67.1 39 Netherlands Pillar 2: Education Access (0–100 best)
2.01 Pre-primary enrolment (%) 78.5 78.5 32 Malta
2.02 Quality of vocational training (1–7) 3.6 44.0 68 Switzerland
2.03 NEET ratio (% of 15–24 year olds) 9.7 67.7 23 Japan
2.04 Out-of-school children (%) 0.6 94.0 17 Multiple (5)
2.05 Inequality-adjusted education index (0–100 best) 0.5 51.5 68 GermanyViet Nam 50th  / 82
Social Mobility Index 2020 edition
Selected contextual indicators
Population millions
GDP US$ billions
GDP per capita US$GDP (PPP) % world GDP
Income Gini 0 (perfect equality) -100 (perfect inequality)
10-year average annual GDP growth %94.6
220.4
2,551.10.53
35.3
5.4

201Viet Nam 50th /82
Index Component Value Score       Rank/ 82 Best Performer
- 76.1 28 Sweden Pillar 3: Education Quality and Equity (0–100 best)
3.01 Children below minimum proﬁciency (%) 1.1 98.4 6 Korea, Rep.
3.02 Pupils per teacher in pre-primary education 17.3 59.1 47 Australia
3.03 Pupils per teacher in primary education 20.3 65.7 59 Multiple (3)
3.04 Pupils per teacher in secondary education n/a n/a n/a Armenia
3.05 Harmonized learning outcomes (score) 524.2 81.0 19 Singapore
3.06 Social diversity in schools (score) n/a n/a n/a Norway
3.07 Percentage of disadvantaged students in schools which report a lack of
education materialn/a n/a n/a Multiple (2)
- 42.2 71 Switzerland Pillar 4: Lifelong Learning (0–100 best)
4.01 Extent of staf f training (1–7) 4.0 49.4 51 Switzerland
4.02 Active labour market policies (1–7) 3.2 36.0 56 Switzerland
4.03 Impact of ICT s on access to basic services, 1-7 4.0 49.7 68 Switzerland
4.04 Percentage of ﬁrms of fering formal training 22.2 29.6 36 Ecuador
4.05 Digital skills among active population (1–7) 3.8 46.1 68 Finland
- 68.0 54 Denmark Pillar 5: T echnology Access (0–100 best)
5.01 Internet users (% of adult population) 70.3 70.3 50 Iceland
5.02 Fixed-broadband internet subscriptions (per 100 pop.) 13.6 27.2 52 Switzerland
5.03 Mobile-broadband subscriptions (per 100 pop.) 71.9 59.9 57 Multiple (12)
5.04 Population covered by at least a 3G mobile network (%) 99.6 99.6 27 Multiple (13)
5.05 Rural population with electricity access (%) 100.0 100.0 1 Multiple (63)
5.06 Internet access in schools, 1–7 (best) 4.1 51.0 57 Singapore
- 75.9 25 Iceland Pillar 6: W ork Opportunities (0–100 best)
6.01 Unemployment among labor force with basic education (%) 1.5 94.1 4 Thailand
6.03 Unemployment among labor forcet with intermediate education (%) 2.9 88.4 5 Thailand
6.02 Unemployment among labor force with advanced education (%) 4.1 83.7 38 Czech Republic
6.04 Unemployment in rural areas (%) 1.5 93.9 5 Peru
6.05 Ratio of female to male labour force participation rate 88.1 85.2 7 Lao PDR
6.06 Workers in vulnerable employment (%) 54.0 10.0 73 Saudi Arabia
- 36.4 62 Belgium Pillar 7: Fair W age Distribution (0–100 best)
7.01 Low pay incidence (% of workers) 17.1 51.1 28 Philippines
7.02 Ratio of bottom 40% to top10% labour income share 27.5 19.4 69 Slovak Republic
7.03 Ratio of bottom 50% to top 50% labour income share 15.6 14.1 72 Slovak Republic
7.04 Mean income of bottom 40% (% of national mean income) 46.9 62.7 34 Multiple (4)
7.05 Adjusted labour income share (%) 40.5 34.4 69 Switzerland
- 53.3 57 Sweden Pillar 8: W orking Conditions (0–100 best)
8.01 Workers’ Rights Index (0–100, best) 64.0 64.0 57 Multiple (2)
8.02 Cooperation in labour-employer relations (1–7) 4.3 55.6 56 Singapore
8.03 Pay and productivity (1–7) 4.2 53.1 42 Switzerland
8.04 Employees working more than 48 hours per week (%) 29.8 40.4 65 Bulgaria
8.05 Collective bargaining coverage ratio (%) n/a n/a n/a France
- 36.8 63 Denmark Pillar 9: Social Protection (0–100 best)
9.01 Guaranteed min. income beneﬁts (% of median income) n/a n/a n/a Multiple (2)
9.02 Social protection coverage (% of population) 37.9 37.9 47 Multiple (6)
9.03 Social protection spending (% of GDP) 6.3 25.3 62 Multiple (9)
9.04 Social safety net protection, 1-7 3.8 47.2 53 Norway
- 55.7 52 New Zealand Pillar 10: Inclusive Institutions (0–100 best)
10.01 Corruption Perceptions Index (0=highly corrupt; 100=very clean) 33.0 33.0 70 Denmark
10.02 Government and public services efﬁciency (score) 0.0 52.3 56 Singapore
10.03 Inclusiveness of institutions (score) 0.0 66.8 49 Portugal
10.04 Political stability and protection from violence (score) 0.2 70.6 42 New Zealand

202In order to make the impact of social mobility tangible, we estimate the impact of social mobility on 
economic growth which we use as a basis to turn social mobility into a dollar value. The idea is to 
quantify the value of the missed opportunities of lacking social mobility in monetary terms. As we 
do not claim to estimate a causal effect, we use a framework that allows us to approximate the 
potential increase in GDP growth associated with a social mobility score increase.
To do so, we follow the logic of Hall and Jones (1999) who suggest that social infrastructure 
has an impact on output per worker in part directly (via the quality of input [human capital]) and 
in part indirectly (through productivity). While these authors interpret social infrastructure mainly in 
terms of openness and lack of rent-seeking, we argue that the drivers of social mobility measured 
by the GSMI include many aspects that matter for fostering human capital such as meritocracy, 
education quality, adequate safety nets, appropriate reward of talent, quality of institutions etc. As 
such it is a broader measure of “social infrastructure” than the one proposed by Hall and Jones, yet 
it shares many of the underlying ideas. A good social infrastructure does not only impact human 
capital directly but may also encourage “the adoption of new ideas and new technologies”. 
An obvious methodological problem to estimate the impact of social mobility in an economic 
growth framework is endogeneity. Clearly, there is a simultaneous effect going from social 
mobility to economic growth and from economic growth to social mobility. 
Good institutions that drive economic outcomes are not randomly assigned to countries, 
but they are determined endogenously by many factors, including the wealth of a country itself. 
Despite these complications, our hypothesis is that relative social mobility is a fundamental 
determinant of economic growth and follow the general idea of Hall and Jones to relate “social 
infrastructure” with GDP per capita. However, instead of using instrumental variable regression, 
we simply control for the initial level of income of countries and estimate the following cross-
country linear regression:
Although the inclusion of the initial level of income does not solve the endogeneity problem, 
it makes sure that the estimate of the relation between of GSMI on growth is conditional to the 
current level of income of countries.
The coefficient of the variable social mobility index is positive and significant at 95%. The 
marginal effect of social mobility on GDP per capita growth is 0.003 over seven years, or 0.04% 
per year for each unit, which means that an increase of 10 units in the index (i.e. from 50 to 60) 
would increase growth by 0.4% per year. For instance, a country that is growing at 1% would 
grow at 1.4% if it manages to increase its social mobility by 10 points. The results are the following:
Dependent variable GDPpc growth
Social mobility index 0.0031
(0.002)
GDPpc -0.117
(0.025)
Constant 1.283
(0.174)
Observations 82GDPpcGrowthi(2017–2024) = β1GDPpc2017i+β2SMIi+εi            (1)
You can find below an estimate of the opportunity costs of low social mobility each year 
and to each economy ranked in the GSMI and to the global economy. All else being equal, if all 
countries increased their GSMI performance by 10 points, the resulting growth would convert into 
an additional $514 billion for the global economy each year (in PPP terms). This would represent 
an extra 4.41% GDP growth for the global economy by 2030.Appendix A. Estimating the Opportunity Cost 
of Low Social Mobility

203Current 
GSMI Rank Economy Total additional GDP growth per 
year, attributable to +10 points 
in GSMI by 2030 (Million USD $)Cumulative additional GDP growth by 
2030, attributable to +10 points in GSMI 
in Social Mobility (Million USD $)
54 Albania 158 1,585
51 Argentina 4,090 40,901
56 Armenia 124 1,244
16 Australia 5,616 56,157
8 Austria 1,959 19,590
78 Bangladesh 3,079 30,786
9 Belgium 2,349 23,492
60 Brazil 14,459 144,594
40 Bulgaria 673 6,730
80 Cameroon 404 4,044
14 Canada 7,881 78,805
47 Chile 2,032 20,317
45 China 102,577 1,025,769
65 Colombia 3,160 31,605
44 Costa Rica 374 3,744
82 Côte d'Ivoire 440 4,404
36 Croatia 447 4,467
29 Cyprus 145 1,449
19 Czech Republic 1,663 16,625
1 Denmark 1,290 12,901
57 Ecuador 863 8,632
71 Egypt 5,421 54,209
68 El Salvador 227 2,265
23 Estonia 185 1,854
3 Finland 1,091 10,905
12 France 12,600 126,001
53 Georgia 176 1,755
11 Germany 18,483 184,831
70 Ghana 794 7,943
48 Greece 1,316 13,164
75 Guatemala 621 6,211
74 Honduras 208 2,078
37 Hungary 1,278 12,784
5 Iceland 82 824
76 India 42,845 428,452
67 Indonesia 14,473 144,734
18 Ireland 1,567 15,667
33 Israel 1,433 14,329
34 Italy 10,232 102,320
15 Japan 23,869 238,691
38 Kazakhstan 2,133 21,333
25 Korea, Rep. 9,418 94,175
72 Lao P.D.R. 221 2,207
31 Latvia 236 2,359
26 Lithuania 401 4,009
10 Luxembourg 274 2,740
43 Malaysia 4,218 42,177
17 Malta 90 896
58 Mexico 10,969 109,689
49 Moldova 107 1,072

204Current 
GSMI Rank Economy Total additional GDP growth per 
year, attributable to +10 points 
in GSMI by 2030 (Million USD $)Cumulative additional GDP growth by 
2030, attributable to +10 points in GSMI 
in Social Mobility (Million USD $)
73 Morocco 1,330 13,300
6 Netherlands 4,099 40,989
22 New Zealand 843 8,429
2 Norway 1,694 16,944
79 Pakistan 4,755 47,551
63 Panama 449 4,494
69 Paraguay 398 3,981
66 Peru 1,917 19,175
61 Philippines 3,927 39,272
30 Poland 4,980 49,801
24 Portugal 1,398 13,981
42 Romania 2,124 21,238
39 Russia 17,798 177,976
52 Saudi Arabia 8,024 80,237
81 Senegal 249 2,486
41 Serbia 505 5,049
20 Singapore 2,399 23,992
32 Slovak Republic 792 7,925
13 Slovenia 315 3,146
77 South Africa 3,425 34,251
28 Spain 7,843 78,432
59 Sri Lanka 1,231 12,308
4 Sweden 2,336 23,358
7 Switzerland 2,330 23,299
55 Thailand 5,476 54,759
62 Tunisia 614 6,136
64 Turkey 9,777 97,770
46 Ukraine 1,622 16,216
21 United Kingdom 12,988 129,880
27 United States 86,673 866,727
35 Uruguay 345 3,454
50 Viet Nam 2,887 28,871
Grand Total 514,294 5,142,945

205Appendix B. Methodology and Technical Notes 
Section A of this appendix presents the methodology and detailed structure of the Global Social 
Mobility Index. Section B presents the methodology used to compute progress scores. Finally, Section C provides detailed descriptions and sources for each indicator included in the index.
A. Computation and Composition of the Social Mobility Index
The computation of the Global Social Mobility Index is based on successive aggregations of scores, 
from the indicator level (the most disaggregated level) to the overall Social Mobility Index (the highest 
level). At every aggregation level, each aggregated measure is computed by taking the average 
(i.e. arithmetic mean) of each score, each indicator is given equal weights within their pillar. The 
overall Social Mobility Index score is the average of the scores of the 10 pillars. Each pillar, therefore, 
accounts for 10% of the overall score.
For individual indicators, prior to aggregation, raw values are transformed into a progress score 
ranging from 0 to 100, with 100 being the ideal state, as described in Section B. 
Complete Indicator List and Index Components
Pillar I Health (0–100 best) (10%)
1.1 Adolescent birth rate per 1,000 women
1.2 Prevalence of malnourishment (% of 5-19 year olds)
1.3 Health Access and Quality Index (0–100 best)
1.4 Inequality-adjusted healthy life expectancy index (0–100 best)
Pillar II Education Access (0–100 best) (10%)
2.1 Pre-primary enrolment (%)
2.2 Quality of vocational training (1–7 best)
2.3 NEET ratio (% of 15–24 year olds)
2.4 Out-of-school children (%)
2.5 Inequality-adjusted education index (0–100 best)
Pillar III Education Quality and Equity (0–100 best) (10%)
3.1 Children below minimum proficiency (%)
3.2 Pupils per teacher in pre-primary education (%)
3.3 Pupils per teacher in primary education (%)
3.4 Pupils per teacher in secondary education (%)
3.5 Harmonized learning outcomes (score)
3.6 Social diversity in schools (score)
3.7 Lack of education material among disadvantaged children (%) 
Pillar IV Lifelong Learning (0–100 best) (10%)
4.1 Extent of staff training (1–7 best)
4.2 Active labour market policies (1–7 best)
4.3 Access to basic services through ICTs (1–7 best)
4.4 Percentage of firms offering formal training
4.5 Digital skills among active population (1–7 best)

206Pillar V Technology Access (0–100 best) (10%)
5.1 Internet users (%)
5.2 Fixed-broadband Internet subscriptions per 100 pop.
5.3 Mobile-broadband subscriptions per 100 pop.
5.4 Population covered by at least a 3G mobile network (%)
5.5 Rural population with electricity access (%)
5.6 Internet access in schools (1–7 best)
Pillar VI Work Opportunities (0–100 best) (10%)
6.1 Unemployment among labour force with basic education (%)
6.2 Unemployment among labour force with intermediate education (%)
6.3 Unemployment among labour force with advanced education (%)
6.4 Unemployment in rural areas (%)
6.5 Ratio of female to male labour force participation rate
6.6 Workers in vulnerable employment (%)
Pillar VII Fair Wage Distribution (0–100 best) (10%)
7.1 Low pay incidence (% of workers)
7.2 Ratio of bottom 40% to top 10% labour income share (%)
7.3 Ratio of bottom 50% to top 50% labour income share (%)
7.4 Mean income of bottom 40% (% of national mean income)
7.5 Adjusted labour income share (%) 
Pillar VIII Working Conditions (0–100 best) (10%)
8.1 Workers’ Rights Index (0–100 best)
8.2 Cooperation in labour-employer relations (1–7 best)
8.3 Meritocracy at work (1–7 best)
8.4 Employees working more than 48 hours per week (%)
8.5 Collective bargaining coverage ratio (%)
Pillar IX Social Protection (0–100 best) (10%)
9.1 Guaranteed min. income benefits (% of median income)
9.2 Social protection coverage (% of population)
9.3 Social protection spending (% of GDP)
9.4 Social safety net protection (1–7 best)
Pillar X Inclusive Institutions (0–100 best) (10%)
10.1 Corruption Perceptions Index (0–100 best)
10.2 Government and public services efficiency (score)
10.3 Inclusiveness of institutions (score)
10.4 Political stability and protection from violence (score)

207B. Computation of Progress Scores and Frontier Values
To allow the aggregation of indicators of different nature and magnitude, each indicator entering 
the Global Social Mobility Index is converted into a unit-less score, called “progress score”, ranging from 0 to 100 using a min-max transformation. Formally, each indicator is re-scaled according to the following formula:
where value
i,c is the “raw” value of country c for indicator i, worst performance ( wpi,) is the 
lowest acceptable value for indicator i and frontier i corresponds to the best possible outcome. 
Depending on the indicator, the frontier may be a policy target or aspiration, the maximum 
possible value, or a number derived from statistical analysis of the distribution (e.g. 90th or 95th 
percentile). If a value is below the worst performance value, its score is 0; if a value is above the frontier value, its score is capped at 100. 
In the case of indicators derived from the Executive Opinion Survey, frontier
i and wpi values 
are always 7 and 1, respectively. These values correspond to the two extreme answers of any questions. Table 1 below provides the actual floor and frontier values used for the normalization of each individual indicator. 
Indicator titles and units Frontier Worst 
performanceGuiding principle
1.01 Adolescent birth rate per 1.000 women 100 0 95th percentile rounded up to 100
1.02 Prevalence of malnourishment (% of 5-19 year olds) 50 0 Arbitrary min max
1.03 Health Access and Quality Index (0–100 best) 100 0 Extreme values of the IHME Index
1.04 Inequality-adjusted healthy life expectancy index 
(0–100 best)72 40 Health adjusted life expectancy score based on Human Development Report 
2016 Practice
2.01 Pre-primary enrolment (%) 100 0 Range of possible values
2.02 Quality of vocational training (1–7 best) 7 1 Range of possible values
2.03 NEET ratio (% of 15–24 year olds) 30 0 Natural min and arbitrary maximum
2.04 Out-of-school children (%) 10 0 Natural min. 95th percentile rounded
2.05 Inequality-adjusted education index (0–100 best) 1 0 Natural min. round 95th percentile
3.01 Children below minimum proficiency (%) 70 0 Natural min. round 95th percentile
3.02 Pupils per teacher in pre-primary education 35 5 5th percentile rounded/arbitrary max
3.03 Pupils per teacher in primary education 40 10 Arbitrary min/arbitrary max
3.04 Pupils per teacher in secondary education 35 5 Arbitrary min/arbitrary max
3.05 Harmonized learning outcomes (score) 600 200 Natural min/arbitrary max
3.06 Social diversity in schools (score) 91 50 Min rounded to 50/arbitrary max
3.07 Percentage of disadvantaged students in schools 
which report a lack of education material100 0 Arbitratry min/arbitraty max
4.01 Extent of staff training (1–7 best) 7 1 Range of possible values
4.02 Active labour market policies (1–7 best) 7 1 Range of possible values
4.03 Access to basic services through ICTs (1–7 best) 7 1 Range of possible values
4.04 Percentage of firms offering formal training 75 0 Both extremes rounded
4.05 Digital skills among active population (1–7 best) 7 1 Range of possible values
5.01 Internet users (%) 100 0 GCI 4.0 2019 value
5.02 Fixed-broadband internet subscriptions per 100 pop. 50 0 GCI 4.0 2019 value
5.03 Mobile-broadband subscriptions per 100 pop. 120 0 120 is the value above which mobile broadband technology is considered sufficiently widespread not to constitute a constraint for the  
average user
5.04 Population covered by at least a 3G mobile network (%) 100 0 Range of possible values
5.05 Rural population with electricity access (%) 100 0 Range of possible values
5.06 Internet access in schools (1–7 best) 7 1 Range of possible valuesscore i,c =value i,c - wp i
frontier i - wp ix 100

208Indicator titles and units Frontier Worst 
performanceGuiding principle
6.01 Unemployment among labour force with basic 
education (%)25 0 Natural min/arbitrary max
6.02 Unemployment among labour force with intermediate 
education (%)25 0 Natural min/arbitrary max
6.03 Unemployment among labour force with advanced 
education (%)25 0 Natural min/arbitrary max
6.04 Unemployment in rural areas (%) 25 0 Natural min/arbitrary max
6.05 Ratio of female to male labour force participation rate 100 20 Rounded min value/Aspirational parity
6.06 Workers in vulnerable employment (%) 60 0 Natural min/arbitrary max
7.01 Low pay incidence (% of workers) 35 0 Arbitrary min/95th percentile rounded to 35
7.02 Ratio of bottom 40% to top 10% labour income share 100 10 Rounded 5th percentile / fair 
distribution
7.03 Ratio of bottom 50% to top 50% labour income share 50 10 Rounded 5th percentile / arbitrary 
sense of fairness: bottom 50 earns half of top 50
7.04 Mean income of bottom 40% (% of national mean 
income)60 25 Rounded 5th/rounded 95th percentile
7.05 Adjusted labour income share (%) 70 25 Rounded 5th/rounded best performer
8.01 Workers’ Rights Index (0–100 best) 100 0 Range of possible values
8.02 Cooperation in labour-employer relations (1–7 best) 7 1 Range of possible values
8.03 Meritocracy at work (1-7 best) 7 1 Range of possible values
8.04 Employees working more than 48 hours per week (%) 50 0 Natural min/arbitrary max
8.05 Collective bargaining coverage ratio (%) 100 0 Natural min/arbitrary max
9.01 Guaranteed min. income benefits (% of median income) 75 0 Natural min/arbitrary max
9.02 Social protection coverage (% of population) 100 0 Range of possible values
9.03 Social protection spending (% of GDP) 25 0 Natural min/95th percentile rounded
9.04 Social safety net protection (1–7 best) 7 1 Range of possible values
10.01 Corruption Perceptions Index (0–100 best) 100 0 Range of possible values
10.02 Government and public services efficiency (score) 2.23 -2.45 Extremes of WGI governance 
indicators
10.03 Inclusiveness of institutions (score) 1.26 -2.50 Extremes of the Haas Inclusiveness Index
10.04 Political stability and protection from violence (score) 1.54 -3.00
Extremes of WGI governance indicators
C. Indicator Definitions and Sources
The following pages provide sources for all the individual indicators included in the Global Social 
Mobility Index 2020 (GSMI). The title of each indicator appears on the first line, preceded by its number to allow for quick reference. Underneath is a description of each indicator or, in the case of indicators derived from the World Economic Forum’s Executive Opinion Survey, the full question and associated answers. If necessary, additional information is provided below 
that. For more information about indicators derived from the Executive Opinion Survey, refer to 
Appendix B of the World Economic Forum’s Global Competitiveness Report 2019.
The interactive ranking tables at www.weforum.org/smr2020/rankings provide information 
about the source and period for each individual data point. Select the indicator of interest from the selector and click on the “info” icon next to each economy to access the information. For indicators not sourced from the World Economic Forum, users are urged to refer to the original source for any additional information and exceptions for certain economies and/or data points. 
“Terms of Use and Disclaimer” on page ii provide information about using the data. The data used in the computation of the GSMI represents the most recent and best data available at the 
time when it was collected (September–December 2019). It is possible that data was updated 
or revised subsequently.

209Pillar 1 Health
1.1 Adolescent birth rate
Adolescent fertility rate is the number of births 
per 1,000 women aged 15–19 | 2017
Source: United Nations Population Division,  World Population Prospects . 
1.2 Prevalence of malnourishment 
among youth       
Prevalence of moderate or severe underweight or obesity among youth and adolescent (5–19 years) population | 2016
Moderate or severe underweight is defined as more than 2 standard deviations below the median of the WHO growth reference for children and adolescents. Obesity is defined as more than 2 standard deviations above the median WHO growth reference.
Source: NCDRisc, based on “Worldwide trends in body-mass index, 
underweight, overweight, and obesity from 1975 to 2016: A pooled analysis of 2416 population-based measurement studies in 128.9 million children, adolescents, and adults”, Lancet , 2018.
1.3 Health access and quality        
Health Access and Quality Index score as 
defined by the IHME, based on the Global Burden of Disease dataset | 2017
Drawing from established methods and updated estimates 
from the Global Burden of Disease (GBD) 2016, we used 32 causes that should not result in death in the presence of effective care to approximate personal healthcare access and quality by location and over time. To better isolate potential effects of personal healthcare access and quality from underlying risk factor patterns, we risk-standardized cause-specific deaths due to non-cancers by location-year, replacing the local joint exposure of environmental and behavioural risks with the global level of exposure. Sup-ported by the expansion of cancer registry data in the Global Burden of Diseases 2016, we used mortality-to-in-cidence ratios for cancers instead of risk-standardized death rates to provide a stronger signal of the effects of personal healthcare and access on cancer survival. We transformed each cause to a scale of 0–100, with 0 as the first percentile (worst) observed between 1990 and 2016, and 100 as the 99th percentile (best). We set these thresholds at the country level, and then applied them to subnational locations. We applied a principal components analysis to construct the Health Access and Quality (HAQ) Index using all scaled cause values, providing an overall score of 0–100 of personal healthcare access and qual-ity by location over time. We then compared HAQ Index levels and trends by quintiles on the Socio-demographic Index (SDI), a summary measure of overall development. 
Source: Institute for Health Metrics and Evaluation, Global Burden of 
Diseases 2017 .  1.4 Inequality-adjusted healthy life expectancy      
Inequality-adjusted Healthy life expectancy 
at birth | 2017   
Healthy Life expectancy Index adjusted for 
inequality in life expectancy as defined by UNDP’s Human Development Report 2018.
Sources: Forum calculations, UNDP and Institute for Health Metrics 
and Evaluation’s Global Burden of Disease 2017 .
Pillar 2: Education Access
2.1 Pre-primary enrolment        
Enrolment in pre-primary education; population of the 
age group corresponding to the given level of education | 2018 or most recent period available 
This data set is based on school register, school survey 
or census for data on enrolment by age; population census or estimates for school-age population.
Source: UNESCO Institute for Statistics. 
2.2 Quality of vocational training        
Response to the survey question “In your country, how do you assess the quality of vocational training?” [1 = extremely poor, among the worst in the world; 7 = excellent, among the best in the world]. | 2018–2019 weighted average or most recent period available
Source: World Economic Forum, Executive Opinion Survey. 
2.3 NEET ratio          
Youth (age 15–24) not in education, employment or training  | 2018 or most recent period available 
Source: International Labour Organization, ILOSTAT  database. 
2.4 Out-of-school children         
Out-of-school children as a share of children of primary school age | 2016   
Source: World Bank, Ending Learning Poverty: What Will It Take? , 2019.   
2.5 Inequality-adjusted education access       
Inequality-adjusted average between mean years of schooling and expected years of schooling | 2017  
Mean and expected years of schooling are based on household surveys data harmonized in international data-bases, including the Luxembourg Income Study; Eurostat’s European Union Survey of Income and Living Conditions; the World Bank’s International Income Distribution Data-

210base; ICF Macro Demographic and Health Surveys; the 
United Nations Children’s Fund Multiple Indicators Clus-ter Survey; the Center for Distributive, Labor and Social Studies; the World Bank’s Socio-Economic Database for Latin America and the Caribbean; and the United Na-tions University’s World Income Inequality Database.
Source: UNDP, Human Development Index, 2018 Edition.   
Pillar 3: Education Quality 
and Equity
3.1 Children below minimum proficiency 
by age 10      
Share of children at the end of primary school 
who read at below the minimum proficiency level, as defined by the Global Alliance to Monitor Learning (GAML), in the context of Sustainable Development Goal 4.1.1 monitoring | 2016
Source: World Bank, Ending Learning Poverty: What Will It Take? , 2019. 
3.2 Pupil-to-teacher ratio 
in pre-primary education      
Average number of pupils per teacher in pre-primary school | 2018 or most recent period available 
The pupil-teacher ratio is calculated by dividing the number 
of students at the specified level of education by the number of teachers at the same level of education. Data on education is collected by the UNESCO Institute for Statistics from official responses to its annual education survey.  
Source: UNESCO Institute for Statistics. 
3.3 Pupil-to-teacher ratio 
in primary education      
Average number of pupils per teacher in primary school | 2018 or most recent period available  
The pupil-teacher ratio is calculated by dividing the number 
of students at the specified level of education by the number of teachers at the same level of education. Data on education is collected by the UNESCO Institute for Statistics from official responses to its annual education survey.  
Source: UNESCO Institute for Statistics. 3.4 P upil-to-teacher r atio 
in se condary e ducation      
Average number of pupils per teacher in secondary 
school | 2018 or most recent period available 
The pupil-teacher ratio is calculated by dividing the num-
ber of students at the specified level of education by the 
number of teachers at the same level of education. Data on 
education is collected by the UNESCO Institute for Statis-
tics fr
om offi cial responses to its annual education survey.  
Source: U NESCO I nstitute f or Statistics. 
3.5 Harmonized learning outcomes        
Composite score representing achievement on 7 
international and regional achievement tests | 2018 
Harmonized lear
ning outcomes are produced using a 
conversion factor to compare international and regional 
standardized achievement tests. These tests include 
PISA, TIMSS, PIRLS, SACMEQ, LLECE, and PASEC. 
The harmonized learning outcomes score highlights 
levels of student learning in reading, mathematics and 
science in over 100 countries based on data from 
four international learning assessments and three 
regional learning assessments. All mean scores were 
calculated on a scale with a center point of 500 except 
2004–2010 PASEC (0 to 100 scale), 1997 LLECE 
(250 centre point), and PIAAC (0 to 500 scale). 
Source: W orld Ba nk H armonised L earning O utcome Da shboard. 
3.6 Social diversity in schools     
Scor
e on the PISA index of social inclusion | 2018 
The PISA index of social inclusion is calculated as 100(1-
rho), where rho stands for the intra-class correlation of so-
cio-economic status. The intra-class correlation, in turn, is the 
variation in student socio-economic status between schools, 
divided by the sum of the va riation in student socio-eco-
nomic status between schools and the variation in student 
socio-economic status within schools, and multiplied by 1 00. 
Source: OECD, PISA 2 018 D atabase. 
3
.07 Lack of education materials among 
disadvantaged students     
Proportion of students in schools whose principal 
reported a lack in educational material | 2018 
Source: OECD, PISA 2 018 D atabase.