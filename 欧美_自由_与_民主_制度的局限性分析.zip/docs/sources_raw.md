# 原始信源列表

此文件用于记录所有在研究过程中搜集到的原始网络链接、学术论文、报告及其他资料的快照。

## 批次一：初步搜索结果

### 精英理论与民主
1.  **Elite theory - Wikipedia**: [https://en.wikipedia.org/wiki/Elite_theory](https://en.wikipedia.org/wiki/Elite_theory) (权力集中于统一的精英阶层)
2.  **A Critique of the Elitist Theory of Democracy**: [https://fbaum.unc.edu/teaching/articles/Walker-APSR_1966.pdf](https://fbaum.unc.edu/teaching/articles/Walker-APSR_1966.pdf) (对经典民主理论的批判)
3.  **Introduction. Elite Theory: Philosophical Challenges - PubMed Central**: [https://pmc.ncbi.nlm.nih.gov/articles/PMC9046547/](https://pmc.ncbi.nlm.nih.gov/articles/PMC9046547/) (所有社会都由少数精英统治)
4.  **The Power Elite**: [https://www1.udel.edu/htr/American/Texts/power.html](https://www1.udel.edu/htr/American/Texts/power.html) (单一精英群体决定国家重大问题)

### 投票率与收入水平
1.  **Election turnout: Why do some people not vote? - POST Parliament**: [https://post.parliament.uk/election-turnout-why-do-some-people-not-vote/](https://post.parliament.uk/election-turnout-why-do-some-people-not-vote/) (英国大选投票率下降)
2.  **ELECTION TURNOUT IN POOREST AREAS DROPPED TWICE...**: [https://www.johnsmithcentre.com/news/research-election-turnout-in-poorest-areas-dropped-twice-the-rate-as-richest/](https://www.johnsmithcentre.com/news/research-election-turnout-in-poorest-areas-dropped-twice-the-rate-as-richest/) (英国最贫困地区投票率下降速度是富裕地区的两倍)
3.  **Low voter turnout? Increasing household income may help - CEPR**: [https://cepr.org/voxeu/columns/low-voter-turnout-increasing-household-income-may-help](https://cepr.org/voxeu/columns/low-voter-turnout-increasing-household-income-may-help) (美国富人投票率更高)
4.  **Next UK election set to be most unequal in 60 years, study finds**: [https://www.theguardian.com/politics/2023/dec/11/next-uk-election-set-to-be-most-unequal-in-60-years-study-finds](https://www.theguardian.com/politics/2023/dec/11/next-uk-election-set-to-be-most-unequal-in-60-years-study-finds) (高低收入者投票率差距扩大)

### 政治捐款与游说
1.  **Influence & Lobbying - OpenSecrets**: [https://www.opensecrets.org/influence](https://www.opensecrets.org/influence) (金钱在政治中的作用)
2.  **How Campaign Contributions and Lobbying Can Lead to Inefficient...**: [https://www.americanprogress.org/article/how-campaign-contributions-and-lobbying-can-lead-to-inefficient-economic-policy/](https://www.americanprogress.org/article/how-campaign-contributions-and-lobbying-can-lead-to-inefficient-economic-policy/) (政治献金和游说导致低效经济政策)
3.  **how campaign contributions and lobbying affect public policy**: [https://pubmed.ncbi.nlm.nih.gov/24413211/](https://pubmed.ncbi.nlm.nih.gov/24413211/) (公共政策受金钱影响)

### Sheldon Wolin 与“倒置极权主义”
1.  **Sheldon Wolin and Inverted Totalitarianism - Truthdig**: [https://www.truthdig.com/articles/sheldon-wolin-and-inverted-totalitarianism/](https://www.truthdig.com/articles/sheldon-wolin-and-inverted-totalitarianism/)
2.  **Democracy Incorporated - Princeton University Press**: [https://press.princeton.edu/books/paperback/9780691178486/democracy-incorporated](https://press.princeton.edu/books/paperback/9780691178486/democracy-incorporated)
3.  **Managed Democracy and the Specter of Inverted Totalitarianism - jstor**: [https://www.jstor.org/stable/j.ctvc77b3h](https://www.jstor.org/stable/j.ctvc77b3h)

### Michael Parenti 与“少数人的民主”
1.  **Democracy for the Few by Michael Parenti | Goodreads**: [https://www.goodreads.com/book/show/387894.Democracy_for_the_Few](https://www.goodreads.com/book/show/387894.Democracy_for_the_Few)
2.  **Reviewing Michael Parenti's 'Democracy For the Few'**: [https://organicconsumers.org/article_6326/](https://organicconsumers.org/article_6326/)
3.  **“Democracy for the Few” by Michael Parenti Essay - IvyPanda**: [https://ivypanda.com/essays/democracy-for-the-few-by-michael-parenti/](https://ivypanda.com/essays/democracy-for-the-few-by-michael-parenti/)

### 自由主义、财产权与阶级
1.  **Liberalism, Property, and the Means of Production - LPE Project**: [https://lpeproject.org/blog/liberalism-property-and-the-means-of-production/](https://lpeproject.org/blog/liberalism-property-and-the-means-of-production/)
2.  **Private Property Rights - (AP European History) - Fiveable**: [https://library.fiveable.me/key-terms/ap-euro/private-property-rights](https://library.fiveable.me/key-terms/ap-euro/private-property-rights)
3.  **Liberalism - Stanford Encyclopedia of Philosophy**: [https://plato.stanford.edu/entries/liberalism/](https://plato.stanford.edu/entries/liberalism/)

### 经济不平等与政治参与
1.  **Unequal Democracy: Economic Inequality and Political...**: [https://sites.lsa.umich.edu/mje/2025/01/09/unequal-democracy-economic-inequality-and-political-representation/](https://sites.lsa.umich.edu/mje/2025/01/09/unequal-democracy-economic-inequality-and-political-representation/)
2.  **How social inequality breeds unequal political participation**: [https://blogs.lse.ac.uk/inequalities/2024/09/25/how-social-inequality-breeds-unequal-political-participation-and-what-to-do-about-it/](https://blogs.lse.ac.uk/inequalities/2024/09/25/how-social-inequality-breeds-unequal-political-participation-and-what-to-do-about-it/)
3.  **Does economic inequality undermine political equality?**: [https://www.sciencedirect.com/science/article/abs/pii/S0261379420300858](https://www.sciencedirect.com/science/article/abs/pii/S0261379420300858)


### 批次二：补充搜索结果

#### “自由”概念的批判性分析 (替代信源)
1.  **Revisiting Marx's Critique of Liberalism**: [https://marxandphilosophy.org.uk/reviews/18845_revisiting-marxs-critique-of-liberalism-rethinking-justice-legality-and-rights-by-igor-shoikhedbrod-reviewed-by-james-furner/](https://marxandphilosophy.org.uk/reviews/18845_revisiting-marxs-critique-of-liberalism-rethinking-justice-legality-and-rights-by-igor-shoikhedbrod-reviewed-by-james-furner/) (马克思对自由主义的批判)
2.  **The Marxist Critique of Liberalism - sanjana sheth**: [https://sanjanasheth.com/2021/03/25/the-marxist-critique-of-liberalism/](https://sanjanasheth.com/2021/03/25/the-marxist-critique-of-liberalism/) (马克思主义视角下的财产权)
3.  **What Karl Marx Really Thought About Liberalism - Jacobin**: [https://jacobin.com/2020/10/karl-marx-liberalism-rights-igor-shoikhedbrod-review](https.jacobin.com/2020/10/karl-marx-liberalism-rights-igor-shoikhedbrod-review) (马克思对自由主义成就和私有财产权的批判)

#### “倒置极权主义”的详细解释 (替代信源)
1.  **Inverted totalitarianism - Wikipedia**: [https://en.wikipedia.org/wiki/Inverted_totalitarianism](https://en.wikipedia.org/wiki/Inverted_totalitarianism) (维基百科的详细解释)
2.  **Liberalism and the spectre of inverted totalitarianism**: [https://canadiandimension.com/articles/view/liberalism-and-the-spectre-of-inverted-totalitarianism](https://canadiandimension.com/articles/view/liberalism-and-the-spectre-of-inverted-totalitarianism) (自由主义与倒置极权主义的联系)
3.  **Democracy Incorporated: Managed Democracy and the Specter of...**: [https://www.amazon.com/Democracy-Incorporated-Managed-Inverted-Totalitarianism/dp/069114589X](https://www.amazon.com/Democracy-Incorporated-Managed-Inverted-Totalitarianism/dp/069114589X) (沃林专著的亚马逊页面)

